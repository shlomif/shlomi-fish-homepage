package Shlomif::R2L::Poller;

use strict;

sub new
{
    my $class = shift;
    my $self = {};

    bless $self, $class;

    $self->{'status'} = 0;

    $self->initialize(@_);

    return $self;
}

sub initialize
{
    # Do nothing

    # This is not exactly an abstract function, but then again I don't 
    # have anything to do here.
}

sub get_status
{
    my $self = shift;
    
    return $self->{'status'};
}

sub enable
{
    my $self = shift;
   
    # proto_enable does the actual enabling. It should be overriden by
    # the class that inherits us.
    $self->proto_enable();
    $self->{'status'} = 1;
}

sub proto_enable
{
    # Do Nothing
}

sub disable
{
    my $self = shift;
    
    # proto_disable does the actual disabling. It should be overriden by
    # the class that inherits us.
    $self->proto_disable();
    $self->{'status'} = 0;
}

sub proto_disable
{
    # Do Nothing
}

sub switch
{
    my $self = shift;
   
    # I do not poll because the user wishes the state to change from what
    # he sees, not from what exists
    my $status = $self->get_status();

    if ($status)
    {
        $self->disable();
    }
    else
    {
        $self->enable();
    }
}

# Polls the external value for an up-to-date value.
# Returns whether it was changed from the time of the last poll.
sub poll
{
    my $self = shift;

    my $prev_status = $self->get_status();

    $self->{'status'} = $self->proto_poll();

    return ($prev_status != $self->get_status());
}

sub proto_poll
{
    my $self = shift;
    # Return Something irrelavant because this is an abstract function.
    return $self->get_status();
}

1;
