$pathman = bless( {
                    'root' => {
                                'attrbs' => {},
                                'subdirs' => {
                                               'Shlomif' => {
                                                              'attrbs' => {},
                                                              'subdirs' => {},
                                                              '..' => $pathman->{'root'},
                                                              'is_mounted' => '0'
                                                            },
                                               'Ira' => {
                                                          'attrbs' => {},
                                                          'subdirs' => {},
                                                          '..' => $pathman->{'root'},
                                                          'is_mounted' => '0'
                                                        },
                                               'Hello' => {
                                                            'attrbs' => {},
                                                            'subdirs' => {
                                                                           'World' => {
                                                                                        'attrbs' => {},
                                                                                        'subdirs' => {},
                                                                                        '..' => $pathman->{'root'}{'subdirs'}{'Hello'},
                                                                                        'is_mounted' => '0'
                                                                                      },
                                                                           'Bill (Gates Naturally)' => {
                                                                                                         'attrbs' => {},
                                                                                                         'subdirs' => {},
                                                                                                         '..' => $pathman->{'root'}{'subdirs'}{'Hello'},
                                                                                                         'is_mounted' => '0'
                                                                                                       },
                                                                           'You' => {
                                                                                      'attrbs' => {},
                                                                                      'subdirs' => {},
                                                                                      '..' => $pathman->{'root'}{'subdirs'}{'Hello'},
                                                                                      'is_mounted' => '0'
                                                                                    }
                                                                         },
                                                            '..' => $pathman->{'root'},
                                                            'is_mounted' => '0'
                                                          },
                                               'Chen' => {
                                                           'attrbs' => {},
                                                           'subdirs' => {
                                                                          'Shapira' => {
                                                                                         'attrbs' => {},
                                                                                         'subdirs' => {},
                                                                                         '..' => $pathman->{'root'}{'subdirs'}{'Chen'},
                                                                                         'is_mounted' => '0'
                                                                                       },
                                                                          'Hackers-IL' => {
                                                                                            'attrbs' => {},
                                                                                            'subdirs' => {},
                                                                                            '..' => $pathman->{'root'}{'subdirs'}{'Chen'},
                                                                                            'is_mounted' => '0'
                                                                                          }
                                                                        },
                                                           '..' => $pathman->{'root'},
                                                           'is_mounted' => '0'
                                                         }
                                             },
                                '..' => undef,
                                'is_mounted' => '0'
                              }
                  }, 'Gamla::Web::PathMan::Perl' );
$p = bless( {
              'cur_dir' => $pathman->{'root'}{'subdirs'}{'Chen'},
              'path_man' => $pathman,
              'pm_path' => [
                             'Chen'
                           ],
              'recursive_write' => 1,
              'recursive_mount' => '0',
              'is_in_mounted' => '0'
            }, 'Gamla::Web::PathMan::Perl::Pointer' );
