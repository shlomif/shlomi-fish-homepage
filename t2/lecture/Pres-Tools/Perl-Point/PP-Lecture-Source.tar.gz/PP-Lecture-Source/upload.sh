#!/bin/bash

src="PP-Lecture-Source"
RSYNC="rsync --progress --verbose --rsh=ssh"
find . -name '*~' -print | xargs rm -f
make $src.tar.gz
mkdir to_upload
cp slide*.htm *.png *.gif to_upload
cp $src.tar.gz to_upload
cd to_upload
$RSYNC -r * shlomif@vipe:public_html/lecture/Pres-Tools/Perl-Point/
cd ..
rm -fr to_upload



