package Gamla::Web::PathMan::Base::Pointer;

use strict;

use Gamla::Object;

use vars qw(@ISA);

@ISA=qw(Gamla::Object);

sub initialize
{
    my $self = shift;

    $self->{'pathman'} = shift;

    return (0, [ @_ ]);
}

sub destroy_
{
    my $self = shift;

    delete($self->{'pathman'});

    return 0;
}

sub duplicate
{
     my $self = shift;

     my $ptr = $self->{'pathman'}->get_root_pointer();

     $ptr->cd($self->pwd());

     return $ptr;
}

sub clone
{
    my $self = shift;

    return $self->duplicate();
}

sub atomic_cd
{
}

sub cd
{
    my $self = shift;

    my $path = shift;

    my $path_component;
    
    foreach $path_component (@{$path})
    {
        $self->atomic_cd($path_component);
    }
}
