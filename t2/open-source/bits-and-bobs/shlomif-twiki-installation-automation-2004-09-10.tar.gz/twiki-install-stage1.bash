#!/bin/bash

source twiki-install-common.bash

rm -fr "$dest_dir"
mkdir "$dest_dir"

function subst_var()
{
    var_name="$1"
    value="$2"
    perl -pi~ -e 's{\".*?\"}{\"'"$value"'\"} if m{^\$'"$var_name"'}' "$dest_dir/lib/TWiki.cfg"
}

cp -R "$source_dir"/* "$dest_dir"

adjust_permissions

(cd "$dest_dir" ;
    (
        cd data &&
        perl -pi~ -e 's/nobody:/'"$httpd_user"':/' */*,v
    )
)

subst_var "defaultUrlHost" "$httpd_default_url"
subst_var "scriptUrlPath" "/${www_base}/bin"
subst_var "pubUrlPath" "/${www_base}/pub"
subst_var "pubDir" "${dest_dir}/pub"
subst_var "templateDir" "${dest_dir}/templates"
subst_var "dataDir" "${dest_dir}/data"

