package Gamla::Web::PathMan::Perl::Pointer;

use strict;

use Gamla::Web::PathMan::Pointer::WithMount;

use vars qw(@ISA);

@ISA=qw(Gamla::Web::PathMan::Pointer::WithMount);

sub is_mounting_point
{
    my $self = shift;

    my $cur_dir = $self->{'cur_dir'};

    return $cur_dir->{'is_mounted'};
}

sub get_mounted_pathman_pointer
{
    my $self = shift;

    my $cur_dir = $self->{'cur_dir'};

    return $cur_dir->{'mounted_pathman'}->get_base_pointer();
}

sub get_mounted_pathman_path_to_start_from
{
    my $self = shift;

    my $cur_dir = $self->{'cur_dir'};

    return [ @{$cur_dir->{'mounted_start_path'}} ];
}

sub dir_exists
{
    my $self = shift;

    my $subdir_name = shift;

    my $cur_dir = $self->{'cur_dir'};

    return exists($cur_dir->{'subdirs'}->{$subdir_name});
}

sub local_mkdir
{
    my $self = shift;

    my $subdir_name = shift;

    my $cur_dir = $self->{'cur_dir'};

    $cur_dir->{'subdirs'}->{$subdir_name} = 
    {
        '..' => $cur_dir,
        'is_mounted' => 0,
        'attrbs' => {},
        'subdirs' => {},
    };

    return 0;
}
