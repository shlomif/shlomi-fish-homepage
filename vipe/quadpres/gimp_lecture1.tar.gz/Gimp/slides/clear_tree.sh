#!/bin/bash
rm -fr ~/public_html/lecture/Gimp/1/slides
