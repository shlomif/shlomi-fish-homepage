
package MyTable;

use strict;

# The default SPEC file.
use MyTable::SPEC;


# Sets the references to the other classes.
sub initialize
{
    my $self = shift;

    $self->set_types_manager(shift(@_));

    $self->set_sql_connection(shift(@_));

    $self->set_ui(shift(@_));

    $self->set_spec( shift(@_) || MyTable::SPEC::get_spec() );

    # Initialize the main sequence
    $self->init_main_sequence();
}

# Release references to other objects
sub destroy_
{
    my $self = shift;

    $self->{'sql_conn'}->end_sequence($self->{'main_seq'});

    $self->set_types_manager(undef);

    $self->set_sql_connection(undef);

    $self->set_ui(undef);

    $self->set_spec(undef);    
}

# $editor = MyTable->new($types, $sql_conn, $ui, $spec);
#
# $types - the types manager
# $sql_conn - a pre-opened SQL connection
# $ui - the user-interface handle
# $spec - the spec file (optional)
#
# All of the above have to be created and intiailized before the table editor
# can be created.
sub new
{
    my $class = shift(@_);
    my $self = {};
    bless $self, $class;

    $self->initialize(@_);

    return $self;
}

# Do not call this method in the middle of a user-interface functionality.
sub set_ui
{
    my $self = shift;

    my $ui = shift;

    $self->{'ui'} = $ui;
}

# Sets the SPEC, and initializes the values hash.
sub set_spec
{
    my $self = shift;
    my $spec = shift;
    
    $self->{'spec'} = $spec;

    my (%values, $a, $field);

    for($a=0 ; $a<scalar(@{$spec->{'fields'}}) ; $a++)
    {
        $field = $spec->{'fields'}->[$a];
        $values{$field->{'name'}} =
        {            
            'value' => undef,
            'changed' => 0,       # 0 - means unchanged, 1 - changed
        };
    }
    
    $self->{'values'} = \%values;
}

sub set_sql_connection
{
    my $self = shift;

    my $sql_connection = shift;

    $self->{'sql_conn'} = $sql_connection;
}

sub set_types_manager
{
    my $self = shift;

    $self->{'types'} = shift;
}

sub init_main_sequence
{
    my $self = shift;

    my $spec = $self->{'spec'};
    my $sql_conn = $self->{'sql_conn'};

    my ($a, @pkey_fields, $field_record);

    # Prepare a primary key fields array for the sequence. It will then be
    # used exclusively by the sequence.
    for($a=0;$a<scalar(@{$spec->{'primary_key'}});$a++)
    {
        $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$spec->{'primary_key'}->[$a]}];
        push @pkey_fields,
        {
            'name' => $field_record->{'name'},
            'type' => $field_record->{'type'},
            'type_params' => $field_record->{'type_params'},
        };
    }

    # Generate the WHERE clause from the filters
    #
    # Right now there's only one, but someday there may be user-specified filters.

    my ($where_clause, @filters);

    $where_clause = '';

    if ($spec->{'filter'})
    {
        push @filters, $spec->{'filter'};
    }

    $where_clause = join(" AND ", (map { "(" . $_ . ")"; } @filters));

    # Consult the module Arad::SQL::Base for details
    $self->{'main_seq'} =
        $sql_conn->create_sequence(
                               $spec->{'table_name'},
                               \@pkey_fields,
                               $where_clause,
                               $spec->{'order_by'}
                                  );

    $self->{'main_seq_size'} = $sql_conn->get_sequence_num_records($self->{'main_seq'});

    # Load the first record in the sequence.
    $self->load_record_by_sequence_pos(0);
}

# ($error_code, $error_str) = $editor->load_record_by_sequence_pos($pos)
#
# Loads the record in position No. $pos in the sequence.
#
# $error_code:
# 0 - success
# 0x200 | $ret - raw_load_record() failed. $ret is its return value.
sub load_record_by_sequence_pos
{
    my $self = shift;
    my $pos = shift;

    my $spec = $self->{'spec'};
    my $sql_conn = $self->{'sql_conn'};
    my $types = $self->{'types'};

    if ($pos >= $self->{'main_seq_size'})
    {
        $pos = $self->{'main_seq_size'} - 1;
    }
    elsif ($pos < 0)
    {
        $pos = 0;
    }

    my (@sql_values, $a, %pkey, $field_record, @ret);

    # Prepare a hash containing the values of the primary key fields in that
    # position.

    @ret = $sql_conn->get_sequence_at_pos($self->{'main_seq'}, $pos);

    @sql_values = @{$ret[0]};

    for($a=0;$a<scalar(@{$spec->{'primary_key'}});$a++)
    {
        $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$spec->{'primary_key'}->[$a]}];

        $pkey{$field_record->{'name'}} = $types->convert_from_sql($field_record->{'type'}, $field_record->{'type_params'}, $sql_values[$a]);
    }

    # Load the record according to the primary key values of the position
    @ret = $self->raw_load_record(\%pkey);
    if ($ret[0] != 0)
    {
        return (0x200 | $ret[0], $ret[1]);
    }    
    $self->{'main_seq_pos'} = $pos;
    $self->{'out_of_seq'} = 0;

    return (0,"");
}


# ($error_code, $error_str) = $editor->load_record_by_primary_key(\%primary_key)
#
# Loads a record according the values of the primary key. The keys of
# %primary_key are the ids of the fields of the primary key and the values
# are their corresponding values.
#
# $error_code:
# 0 - success
# 1 - could not find a record with the given primary keys.
# 0x200 | $ret - raw_load_record() failed with $ret as its return value.
sub load_record_by_primary_key
{
    my $self = shift;
    my $primary_key = shift;

    my $spec = $self->{'spec'};
    
    my ($pos, $a, @values, $field_record, @ret);

    for($a=0;$a<scalar(@{$spec->{'primary_key'}});$a++)
    {
        $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$spec->{'primary_key'}->[$a]}];

        push @values, $primary_key->{$field_record->{'name'}};
    }

    $pos = $self->{'sql_conn'}->get_sequence_pos_from_values($self->{'main_seq'}, \@values, -1);

    if ($pos == -1)
    {
        return (1, "Could not find a record with the given primary keys.");
    }

    @ret = $self->raw_load_record($primary_key);
    if ($ret[0] != 0)
    {
        return (0x200 | $ret[0], $ret[1]);
    }
    $self->{'main_seq_pos'} = $pos;
    $self->{'out_of_seq'} = 0;    

    return (0,"");
}

# $editor->referesh_sequence($event);
#
# Refreshes the sequence after an event that could have changed it had occured.
# if $event is "save" then the record was saved.
# if $event is "delete" then the record was deleted.
sub refresh_sequence
{
    my $self = shift;
    my $event = shift;

    my $spec = $self->{'spec'};
    my $sql_conn = $self->{'sql_conn'};

    $sql_conn->refresh_sequence($self->{'main_seq'});

    $self->{'main_seq_size'} = $sql_conn->get_sequence_num_records($self->{'main_seq'});

    
    if ($event eq 'save')
    {
        my ($a, @values, $new_pos);

        for($a=0;$a<scalar(@{$spec->{'primary_key'}});$a++)
        {
            push @values, $self->{'values'}->{$spec->{'primary_key'}->[$a]}->{'value'};
        }

        
        $new_pos =
            $sql_conn->get_sequence_pos_from_values(
                                                    $self->{'main_seq'},
                                                    \@values,
                                                    ($self->{'main_seq_pos'})
                                                   );
        if ($new_pos == -1)
        {
            $self->{'out_of_sequence'} = 1;
        }
        else
        {
            $self->{'main_seq_pos'} = $new_pos;
        }
    }
    elsif ($event eq 'delete')
    {
        if ($self->{'main_seq_pos'} >= $self->{'main_seq_size'})
        {
            $self->{'main_seq_pos'} = ($self->{'main_seq_size'} - 1);
        }
    }

    return 0;
}

# $editor->next_or_prev_record($offset)
#
# Moves to the record $offset records after the current one. $offset can be
# negative in which case it moves to a previous record.
sub next_or_prev_record
{
    my $self = shift;
    my $offset = shift;

    return ($self->load_record_by_sequence_pos($self->{'main_seq_pos'}+$offset));
}

# Do not call this function directly as it is called from
# load_record_by_sequence_pos() and load_record_by_primary_key().
sub raw_load_record
{
    my $self = shift;

    my $primary_keys = shift(@_);

    my %pkeys = %{$primary_keys}; # The primary keys
    
    my $spec = $self->{'spec'};

    my $types = $self->{'types'};

    my $sql_conn = $self->{'sql_conn'};

    my $values = $self->{'values'};




    my ($select_clause, $where_clause, @where, $field, $value, @sql_value, $field_record);
    my (@ret);
    
    $select_clause = "SELECT " . join(",",
                                      (map
                                          {
                                              $_->{'name'};
                                          }
                                          @{$spec->{'fields'}}
                                         )
                                     );

    # Construct the "WHERE" clause
    while (($field, $value) = each(%pkeys))
    {
        $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$field}];

        @ret = $self->verify_field($field, $value);

        if ($ret[0] != 0)
        {
            return (0x100 | $ret[0], $ret[1]);
        }
        
        @sql_value = $types->convert_to_sql($field_record->{'type'}, $field_record->{'type_params'}, $value);

        push @where, ($field . "=" .
                             ( ($sql_value[0] & 0x1) ?
                               $types->quote_sql_value($sql_value[1]) :
                               $sql_value[1]
                             )
                     );
            
    }

    $where_clause = "WHERE " . join(" AND ", @where);

    my $query = $sql_conn->perform_select_query(
                                                $select_clause .
                                                " FROM " . $spec->{'table_name'} .
                                                " " . $where_clause
                                               );

    my (@new_values);
    
    @new_values = $sql_conn->get_query_row($query);

    $sql_conn->end_query($query);
    
    if (@new_values)
    {
        my ($a);
    
        for($a=0;$a<scalar(@{$spec->{'fields'}});$a++)
        {
            $field_record = $spec->{'fields'}->[$a];
            $self->{'values'}->{$field_record->{'name'}}->{'value'} =
                  $types->convert_from_sql($field_record->{'type'}, $field_record->{'type_params'}, $new_values[$a]);
    
            $self->{'values'}->{$field_record->{'name'}}->{'changed'} = 0;        
        }

        return (0, "");
    }
    else
    {
        return (1, "Could not find a record with the given primary keys");
    }    
}
# Returns:
# ($error_code, $error_string) = $self->raw_load_record(...);
# 0 - OK
# 1 - could not find a record with the given primary keys.
# 0x100 | $field_verify_code - a field verification test has failed
#                              for one of the primary keys.

# Changes "$F" in the string to the name of the field.
sub process_field_error_string
{
    my $self = shift;

    my $error_string = shift;

    my $field_name = shift;

    $error_string =~ s!\$F!$field_name!g;

    return $error_string;
}

# ($error_code, $error_string) = $editor->verify_field($field_name, $field_value)
#
# Verifies that the field value is OK. 
sub verify_field
{
    my $self = shift;

    my $field_name = shift;
    my $field_value = shift;


    my $spec = $self->{'spec'};
        

    my $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$field_name}];

    my $types = $self->{'types'};

    my ($error_val, @ret);

    @ret = $types->check_value($field_record->{'type'}, $field_record->{'type_params'}, $field_value);

    if ($ret[0] != 0)
    {
        return (1, $self->process_field_error_string($ret[1], $field_name) );
    }

    if (exists($field_record->{'verify_func'}))
    {
        @ret = &{$field_record->{'verify_func'}}(
                                                 $self,
                                                 $field_name,
                                                 $field_value
                                                );

        if ($ret[0] != 0)
        {
            return (2, $self->process_field_error_string($ret[1], $field_name) );
        }
    }

    # TO DO: Add extra field verification code here

    return (0, "");    
}
# Returns:
# ($error_code, $error_string) = $self->verify_field(...)
# $error_code values:
#   0 - OK.
#   1 - Failed because of incorrect value for that data type
#   2 - Failed because of the field verification function
#   3-255 - Failed because of user-added tests

# Right now just returns the string as it is. But there may be more in the
# future.
sub process_record_error_string
{
    my $self = shift;

    my $error_string = shift;

    return $error_string;
}


sub verify_record
{
    my $self = shift;

    my $spec = $self->{'spec'};

    my ($a, @ret, $field_record);


    # Scan through all the fields and verify them.
    for ($a=0 ; $a < scalar( @{$spec->{'fields'}} ) ; $a++)
    {
        $field_record = $spec->{'fields'}->[$a];
        if ( ($field_record->{'flags'} !~ /read-only/) )
        {
            @ret = $self->verify_field(
                                       $field_record->{'name'},
                                       $self->{'values'}->{$field_record->{'name'}}->{'value'},
                                      );

            if ($ret[0] != 0)
            {
                return (0x100 | $ret[0], $self->process_field_error_string($ret[1]));
            }
        }
    }

    if (exists($spec->{'record_verify_func'}))
    {
        @ret = &{$spec->{'record_verify_func'}}(
                                                $self
                                               );

        if ($ret[0] != 0)
        {
            return (1, $self->process_record_error_string($ret[1]));
        }
                                                     
    }

    # TO DO: Add extra record verification code here:


    return (0, "");
}
# Returns:
# ($error_code, $error_string) = $self->verify_record();
#
# $error_code values:
# 0 - OK
# 0x100 | $field_error_code - Failed because of a field test.
# 1 - Failed because of the spec's verification function
# 2-255 - Failed because of user-added tests


# ($error_code, $errot_string) = $editor->save_record($flags);
#
# Saves the current record. $flags is a comma separated list of options.
# Currently supported options:
# only-changed : save only the fields that were changed into the database.
#
# $error_code values:
# 0 - success
# 0x200 | $ret - verify_record() failed and returned $ret. 
sub save_record
{
    my $self = shift;

    my $flags = shift;    

    my $save_all = 1;
    if ($flags =~ /only-changed/)
    {
        $save_all = 0;
    }

    # Verify that the record is OK.
    {
        my @verify = $self->verify_record();

        if ($verify[0])
        {
            return (0x200 | $verify[0], $verify[1]);
        }
    }

    

    my $spec = $self->{'spec'};
    
    my $types = $self->{'types'};

    my $sql_conn = $self->{'sql_conn'};
    

    my ($where_clause, @where, $field, $value, @sql_value, $field_record);

    # Construct the WHERE clause according to the values of the primary key.
    foreach $field (@{$spec->{'primary_key'}})
    {
        $value = $self->{'values'}->{$field}->{'value'};
            
        $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$field}];
        @sql_value = $types->convert_to_sql($field_record->{'type'}, $field_record->{'type_params'}, $value);

        push @where, ($field . "=" .
                             ( ($sql_value[0] & 0x1) ?
                               $types->quote_sql_value($sql_value[1]) :
                               $sql_value[1]
                             )
                     );
            
    }

    $where_clause = join(" AND ", @where);

    my (%values_to_update, $a);

    # Prepare a values hash for passing into perform_update_transaction()
    for ($a=0 ; $a < scalar( @{$spec->{'fields'}} ) ; $a++)
    {
        $field_record = $spec->{'fields'}->[$a];
        if ( ($field_record->{'flags'} !~ /read-only/) &&
             ($save_all ||
                        ($self->{'values'}->{$field_record->{'name'}}->{'changed'})
             )
           )
        {
            $values_to_update{$field_record->{'name'}} =
            [ $types->convert_to_sql(
                                     $field_record->{'type'},
                                     $field_record->{'type_params'},
                                     $self->{'values'}->{$field_record->{'name'}}->{'value'}
                                    )
            ];
        }
    }

    # Consult the notes at Arad::SQL::DBI for information about this function.
    my @ret = $sql_conn->perform_update_transaction($spec->{'table_name'}, \%values_to_update, $where_clause);

    if ($ret[0])
    {
        return (0x400 | $ret[0], $ret[1]);
    }

    # Set the changed status of the fields to 0.
    for($a=0;$a<scalar(@{$spec->{'fields'}});$a++)
    {
        $field_record = $spec->{'fields'}->[$a];

        $self->{'values'}->{$field_record->{'name'}}->{'changed'} = 0;        
    }

    $self->refresh_sequence('save');

    return (0, "");
}

# Get the value of a field for a "new record" operation
sub get_field_from_user
{
    my $self = shift;
    my $field_name = shift;

    my $spec = $self->{'spec'};
    my $types = $self->{'types'};
    my $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$field_name}];

    my ($raw_value, @ret);

    do
    {        
        if ($self->{'dialog'})
        {
            $raw_value = $self->{'dialog'}->get_field_from_user($field_name);
        }
        else
        {
            $raw_value = $self->{'ui'}->get_field_from_user($field_name);
        }
    
        @ret = $self->verify_field($field_name, $raw_value);
        if ($ret[0] != 0)
        {
            if ($self->{'dialog'})
            {
                $self->{'dialog'}->notify_user("Illegal value for that field. " . $ret[1]);
            }
            else
            {
                $self->{'ui'}->notify_user("Illegal value for that field. " . $ret[1]);
            }        
        }
    } while ($ret[0] != 0);

    return $raw_value;

}

# ($error_code, $error_string) = $editor->new_record()
# Creates a new "empty" record.
sub new_record
{
    my $self = shift;

    my $spec = $self->{'spec'};
    my $types = $self->{'types'};

    my ($a, $field_record, %values, %sql_values, $field);

    for($a=0;$a<scalar(@{$spec->{'fields'}});$a++)
    {
        $field_record = $spec->{'fields'}->[$a];

        if (1) #if ($field_record->{'flags'} =~ /read-only/)
        {
            if ($field_record->{'on_new'} eq 'default_value')
            {
                # This field has a default value in the SPEC file.
                $values{$field_record->{'name'}} = $field_record->{'default_value'};                
            }
            elsif ($field_record->{'on_new'} eq 'input')
            {
                # This field wishes to be inputted from the user.
                $values{$field_record->{'name'}} = $self->get_field_from_user($field_record->{'name'});
            }
            elsif (ref($field_record->{'on_new'}) eq 'CODE')
            {
                # This field has a function that retrieves its new value
                $values{$field_record->{'name'}} =
                    &{$field_record->{'on_new'}} ($self, $field_record->{'name'}, \%values);
            }
        }
    }

    # Prepare the values hash for perform_insert_transaction();
    foreach $field (keys(%values))
    {
        $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$field}];
        $sql_values{$field} = [
                           $types->convert_to_sql(
                                                  $field_record->{'type'},
                                                  $field_record->{'type_params'},
                                                  $values{$field}
                                    )
            ];
    }

    my @ret = $self->{'sql_conn'}->perform_insert_transaction($spec->{'table_name'}, \%sql_values);

    if ($ret[0] != 0)
    {
        return (0x100 | $ret[0], $ret[1]);
    }

    # Load the newly created record.
    my (%pkey_values);

    for($a=0;$a<scalar(@{$spec->{'primary_key'}});$a++)
    {
        $pkey_values{$spec->{'primary_key'}->[$a]} = $values{$spec->{'primary_key'}->[$a]};
    }

    $self->refresh_sequence('new');
    
    @ret = $self->load_record_by_primary_key(\%pkey_values);

    if ($ret[0] != 0)
    {
        return (0x200 | $ret[0], $ret[1]);
    }

    return (0, "");
}

# ($error_code, $error_string) = $editor->delete_record();
#
# Deletes the current record.
sub delete_record
{
    my $self = shift;

    my $spec = $self->{'spec'};
    my $types = $self->{'types'};

    my ($where_clause, @where, $field, $value, @sql_value, $field_record);
    
    # Construct the WHERE clause according to the primary key values.
    foreach $field (@{$spec->{'primary_key'}})
    {
        $value = $self->{'values'}->{$field}->{'value'};
            
        $field_record = $spec->{'fields'}->[$spec->{'fields_index'}->{$field}];
        @sql_value = $types->convert_to_sql($field_record->{'type'}, $field_record->{'type_params'}, $value);

        push @where, ("(" . $field . "=" .
                             ( ($sql_value[0] & 0x1) ?
                               $types->quote_sql_value($sql_value[1]) :
                               $sql_value[1]
                             ) . ")"
                     );
            
    }

    $where_clause = join(" AND ", @where);

    my @ret = $self->{'sql_conn'}->perform_delete_transaction($spec->{'table_name'}, $where_clause);

    if ($ret[0] != 0)
    {
        return (0x100 | $ret[0], $ret[1]);
    }

    $self->refresh_sequence('delete');

    $self->load_record_by_sequence_pos($self->{'main_seq_pos'});

    return (0, "");    
}

# $field_value = $editor->get_field_value($field_name)
#
# Returns the value of the field $field_name
sub get_field_value
{
    my $self = shift;

    my $field_name = shift;

    return $self->{'values'}->{$field_name}->{'value'};
}

# ($error_code, $error_string) = $editor->set_field_value($field_name, $new_value);
#
# Sets the value of the field $field_name to $new_value
sub set_field_value
{
    my $self = shift;
    my $field_name = shift;
    my $new_value = shift;

    my $spec = $self->{'spec'};

    my (@ret);

    if (!exists($spec->{'fields_index'}->{$field_name}))
    {
        return (1, "The field " . $field_name . " does not exist.");
    }

    if ($spec->{'fields'}->[$spec->{'fields_index'}->{$field_name}]->{'flags'} =~ /read-only/)
    {
        return (2, "Cannot write to the field " . $field_name . ".");
    }

    @ret = $self->verify_field(
                               $field_name,
                               $new_value,
                              );

    if ($ret[0] != 0)
    {
        return (0x100 | $ret[0], $self->process_record_error_string($ret[1]));
    }

    $self->{'values'}->{$field_name}->{'value'} = $new_value;
    $self->{'values'}->{$field_name}->{'changed'} = 1;
    
    return (0, "");    
}

# Returns:
# ($error_code, $error_string)
#
# 0 - OK.
# 1 - A field by that name does not exist.
# 2 - The field cannot be written to.
# 0x100 | $verify_return - The value is illegal

# returns the position of the current record.
sub get_record_position
{
    my $self = shift;
    
    if ($self->{'out_of_seq'})
    {
        return -1;
    }
    else
    {
        return $self->{'main_seq_pos'};
    }
}


# $ret = $editor->is_readonly($field_name);
#
# $ret is non-zero if $field_name is a read only field.
sub is_readonly
{
    my $self = shift;
    my $field_name = shift;

    my $spec = $self->{'spec'};

    if (exists($spec->{'fields_index'}->{$field_name}))
    {
        return ($spec->{'fields'}->[$spec->{'fields_index'}->{$field_name}]->{'flags'} =~ /read-only/);
    }

    return 0;
}

# $primary_key = $editor->get_primary_key();
#
# $primary_key is a reference to an array that contains the fields that compose
# the table's primary key.
sub get_primary_key
{
    my $self = shift;

    my $spec = $self->{'spec'};

    return [ @{$spec->{'primary_key'}} ];
}

# $table_name = $editor->get_table_name()
#
# Returns the name of the table
sub get_table_name
{
    my $self = shift;

    my $spec = $self->{'spec'};

    return $spec->{'table_name'};
}

# Returns whether or not the record was changed since it was loaded.
sub has_record_changed
{
    my $self = shift;

    my ($field_name, $values);
    $values = $self->{'values'};
    foreach $field_name (keys(%{$values}))
    {
        if ($values->{$field_name}->{'changed'})
        {
            return 1;
        }
    }

    return 0;
}

# $editor->create_dialog($options)
#
# Creates a dialog for editing the table and invokes the dialog loop. Passes
# $options to the dialog.
sub create_dialog
{
    my $self = shift;

    my $options = shift;

    my $spec = $self->{'spec'};

    my $dialog = $self->{'ui'}->create_new_dialog({ 'type' => 'table'}, $options);

    $self->{'dialog'} = $dialog;

    $dialog->set_table_editor($self);    

    my ($a);

    for($a=0;$a<scalar(@{$spec->{'fields'}});$a++)
    {
        $dialog->register_field_control(
                                        $spec->{'fields'}->[$a]->{'name'},
                                        { 'type' => 'text' }
                                        );
    }

    $dialog->dialog_loop();

    $dialog->destroy_();

    delete($self->{'dialog'});
}

1;