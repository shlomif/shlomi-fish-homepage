package MyTable::SPEC_emp2;

use strict;

sub fMyTable_OnNew
{
    my $self = shift;
    my $field_name = shift;
    my $prev_values = shift;

    if ($field_name eq 'employee_id')
    {
        my $sql_conn = $self->{'sql_conn'};
        my $query = $sql_conn->perform_select_query("SELECT employee_id FROM employees ORDER BY employee_id DESC");
        my @row = $sql_conn->get_query_row($query);
        $sql_conn->end_query($query);

        return ($row[0] ? ($row[0]+1) : 1);
    }
    else
    {
        return 0;
    }
}

sub fMyTable_Verify
{
    my $self = shift;
    my $field_name = shift;
    my $field_value = shift;

    if ($field_name ne 'first_name')
    {
        return (0,"");
    }
    if ($field_value !~ /^[A-Z][a-z]*$/)
    {
        return (1, "\$F must be a proper name.");
    }
    return (0, "");
}

sub fMyTable_RecordVerify
{
    my $self = shift;

    my $first_name = $self->get_field_value('first_name');
    my $last_name = $self->get_field_value('last_name');

    if (substr($first_name,0,1) ne substr($last_name,0,1))
    {
        return (1, "The first name and the last name must begin with the same letter.");
    }

    return (0,"");
}

sub generate_spec
{
    my $spec =
    {
        'table_name' => 'emp2',
        'fields' =>
        [
             {
                 'name' => 'department',
                 'type' => 'varchar',
                 'type_params' => { 'len' => 30 },
                 'flags' => 'read-only',
                 'on_new' => 'input',
             },         
             {
                 'name' => 'last_name',
                 'type' => 'varchar',
                 'type_params' => { 'len' => 30 },
                 'flags' => 'read-only',
                 'on_new' => 'input',
             },
             {
                 'name' => 'first_name',
                 'type' => 'varchar',
                 'type_params' => { 'len' => 30 },
                 #'verify_func' => \&fMyTable_Verify,
             },
             {
                 'name' => 'job',
                 'type' => 'varchar',
                 'type_params' => { 'len' => 30 },
             },
             {
                 'name' => 'hired_at',
                 'type' => 'date',
             },         
             {
                 'name' => 'employee_id',
                 'type' => 'int32',
                 # 'on_new' => 'input', 
             },
             {
                 'name' => 'children_num',
                 'type' => 'int32',
                 # 'on_new' => 'input', 
             },
            ],
        'primary_key' => [ 'department', 'last_name' ],
        'order_by' => 'last_name, department',
        #'filter' => "last_name LIKE 'F%'",
        #'record_verify_func' => \&fMyTable_RecordVerify,
    };

    return $spec;
}

sub init_spec
{
    my $spec = shift;
    # Generate an index to the fields

    my (%index);

    my $a;

    for($a=0;$a<scalar(@{$spec->{'fields'}});$a++)
    {
        $index{$spec->{'fields'}->[$a]->{'name'}} = $a;

        if (!exists($spec->{'fields'}->[$a]->{'flags'}))
        {
            $spec->{'fields'}->[$a]->{'flags'} = "";
        }
    }

    $spec->{'fields_index'} = \%index;

    return 0;
}

sub get_spec
{
    my $spec = generate_spec();
    init_spec($spec);
    
    return $spec;
}

1;
