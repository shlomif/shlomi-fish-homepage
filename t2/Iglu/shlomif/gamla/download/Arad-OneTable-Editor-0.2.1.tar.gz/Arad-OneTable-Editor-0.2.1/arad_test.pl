#!/usr/bin/perl

use strict;

use Arad::Types;
use Arad::Utils;

my $types = new Arad::Types;

#print join(" - ", $types->check_value('int32', {}, 65)), "\n";
#print join(" - ", $types->check_value('int32', {}, "abc")), "\n";
#print join(" - ", $types->check_value('int16', {}, 100000)), "\n";
#print join(" - ", $types->check_value('varchar', { 'len' => 6}, "hello world")), "\n";
#print join(" - ", $types->compare_values('date', {}, '1996-09-08', '1996-10-03')), "\n";

print join(" - ", $types->check_value('int64', {}, "-567")), "\n";
print join(" - ", $types->compare_values('int64', {}, "-812347293847293847", "-7123821381723897983" )), "\n";

#print join(" - ", $types->check_value('time', {}, "11:34:90-")), "\n";
#print join(" - ", $types->convert_to_sql('time', {}, "11:25")), "\n";
