load_common mymake
load_common completion

base="$HOME/Docs/IGLU/Welcome-to-Linux"
trunk="$base/trunk"

this="$trunk"
cd $this

