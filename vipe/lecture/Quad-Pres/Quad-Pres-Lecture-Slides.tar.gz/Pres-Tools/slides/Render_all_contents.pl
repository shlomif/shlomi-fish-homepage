#!/usr/bin/perl

use Contents;

use strict;

my %targets =
    (
        'home' =>
            {
                'render_type' => "server",
                'default_dest_dir' => "/var/www/html/shlomi/perl-mongers/lecture/Quad-Pres/slides/",
            },
    );

my $the_target = shift || "home";

if (!exists($targets{$the_target}))
{
    die "Unknown Target \"$the_target\"!\n";
}

my $default_dest_dir = $targets{$the_target}->{'default_dest_dir'};
my $render_type = $targets{$the_target}->{'render_type'};
#my $default_dest_dir = "./rendered/";
#my $default_dest_dir = $ENV{'HOME'} . "/public_html/lecture/Perl/Newbies/lecture1/";

my $contents = Contents::get_contents();

my $src_dir = "./src/";
my $dest_dir = shift || $default_dest_dir;

if ($src_dir !~ /\/$/)
{
    $src_dir .= "/";
}
if ($dest_dir !~ /\/$/)
{
    $dest_dir .= "/";
}

my $render_all_non_leafs = 0;
{
    my @src_stat = stat("Contents.pm");
    my @src2_stat = stat("./src/template.wml");
    my @dest_stat = stat($dest_dir."/"."index.html");
    if (($src_stat[9] > $dest_stat[9]) || 
        ((-e "./src/template.wml") && ($src2_stat[9] > $dest_stat[9]))
       )
    {
        $render_all_non_leafs = 1;
    }
}


sub traverse
{
    my $path_ref = shift;
    my $branch = shift;

    my (@path);

    @path = @{$path_ref};

    my $p = join("/", @path);

    my ($filename, $src_filename);

    my $is_dir = exists($branch->{'subs'});

    if ($is_dir)
    {
        # It is a directory
        $filename = ($dest_dir . "/" . $p);
        if (! (-d $filename))
        {
            mkdir($filename, 0777);
        }
        $filename .= "/index.html";
        $src_filename = $src_dir . "/" . $p . "/index.html";
    }
    else
    {
        $filename = ($dest_dir . "/" . $p);
        $src_filename = $src_dir . "/" . $p;
    }
    $src_filename .= ".wml";
    # Automatically copy the template to the source filename
    if (! -e $src_filename)
    {
        if ($is_dir)
        {
            my $dir_name = $src_filename;
            $dir_name =~ s/\/*index\.html\.wml$//;
            mkdir($dir_name, 0777);
        }
        
        open I, "<src/template.html.wml";
        open O, (">" . $src_filename);
        binmode(I);
        binmode(O);
        print O join("", <I>);
        close(O);
        close(I);
    }
    my @src_stat = stat($src_filename);
    my @dest_stat = stat($filename);
    if ((! -e $filename) || 
        ($src_stat[9] > $dest_stat[9]) || 
        ($render_all_non_leafs && (exists($branch->{'subs'})))
        )
    {
        my $src_filename_modified = $src_filename;
        $src_filename_modified =~ s/^(.\/)?src\/*//;
        my $cmd = "cd src && ../wml_render_file.sh \"" . 
            $src_filename_modified . 
            "\" | ../fix-gvim-html.pl > \"" . $filename . "\"\n";
            
            
        print $cmd, "\n";
        system($cmd);

    }

    if (exists($branch->{'images'}))
    {
        foreach my $image (@{$branch->{'images'}})
        {
            $filename = $dest_dir . "/" . $p . "/" . $image ;
            $src_filename = $src_dir . "/" . $p . "/" . $image ;

            my @src_stat = stat($src_filename);
            my @dest_stat = stat($filename);
            if ((! -e $filename) || 
                ($src_stat[9] > $dest_stat[9])
                )
            {
                open I, ( "<" . $src_filename);
                open O, ( ">" . $filename);
                binmode(I);
                binmode(O);
                print O join("",<I>);
                close(O);
                close(I);        
            }
        }
    }

    if (exists($branch->{'subs'}))
    {
        # Let's traverse all the directories
        foreach my $sub_branch (@{$branch->{'subs'}})
        {
            &traverse(
                [ @path, $sub_branch->{'url'} ],
                $sub_branch
                );
        }
    }

}

&traverse([], $contents);


