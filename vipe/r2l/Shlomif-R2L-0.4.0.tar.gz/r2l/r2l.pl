#!/usr/bin/perl

use Getopt::Long;

use Gtk;
use Shlomif::R2L::Gui;

my $filename = "";
my $poll_time = "";
$result = GetOptions ('filename=s' => \$filename, 'poll-time=f' => \$poll_time);

if ($filename eq "")
{
    $filename = $ENV{'HOME'} . "/" . ".r2l";
}

# If poll_time is "" it will be considered as the default
my $gui = Shlomif::R2L::Gui->new($filename, $poll_time);

Gtk->init();

$gui->run();

Gtk->main();


