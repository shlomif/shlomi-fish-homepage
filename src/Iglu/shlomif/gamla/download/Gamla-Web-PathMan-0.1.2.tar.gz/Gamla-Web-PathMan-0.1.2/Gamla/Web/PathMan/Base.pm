package Gamla::Web::PathMan::Base;

use strict;

use Gamla::Object;

use vars qw(@ISA);

@ISA=qw(Gamla::Object);

sub get_root_pointer
{
    my $self = shift;

    return undef;
}
