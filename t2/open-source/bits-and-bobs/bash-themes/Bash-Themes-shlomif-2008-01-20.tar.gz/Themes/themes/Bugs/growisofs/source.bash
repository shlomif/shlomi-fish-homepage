load_common mymake
load_common completion
# load_common gen_patch
base="/home/shlomi/conf/bugs/growisofs-unresponsive"
this="$base"
gitdir="$HOME/Download/unpack/kernel/from-git/linux-2.6"
bug_conf_file="$base/config-kernel"
local_conf_file="$gitdir/.config"

go2git()
{
    cd "$gitdir"
}

put_conf()
{
    (
        go2git
        cp -f "$bug_conf_file" "$local_conf_file"
        yes "" | make oldconfig
    )
}

diff_conf()
{
    (
        go2git
        diff -u "$bug_conf_file" "$local_conf_file"
    )
}

e()
{
    (
        cd "$this"
        gvim bisecting-notes.txt
    )
}

cd "$this"
