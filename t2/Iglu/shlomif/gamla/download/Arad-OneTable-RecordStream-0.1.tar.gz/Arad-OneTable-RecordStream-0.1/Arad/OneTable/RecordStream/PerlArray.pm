# Arad::OneTable::RecordStream::PerlArray - a stream of records that reads
# from a standard perl array.
#
# Usage:
#
# my $stream = Arad::OneTable::RecordStream::PerlArray->new(\@array);
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
# This code is under the public domain.

package Arad::OneTable::RecordStream::PerlArray;

use strict;

use Arad::OneTable::RecordStream;

use vars qw(@ISA);

@ISA=qw(Arad::OneTable::RecordStream);

sub initialize
{
    my $self = shift;

    my $array_ref = shift;
    $self->{'array'} = $array_ref;
    
    $self->{'pos'} = 0;
    
    return $self;
}

sub destroy_
{
    my $self = shift;
    
    delete($self->{'array'});
}

sub get_next_record
{
    my $self = shift;
    
    my $pos = $self->{'pos'};
    my $array_ref = $self->{'array'};
    my $ret;
    
    if ($pos >= scalar(@{$array_ref}))
    {
        $ret = undef;
    }
    else
    {
        $ret = $array_ref->[$pos];
        $self->{'pos'}++;
    }
    
    return $ret;
}

sub skip
{
    my $self = shift;

    my $how_many = shift;
    
    $self->{'pos'} += $how_many;
    
    return $self;
}