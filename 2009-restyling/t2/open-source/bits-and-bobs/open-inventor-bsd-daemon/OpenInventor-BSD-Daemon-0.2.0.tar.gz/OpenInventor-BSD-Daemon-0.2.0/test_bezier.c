#include <stdio.h>
#include <stdlib.h>

#include "polynom.h"

int main(int argc, char * argv[])
{
    float p1_coeffs[4] = {10, 3, 4, 3};
    float p2_coeffs[2] = {1, 2};

    polynom_t * p1, * p2, * sum;
    int i;

    p1 = polynom_alloc(sizeof(p1_coeffs)/sizeof(p1_coeffs[0]), p1_coeffs);
    p2 = polynom_alloc(sizeof(p2_coeffs)/sizeof(p2_coeffs[0]), p2_coeffs);

    sum = polynom_mult(p1, p2);

    for(i=0;i<sum->num_points;i++)
    {
        printf("sum[%i] = %f\n", i, (double)sum->coeffs[i]);
    }

    return 0;
    
}

