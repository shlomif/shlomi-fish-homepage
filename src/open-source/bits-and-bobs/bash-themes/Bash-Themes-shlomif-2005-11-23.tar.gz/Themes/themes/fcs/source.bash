load_common mymake

this="/home/shlomi/progs/freecell/trunk/fc-solve/source"
site="/home/shlomi/progs/freecell/trunk/fc-solve/site/wml"

cd $this

