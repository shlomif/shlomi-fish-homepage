# Arad::UI::TableEditDialog - The base class for the table-editor dialogs of
# the various user-interfaces.
#
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)


package Arad::UI::TableEditDialog;

use strict;

use Arad::Utils;

sub initialize
{
    my $self = shift;

    my $ui = shift;

    $self->{'ui'} = $ui;

    $self->{'fields'} = [];

    $self->{'fields_index'} = {};
}

sub new
{
    my $class = shift(@_);
    my $self = {};
    bless $self, $class;

    $self->initialize(@_);

    return $self;
}

sub set_table_editor
{
    my $self = shift;

    my $table_editor = shift;

    $self->{'editor'} = $table_editor;
}

sub destroy_
{
    my $self = shift;

    $self->{'editor'} = undef;
    $self->{'ui'} = undef;
}

sub register_field_control
{
    my $self = shift;

    my $field_name = shift;
    my $control_type = shift;

    # The only one we can handle so far
    if ($control_type->{'type'} eq 'text')
    {
        push @{$self->{'fields'}}, { 'name' => $field_name, 'type' => $control_type };
        $self->{'fields_index'}->{$field_name} = scalar(@{$self->{'fields'}}) - 1;
    }
}

sub dialog_loop
{
    my $self = shift;
   
    return 0;
}

sub message_box
{
    my $self = shift;

    my $text = shift;
    my $type = shift;
    my $handle = shift;

    return $self->{'ui'}->message_box($text, $type, $handle);    
}

1;

