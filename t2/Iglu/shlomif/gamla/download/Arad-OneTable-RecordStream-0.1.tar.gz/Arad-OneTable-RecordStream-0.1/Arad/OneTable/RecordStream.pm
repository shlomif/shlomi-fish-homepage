# Arad::OneTable::RecordStream - a base class for single-table sequential
# record streams.
#
# Usage:
# my $stream = [ Stream Specific constructor ]
#
# while ($record = $stream->get_next_record())
# {
#   ... 
# }
#
# $stream->skip(5);  # To skip 5 records
# 
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
# This code is under the public domain.

package Arad::OneTable::RecordStream;

use strict;

sub initialize
{
    # Nothing to initialize here.
}

sub destroy_
{
}

sub new
{
    my $class = shift;

    my $self = {};

    bless($self, $class);

    $self->initialize(@_);

    return $self;    
}

sub DESTROY
{
    my $self = shift;

    $self->destroy_();
}

sub get_next_record
{
}

sub skip
{
    my $self = shift;

    my $how_many = shift;

    my $a;

    for($a=0 ; $a<$how_many ; $a++)
    {
        $self->get_next_record();
    }

    return 0;
}

1;