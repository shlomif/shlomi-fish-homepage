#!/bin/bash
FILENAME="$1"
FILENAME=$(echo $FILENAME | 
    sed 's/\.wml$//' |
    sed 's/\/$/index.html/'
    )

exec wml --passoption=2,-X -DFILENAME="$FILENAME" "$FILENAME.wml"

