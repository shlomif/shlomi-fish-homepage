load_common mymake

this="$HOME/Docs/Philosophy/Solving/site/trunk"

cd $this

