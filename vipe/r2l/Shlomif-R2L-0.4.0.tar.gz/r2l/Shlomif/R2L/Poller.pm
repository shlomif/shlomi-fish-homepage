package Shlomif::R2L::Poller;

use strict;

sub new
{
    my $class = shift;
    my $self = {};

    bless $self, $class;

    $self->{'status'} = 0;
    $self->{'status_sub'} = 0;

    $self->initialize(@_);

    return $self;
}

sub initialize
{
    # Do nothing

    # This is not exactly an abstract function, but then again I don't 
    # have anything to do here.
}

sub get_status
{
    my $self = shift;
    
    return [$self->{'status'}, $self->{'status_sub'}];
}

sub enable
{
    my $self = shift;
   
    # proto_enable does the actual enabling. It should be overriden by
    # the class that inherits us.
    $self->proto_enable();
    $self->{'status'} = 1;
}

sub proto_enable
{
    # Do Nothing
}

sub disable
{
    my $self = shift;
    
    # proto_disable does the actual disabling. It should be overriden by
    # the class that inherits us.
    $self->proto_disable();
    $self->{'status'} = 0;
}

sub proto_disable
{
    # Do Nothing
}

sub enable_sub_
{
    my $self = shift;

    my ($status, $status_sub) = @ {$self->get_status() };

    # Makes no difference now.
    if (! $status)
    {
        return ;
    }
   
    # proto_enable does the actual enabling. It should be overriden by
    # the class that inherits us.
    $self->proto_enable_sub_();
    $self->{'status_sub'} = 1;
}

sub proto_enable_sub_
{
    # Do Nothing
}

sub disable_sub_
{
    my $self = shift;

    my ($status, $status_sub) = @ {$self->get_status() };

    # Makes no difference now.
    if (! $status)
    {
        return ;
    }
    
    # proto_disable does the actual disabling. It should be overriden by
    # the class that inherits us.
    $self->proto_disable_sub_();
    $self->{'status_sub'} = 0;
}

sub proto_disable_sub_
{
    # Do Nothing
}



sub switch
{
    my $self = shift;
   
    # I do not poll because the user wishes the state to change from what
    # he sees, not from what exists
    my ($status, $status_sub) = @ { $self->get_status() };

    if ($status)
    {
        if (! $status_sub)
        {
            $self->enable_sub_();
        }
        else # ($status_sub_)
        {    
            $self->disable();
        }
    }
    else # ! $status
    {
        $self->enable();
        $self->disable_sub_();
    }
}

# Polls the external value for an up-to-date value.
# Returns whether it was changed from the time of the last poll.
sub poll
{
    my $self = shift;

    my $prev_status = $self->get_status();

    ($self->{'status'}, $self->{'status_sub'}) = @ { $self->proto_poll(); };

    my $status = $self->get_status();

    return ( ($prev_status->[0] != $status->[0]) || 
             ($prev_status->[1] != $status->[1]) );
}

sub proto_poll
{
    my $self = shift;
    # Return Something irrelavant because this is an abstract function.
    return $self->get_status();
}

1;
