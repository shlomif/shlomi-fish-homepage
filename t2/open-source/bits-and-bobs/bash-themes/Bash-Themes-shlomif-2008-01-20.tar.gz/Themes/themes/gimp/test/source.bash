load_common mymake
# load_common gen_patch

trunk="$HOME/progs/perl/gimp/Gimp-Test/trunk"
this="$trunk/gimp-tests/valid-output"
rw_repos_url="svn+ssh://svn.berlios.de/svnroot/repos/gimp-test"
read_repos_url="svn://svn.berlios.de/gimp-test"

cd $this

