package MyConfig;

use Exporter;

use vars qw(%config @EXPORT @ISA);

@EXPORT=qw(%config);

@ISA = qw(Exporter);

%config = 
(
	'strings' => 
	{
		'main_title' => "Linux-IL Consultants Database",
		'add_result_title' => "You were added to the database",
		'add_back_link_text' => "Back to the Consultants Database",
		'show_all_records_text' => "Show all the consultants",
		'add_a_record_text' => "Add yourself to the database",
	},
	'dsn' => 'dbi:mysql:test_jobs',

        'table_name' => 'consultants',
        'areas' => [ "Tel Aviv", "Haifa", "Jerusalem", "North", "South" ],
	'fields' =>
	[
		{
			qw(sql name pres Name sameline 1)
		},
		{
                        'sql' => 'knowldege_area',
                        'pres' => 'Area of Knowledge',
                        'sameline' => 0,
                },
		{
                        'sql' => 'other_os',
                        'pres' => 'Other OS',
                        'sameline' => 0,
                },
		{
			qw(sql address pres Address sameline 1)
		},
		{
			qw(sql phone pres Phone sameline 1)
		},
		{
			qw(sql fax pres Fax sameline 1)
		},
		{	
			qw(sql email pres E-mail sameline 1 flags email)
		},
		{ 
			qw(sql website pres WebSite sameline 1)
		},
	],
);
1;