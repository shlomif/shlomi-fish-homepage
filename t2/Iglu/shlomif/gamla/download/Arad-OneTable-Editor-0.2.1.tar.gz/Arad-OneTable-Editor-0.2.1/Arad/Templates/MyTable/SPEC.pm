# Arad::Templates::MyTable::SPEC - an unusable SPEC file.
#
# This file has to be modified by the user so Arad can make use of it.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)
#
#---------------


# This is the query specification file. It has to be filled acoording to
# the query you wish to write.

package Arad::Templates::MyTable::SPEC;

use strict;

# In all those functions, $self is the instance of the table editor class,
# so you can use all of its members.

sub fMyTable_OnNew
{
    my $self = shift;
    my $field_name = shift;
    my $prev_values = shift;

    # Fill In: Generation of new primary keys for the new record event
}

sub fMyTable_Verify
{
    my $self = shift;
    my $field_name = shift;
    my $field_value = shift;

    # Fill In: constraints on fields

    return (0, "");
}

sub fMyTable_RecordVerify
{
    my $self = shift;

    # Fill In: constraints on the entire record

    return (0,"");
}


# This function return an uninitialized spec
# Fill In: The spec you want to use for the table.
sub generate_spec
{
    my $spec =
    {
        'table_name' => '', # The name of the table
        'fields' =>
        [
             # The primary keys fields
             {
                 'name' => '',                  # The name of the field
                 'type' => '',                  # Its type
                 'type_params' => { },          # Type parameters
                 'flags' => 'read-only',        # Primary Key fields should have read-only flag
                 'on_new' => \&fMyTable_OnNew   # Generate a new value for the new record event
             },
             # Other fields
             {
                 'name' => '',
                 'type' => '',
                 'type_params' => {},
                 # 'verify_func' => \&fMyTable_Verify   # Function to verify the value
             },
        ],
        # A list of the primary key fields
        'primary_key' => [  ],
        
        'order_by' => '',         # SQL ORDER BY Clause
        # 'filter' => "",         # SQL WHERE Filter

        # Function to verify the entire record
        # 'record_verify_func' => \&fMyTable_RecordVerify, 
    };

    return $spec;
}

sub init_spec
{
    my $spec = shift;
    # Generate an index to the fields

    my (%index);

    my $a;

    for($a=0;$a<scalar(@{$spec->{'fields'}});$a++)
    {
        $index{$spec->{'fields'}->[$a]->{'name'}} = $a;

        if (!exists($spec->{'fields'}->[$a]->{'flags'}))
        {
            $spec->{'fields'}->[$a]->{'flags'} = "";
        }
    }

    $spec->{'fields_index'} = \%index;

    return 0;
}

# This function returns an initialized spec.
sub get_spec
{
    my $spec = generate_spec();
    init_spec($spec);
    
    return $spec;
}

1;
