# Arad::Types - an SQL type manager. It holds a hash of various types and
# multiplexes their various functions. Check the types files for more 
# information regarding those types.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)

package Arad::Types;

use strict;

use Arad::Utils;

# Types is a shared global (in C++ it would have been declared as static)
# hash that holds all the types.

my (%types);

sub initialize
{
    my $self = shift;

    my $sql_driver = shift;

    $self->set_sql_driver($sql_driver);
}

sub new
{
    my $class = shift(@_);
    my $self = {};
    bless $self, $class;

    $self->initialize(@_);

    return $self;
}

sub set_sql_driver
{
    my $self = shift;

    my $sql_driver = shift;

    $self->{'sql_driver'} = $sql_driver;
}

sub destroy_
{
    my $self = shift;

    $self->set_sql_driver(undef);
}

# Put all the types into the types' hash

sub register_type
{
    my $t = shift;

    $types{$t->{'type'}} = $t;
}

use Arad::Types::Int16;
use Arad::Types::Int32;
use Arad::Types::Int64;
use Arad::Types::Double;
use Arad::Types::VarChar;
use Arad::Types::Char;
use Arad::Types::Date;
use Arad::Types::Time;
use Arad::Types::Boolean;

register_type(new Arad::Types::Int16);
register_type(new Arad::Types::Int32);
register_type(new Arad::Types::Int64);
register_type(new Arad::Types::Double);
register_type(new Arad::Types::VarChar);
register_type(new Arad::Types::Char);
register_type(new Arad::Types::Date);
register_type(new Arad::Types::Time);
register_type(new Arad::Types::Boolean);



# This method checks if a certain value which was inputted by the user
# is legal as far as the type and its parameters are concerned.
sub check_value
{
    my $self = shift;

    my $type = shift;
    my $type_params = shift;
    my $value = shift;

    return $types{$type}->base_check_value($type_params, $value);
}
# Returns:
# ($status, $error_string) = $types->check_value(...)
# $status - 0 - OK, 1 - Not OK.
#


# Converts a perl-style value to an SQL value that can be placed inside
# SQL clauses.
sub convert_to_sql
{
    my $self = shift;

    my $type = shift;
    my $type_params = shift;
    my $value = shift;

    return $types{$type}->base_to_sql($self->{'sql_driver'}, $type_params, $value);
}
# Returns:
# ($flags, $sql_value) = $types->convert_to_sql(...)
# $flags -
#      & 0x1 - Place inside single-quotes
#      & 0x2 - Breakable (can be put inside multiple UPDATE statements)
# $sql_value - the SQL value, unquoted, with no conversion of special characters
#              to \
#

# Converts a value that was received from the database, using SELECT
# into a value that is understood by perl.
sub convert_from_sql
{
    my $self = shift;

    my $type = shift;
    my $type_params = shift;
    my $sql_value = shift;

    return $types{$type}->base_from_sql($self->{'sql_driver'}, $type_params, $sql_value);
}
# Returns:
# $plain_value = $types->convert_from_sql(...)


# Checks a value as it is inputted. Currently the types do not support this
# function.
sub dynamic_check_value
{
    my $self = shift;

    my $type = shift;
    my $type_params = shift;
    my $old_value = shift;
    my $new_value = shift;

    return $types{$type}->base_dynamic_check_value($type_params, $old_value, $new_value);    
}
# Returns:
# ($status, $updated_value, $error_string) = $types->dynamic_check_value(...);
#
# $status = 0 - input is OK
#       & 0x1 - should be modified to updated value
#       & 0x2 - display error string
#
# $updated_value - value to update in control
# $error_string - error message to display
#

# Compares two values from the same data type, and returns a positive number
# if the first is "greater" than the second. A negative one if it's lesser,
# and 0 if both values are equal.
sub compare_values
{
    my $self = shift;

    my $type = shift;
    my $type_params = shift;
    my $value1 = shift;
    my $value2 = shift;

    return $types{$type}->base_compare($type_params, $value1, $value2);
}
# Returns:
# ($value1 cmp_func $value2)

# Quotes an SQL value, like a char or varchar so it can be passed to the SQL
# driver, inside a query. 
sub quote_sql_value
{
    my $self = shift;

    my $value = shift;

    my $sql_driver = $self->{'sql_driver'};

    if (defined($sql_driver) && ($sql_driver->can("quote_sql_value")))
    {
        return $sql_driver->quote_sql_value($value);
    }

    return ("'" . Arad::Utils::backslash_string($value, "'", "oct") . "'");
}


1;
