#!/usr/bin/perl

require 5.004; 

use strict;

#BEGIN {  unshift @INC, "../lib"; }

$^W = 0;
use Parse::YYLex;

use MyParser;

print STDERR "Version $Parse::ALex::VERSION\n";

my (@tokens) = (
      'LEFT_PARENS', '\(', 'RIGHT_PARENTS', '\)',
      
	  qw(
	     MINUS    -
         PLUS     \+
         MULT      \*
         DIV       /
	     LEFTP    [\(]
	     RIGHTP   [\)]
	     INT  [1-9][0-9]*
         EOL  \n
	    ),
      
	  qw(STRING),   [qw(" (?:[^"]+|"")* ")],
	  qw(ERROR  .*), sub {
	    die "!can\'t analyze: \"$_[1]\"\n!";
	  }
	 );

#Parse::YYLex->trace;
Parse::YYLex->ytab('y.tab.ph');
my $lexer = Parse::YYLex->new(@tokens);

sub yyerror
{
    die "There was an error:" . join("\n", @_). "\n";
}

my $debug = 0;
my $parser = new MyParser($lexer->getyylex(), \&MyParser::yyerror , $debug);
$lexer->from(\*STDIN);
$parser->yyparse(\*STDIN);

__END__
1+2-5

