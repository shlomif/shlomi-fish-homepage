# This is so Perl Golf test suites will backup the scripts
export GOLF_BACKUP=0.5

