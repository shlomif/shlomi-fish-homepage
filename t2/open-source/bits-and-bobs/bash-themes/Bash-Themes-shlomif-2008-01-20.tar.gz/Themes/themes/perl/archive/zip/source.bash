load_common mymake
load_common completion
# load_common gen_patch

base="$HOME/progs/perl/cpan/Archive-Zip"
trunk="$base/trunk/Archive-Zip"
this="$trunk"
rw_repos_url="http://svn.ali.as/cpan/trunk/Archive-Zip"
read_repos_url="http://svn.ali.as/cpan/trunk/Archive-Zip"

cd $this

