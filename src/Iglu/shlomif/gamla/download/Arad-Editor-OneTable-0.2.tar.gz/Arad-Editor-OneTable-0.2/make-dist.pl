#!/usr/bin/perl

use strict;

use File::Find;

my (@modules, @dirs);

sub make_list
{
    my $fn = $File::Find::name;

    $fn =~ s!^\./!!;

    if ($fn =~ /^Arad/)
    {
        if ($fn =~ /\.pm$/)
        {
            push @modules, $fn;
        }
        elsif (-d $_)
        {
            push @dirs, $fn;
        }
    }
}

find(\&make_list, ".");

my ($dir, $module, $text);

foreach $dir (@dirs)
{
    if (! -e ("dist/" . $dir))
    {
        mkdir("dist/" . $dir, 0777);
    }
}

foreach $module (@modules)
{
    open I, "<" . $module;
    $text = join("", <I>);
    close I;

    open O, (">dist/" . $module);
    print O $text;
    close (O);
}


