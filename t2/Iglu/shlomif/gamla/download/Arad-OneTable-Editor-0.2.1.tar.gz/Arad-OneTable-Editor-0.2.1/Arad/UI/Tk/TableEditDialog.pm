# Arad::UI::Tk::TableEditDialog - The Perl/Tk table editing dialog
#
# This dialog displays the field titles and their value-editing controls
# in a vertical table, and displays some buttons and a menu bar.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)

package Arad::UI::Tk::TableEditDialog;

use Arad::UI::TableEditDialog;

@ISA = qw(Arad::UI::TableEditDialog);

use strict;

use Arad::Utils;
use Tk;


sub initialize
{
    my $self = shift;

    my $ui = shift;

    $self->SUPER::initialize($ui);
}


# Fills the controls with the values of the fields and displays
# The record number.
sub fill_values
{
    my $self = shift;

    my $editor = $self->{'editor'};
    my $field_controls = $self->{'field_controls'};

    my ($a, $value, $field_name, $entry);

    for($a=0 ; $a < scalar(@{$self->{'fields'}}) ; $a++)
    {
        $field_name = $self->{'fields'}->[$a]->{'name'};
        
        $value = $editor->get_field_value($field_name);

        $entry = $field_controls->[$a]->{'entry'};

        $entry->delete(0,length($entry->get()));

        $entry->insert(0, Arad::Utils::backslash_string($value));
    }


    my $top_label = $self->{'top_label'};

    my $record_num = $self->{'editor'}->get_record_position();



    if ($record_num < 0)
    {
        $top_label->configure(-text => "[ Out of filter ]");
    }
    else
    {
        $top_label->configure(-text => "Record Number " . $record_num);
    }
    
}

# Determines whether the current record has changed since it was loaded.
sub has_record_changed
{
    my $self = shift;

    my $editor = $self->{'editor'};
    my $fields = $self->{'fields'};
    my $field_controls = $self->{'field_controls'};

    my ($a, $orig_value, $ui_value);

    for($a=0; $a < scalar(@{$fields}); $a++)
    {
        $orig_value = $editor->get_field_value($fields->[$a]->{'name'});

        $ui_value = Arad::Utils::unbackslash_string($field_controls->[$a]->{'entry'}->get());

        if ($orig_value ne $ui_value)
        {
            return 1;
        }
    }

    return 0;
}


sub next_or_prev
{
    my $self = shift;

    my $offset = shift;

    my $editor = $self->{'editor'};

    if ($self->has_record_changed())
    {
        if (($self->message_box("The record has changed. Are you sure you want to move to a new record (and lose changed to this one)?", "yes-no")) eq "no")
        {
            return 0;
        }
    }

    my (@ret);
    
    @ret = $editor->next_or_prev_record($offset);

    if ($ret[0] != 0)
    {
        $self->message_box($ret[1], 'ok');
    }
    else
    {
        $self->fill_values();
    }
    
}

sub save_record
{
    my $self = shift;

    my $editor = $self->{'editor'};

    my ($a, $fields, $ctrls, $input, @ret, $field_name);


    $fields = $self->{'fields'};
    $ctrls = $self->{'field_controls'};    

    for($a=0 ; $a < scalar(@{$fields}) ; $a++)
    {
        $field_name = $fields->[$a]->{'name'};

        if (! $editor->is_readonly($field_name))
        {

            $input = $ctrls->[$a]->{'entry'}->get();
    
            @ret = $editor->set_field_value($field_name, Arad::Utils::unbackslash_string($input));
    
            if ($ret[0] != 0)
            {
                $self->message_box($ret[1], 'ok');

                return 1;
            }
        
        }

    }

    @ret = $editor->save_record("");

    if ($ret[0] != 0)
    {
        $self->message_box($ret[1], 'ok');
    }
    else
    {
        $self->fill_values();
    }

    return 0;
}

sub load_record
{
    my $self = shift;

    my $editor = $self->{'editor'};

    if ($self->has_record_changed())
    {
        if (($self->message_box("The record has changed. Are you sure you want to move to a new record (and lose changed to this one)?", "yes-no")) eq "no")
        {
            return 0;
        }
    }
    

    my (@ret, @pkey, %pkey_values, $a, $input, $dialog, $label, $entry, $button);

    @ret = $editor->get_primary_key();

    @pkey = @{$ret[0]};

    foreach $a (@pkey)
    {
        $dialog = $self->{'top'}->Dialog();

        $input = '';

        $label = $dialog->Label(-text => ("Enter the value for " . $a . ":"), -justify => 'left');
        $label->pack(-side => 'top');

        $entry = $dialog->Entry(-width => 40, -textvariable => \$input);
        $entry->pack(-side => 'top');

        #$button = $dialog->Button(-text => 'OK', -command => sub { $input = $entry->get(); $dialog = '' ; });
        #$button->pack(-side => 'top');

        $dialog->Show();
    
        $pkey_values{$a} = Arad::Utils::unbackslash_string($input);
    }

    @ret = $editor->load_record_by_primary_key(\%pkey_values);

    if ($ret[0] != 0)
    {
        $self->message_box($ret[1], 'ok');
    }
    else
    {
        $self->fill_values();
    }

    return 0;
    
}

sub new_record
{
    my $self = shift;

    my $editor = $self->{'editor'};

    if ($self->has_record_changed())
    {
        if (($self->message_box("The record has changed. Are you sure you want to create a new record (and lose changed to this one)?", "yes-no")) eq "no")
        {
            return 0;
        }
    }
    

    my (@ret);

    @ret = $editor->new_record();

    if ($ret[0] != 0)
    {
        print "\n" . $ret[1] . "\n";        
    }
    else
    {
        $self->fill_values();
    }
}

sub delete_record
{
    my $self = shift;

    my $editor = $self->{'editor'};

    if (($self->message_box("Are you sure you want to delete this record?", "yes-no")) eq "no")
    {
        return 0;
    }
    

    my @ret = $editor->delete_record();

    if ($ret[0] != 0)
    {
        print "\n" . $ret[1] . "\n";
    }
    else
    {
        $self->fill_values();
    }
    
}

sub goto_record
{
    my $self = shift;

    my $editor = $self->{'editor'};

    if ($self->has_record_changed())
    {
        if (($self->message_box("The record has changed. Are you sure you want to move to a new record (and lose changed to this one)?", "yes-no")) eq "no")
        {
            return 0;
        }
    }


    my ($dialog, $input, $absolute, $check_button, $label, $entry, $selected_button);

    $dialog = $self->{'top'}->Dialog(-buttons => ['Ok', 'Cancel']);

    $input = '';
    $absolute = 0;

    $label = $dialog->Label(-text => "Enter the position of the record to go to:", -justify => 'left');
    $label->pack(-side => 'top');

    $check_button = $dialog->Checkbutton(-text => "Absolute Position", -variable => \$absolute);
    $check_button->pack(-side => 'top');

    $entry = $dialog->Entry(-width => 40, -textvariable => \$input);
    $entry->pack(-side => 'top');

    #$button = $dialog->Button(-text => 'OK', -command => sub { $input = $entry->get(); $dialog = '' ; });
    #$button->pack(-side => 'top');

    $selected_button = $dialog->Show();

    if ($selected_button eq 'Cancel')
    {
        return 0;
    }

    my (@ret);

    $input = int($input);

    if ($absolute)
    {
        @ret = $editor->load_record_by_sequence_pos($input);
    }
    else
    {
        @ret = $editor->next_or_prev_record($input);
    }

    if ($ret[0] != 0)
    {
        $self->message_box($ret[1], 'ok');
    }
    else
    {
        $self->fill_values();
    }
    
}

sub exit_
{
    my $self = shift;

    if ($self->has_record_changed())
    {
        if (($self->message_box("The record has changed. Are you sure you want to exit the program (and lose the changes)?", "yes-no")) eq "no")
        {
            return 0;
        }
    }

    
    $self->{'top'}->destroy();

}

# The geometry of the dialog goes like this:
# Menu (left aligned)
# Record Number Label (Center Aligned)
# The Fields' Frame (left aligned)
# Buttons Frame (center aligned)
sub dialog_loop
{
    my $self = shift;

    my $TOP = MainWindow->new();
    $TOP->title("Editing table: " . $self->{'editor'}->get_table_name());
    $self->{'top'} = $TOP;

    my ($fields_frame, $a, @field_controls, $field_name, $label, $entry, $top_label);
    my ($menu_bar);

    $menu_bar = $TOP->Frame();
    $menu_bar->grid(-row => 0, -column => 0, -sticky => 'w');

    $top_label = $TOP->Label(-text => "", -justify => 'left');
    $self->{'top_label'} = $top_label;
    $top_label->grid(-row => 1, -column => 0);

    $fields_frame = $TOP->Frame()->grid(qw!-row 2 -column 0 -sticky w!);

    for($a=0 ; $a < scalar(@{$self->{'fields'}}) ; $a++)
    {
        $field_name = $self->{'fields'}->[$a]->{'name'};

        $label = $fields_frame->Label(-text => ($field_name . ":"), -justify => 'left');

        $entry = $fields_frame->Entry(-width => 40);

        $label->grid(-row => $a, -column => 0, -sticky => 'w');
        $entry->grid(-row => $a, -column => 1, -sticky => 'ew');
        $fields_frame->gridRowconfigure(1, -weight => 1 );

        $field_controls[$a] = { 'entry' => $entry };
    }

    $self->{'field_controls'} = \@field_controls;

    my ($buttons_frame, $scrolling_buttons_frame, $command_buttons_frame);

    $buttons_frame = $TOP->Frame()->grid(qw!-row 3 -column 0!);

    $scrolling_buttons_frame = $buttons_frame->Frame()->pack(qw!-side top!);    

    my $prev_100 = $scrolling_buttons_frame->Button(-text => '<<', -command => sub { $self->next_or_prev(-100); });
    $prev_100->pack(qw!-side left!);

    my $prev = $scrolling_buttons_frame->Button(-text => '<', -command => sub { $self->next_or_prev(-1); });
    $prev->pack(qw!-side left!);

    my $next = $scrolling_buttons_frame->Button(-text => '>', -command => sub { $self->next_or_prev(1); });
    $next->pack(qw!-side left!);
    
    my $next_100 = $scrolling_buttons_frame->Button(-text => '>>', -command => sub { $self->next_or_prev(100); });
    $next_100->pack(qw!-side left!);

    my $goto = $scrolling_buttons_frame->Button(-text => 'Goto #', -command => sub { $self->goto_record(); });
    $goto->pack(qw!-side left!);
    
    my $save = $buttons_frame->Button(-text => 'Save', -command => sub { $self->save_record(); });
    $save->pack(qw!-side top -fill x!);

    my $load = $buttons_frame->Button(-text => 'Load...', -command => sub { $self->load_record(); });
    $load->pack(qw!-side top -fill x!);

    my $new = $buttons_frame->Button(-text => 'New', -command => sub { $self->new_record(); });
    $new->pack(qw!-side top -fill x!);

    my $delete = $buttons_frame->Button(-text => 'Delete', -command => sub { $self->delete_record(); });
    $delete->pack(qw!-side top -fill x!);

    my $exit = $buttons_frame->Button(-text => 'Exit', -command => sub { $self->exit_();  });
    $exit->pack(qw!-side top -fill x!);

    # Initialize the menus in the menu bar.

    my $file = $menu_bar->Menubutton(-text => 'File', -underline => 0, -menuitems =>
                                [
                                 [ 'Button' => 'Quit', -underline => 0, -command => sub { $self->exit_(); } ]
                                ]);

    $file->grid(qw!-row 0 -column 0 -sticky w!);

    my $record = $menu_bar->Menubutton(-text => 'Record', -underline => 0, -menuitems =>
                                             [
                                              [ 'Button' => 'New', -underline => 0, -command => sub { $self->new_record(); } ],
                                              [ 'Button' => 'Save', -underline => 0, -command => sub { $self->save_record(); }, -accelerator => 'Control+s' ],
                                              [ 'Button' => 'Load...', -underline => 0, -command => sub { $self->load_record(); }, -accelerator => 'Control+l' ],
                                              [ 'Button' => 'Delete', -underline => 0, -command => sub { $self->delete_record(); }, -accelerator => 'Control+d' ],                                              
                                             ]);

    $record->grid(qw!-row 0 -column 1 -sticky w!);

    my $move = $menu_bar->Menubutton(-text => 'Move', -underline => 0, -menuitems =>
                                           [
                                            [ 'Button' => 'Next', -underline => 0, -command => sub { $self->next_or_prev(1); }, -accelerator => 'Control+n' ],
                                            [ 'Button' => 'Prev', -underline => 0, -command => sub { $self->next_or_prev(-1); }, -accelerator => 'Control+p' ],
                                            [ 'Button' => 'Next 100', -underline => 1, -command => sub { $self->next_or_prev(100); }, -accelerator => 'Control+>' ],
                                            [ 'Button' => 'Prev 100', -underline => 1, -command => sub { $self->next_or_prev(-100); }, -accelerator => 'Control+<' ],
                                            [ 'Separator' => ''],
                                            [ 'Button' => 'Goto Number...', -underline => 0, -command => sub { $self->goto_record(); } ],
                                           ]);

    $move->grid(qw!-row 0 -column 2 -sticky w!);
    
    # Create key bindings.

    $TOP->bind('<Control-n>' => sub { $self->next_or_prev(1); });
    $TOP->bind('<Control-p>' => sub { $self->next_or_prev(-1); });
    $TOP->bind("<Control-period>" => sub { $self->next_or_prev(100); });
    $TOP->bind("<Control-comma>" => sub { $self->next_or_prev(-100); });
    $TOP->bind('<Control-s>' => sub { $self->save_record(); });
    $TOP->bind('<Control-l>' => sub { $self->load_record(); });
    $TOP->bind('<Control-d>' => sub { $self->delete_record(); });

    $self->fill_values();

    Tk::MainLoop();

    return 0;
}    

sub get_field_from_user
{
    my $self = shift;

    my $field_name = shift;

    my ($dialog, $frame, $input, $label, $entry);

    $dialog = $self->{'top'}->Dialog();

    $frame = $dialog->Frame()->pack(qw!-side top!);    

    $input = '';

    $label = $frame->Label(-text => ("Enter the value of " . $field_name . ":"), -justify => 'left');
    $label->grid(-row => 0, -column => 0, -sticky => 'w');
    $frame->gridRowconfigure(1, -weight => 1 );

    $entry = $frame->Entry(-width => 40, -textvariable => \$input);
    $entry->grid(-row => 1, -column => 0, -sticky => 'w');
    $frame->gridRowconfigure(1, -weight => 1 );


    $dialog->Show();

    return Arad::Utils::unbackslash_string($input);
}


sub message_box
{
    my $self = shift;

    my $text = shift;
    my $type = shift;

    return $self->SUPER::message_box($text, $type, $self->{'top'});    
}

