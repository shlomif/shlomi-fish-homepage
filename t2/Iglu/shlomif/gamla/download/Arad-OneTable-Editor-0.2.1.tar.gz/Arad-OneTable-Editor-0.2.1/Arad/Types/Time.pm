# Arad::Types::Int32 - an implementation of a time SQL data type.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)


package Arad::Types::Time;

use Arad::Types::Time;

@ISA = qw(Arad::Types::Base);

use strict;

sub initialize
{
    my $self = shift;

    $self->{'type'} = 'time';
}

sub check_value
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value =~ /^\d{1,2}(:\d{1,2}(:\d{1,2}(\.\d{1,6})?)?)?$/)
    {
        my @parts = split(/:/, $value);

        if ($parts[0] > 23)
        {
            return (1, "The hour in \$F must be in the range 0-23");
        }
        elsif ((scalar(@parts) >= 2) && ($parts[1] > 59))
        {
            return (1, "The minutes in \$F must be in the range 0-59");
        }
        elsif ((scalar(@parts) >= 3) && ($parts[2] >= 60))
        {
            return (1, "The seconds in \$F must be in the range 0-59");
        }
        else
        {
            return (0,"");
        }
    }
    elsif (($value eq '') || ($value eq undef))
    {
        return (0, "");
    }
    else
    {
        return (1, "\$F is a time and must be in the form HH:MM:SS");
    }
}

sub to_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    my $new_value = '';

    if ($value =~ /^\d{1,2}(:\d{1,2}(:\d{1,2}(\.\d{1,6})?)?)?$/)
    {
        if ($value =~ /^\d{1,2}$/)
        {
            $new_value = $value . ":00:00";
        }
        elsif ($value =~ /^\d{1,2}:\d{1,2}$/)
        {
            $new_value = $value . ":00";
        }
        else
        {
            $new_value = $value;
        }
    }
    elsif (($value eq '') || ($value eq undef))
    {
        return (0, "null");
    }
    return (1, $new_value);
}

sub from_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value eq undef)
    {
        return '';
    }

    return $value;
}

sub compare
{
    my $self = shift;

    my $type_params = shift;

    my $value1 = shift;
    my $value2 = shift;

    my ($y1, $m1, $d1) = split(/-/, $value1);
    my ($y2, $m2, $d2) = split(/-/, $value2);

    my $days1 = ($y1*12+$m1)*31+$d1;
    my $days2 = ($y2*12+$m2)*31+$d2;
    
    return ($days1 <=> $days2);
}
