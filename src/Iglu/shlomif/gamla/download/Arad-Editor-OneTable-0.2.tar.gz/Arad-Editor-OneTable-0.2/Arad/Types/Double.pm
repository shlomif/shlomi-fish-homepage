# Arad::Types::Double - a floating-point SQL data type.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)


package Arad::Types::Double;

use Arad::Types::Base;

@ISA = qw(Arad::Types::Base);

use strict;

sub initialize
{
    my $self = shift;

    $self->{'type'} = 'double';
}

sub check_value
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value =~ /^[-+]?\d+(\.\d+)?((e|E)\d+)?$/)
    {
        return (0, "");
    }
    elsif (($value eq undef) || ($value eq ''))
    {
        return (0,"");
    }
    else
    {
        return (1, "\$F must be an floating point value.");
    }
}

sub to_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if (($value eq undef) || ($value eq ''))
    {
        return (0, "null");
    }

    return (0, $value);
}

sub from_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value eq undef)
    {
        return '';
    }

    return $value;
}

sub compare
{
    my $self = shift;

    my $type_params = shift;

    my $value1 = shift;
    my $value2 = shift;

    return ($value1 <=> $value2);
}
