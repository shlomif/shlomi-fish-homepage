# Arad::Types::Base - the base class for the SQL data types.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)


package Arad::Types::Base;

use strict;

sub initialize
{
    my $self = shift;

    $self->{'type'} = 'base';
}

sub new
{
    my $class = shift(@_);
    my $self = {};
    bless $self, $class;

    $self->initialize();

    return $self;
}

sub base_check_value
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    return $self->check_value($type_params, $value);
}

sub base_to_sql
{
    my $self = shift;

    my $sql_driver = shift;
    my $type_params = shift;
    my $value = shift;

    if (defined($sql_driver) && ($sql_driver->can_convert_to($self->{'type'})))
    {
        return $sql_driver->convert_to_sql($self->{'type'}, $type_params, $value);
    }
    else
    {
        return $self->to_sql($type_params, $value);
    }
}

sub base_from_sql
{
    my $self = shift;

    my $sql_driver = shift;
    my $type_params = shift;
    my $value = shift;

    if (defined($sql_driver) && ($sql_driver->can_convert_from($self->{'type'})))
    {
        return $sql_driver->convert_from_sql($self->{'type'}, $type_params, $value);
    }
    else
    {
        return $self->from_sql($type_params, $value);
    }
}

sub base_dynamic_check_value
{
    my $self = shift;

    my $type_params = shift;
    my $old_value = shift;
    my $new_value = shift;

    if ($self->can("dynamic_check_value"))
    {
        return $self->dynamic_check_value($type_params, $old_value, $new_value);
    }
    else
    {
        return (0, $new_value, undef);
    }
}

sub base_compare
{
    my $self = shift;

    my $type_params = shift;

    my $value1 = shift;
    my $value2 = shift;

    return $self->compare($type_params, $value1, $value2);
}

1;