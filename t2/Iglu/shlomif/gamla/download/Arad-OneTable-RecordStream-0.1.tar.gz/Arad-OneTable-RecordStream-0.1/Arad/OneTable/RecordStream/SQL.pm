# Arad::OneTable::RecordStream::SQL - a stream of records from an SQL
# table.
#
# Usage:
# my $stream = Arad::OneTable::RecordStream::SQL->new(
#     $dbi_connection,
#     $spec,
#     $table_name);
#
# Or:
# my $stream = Arad::OneTable::RecordStream::SQL->new(
#     $dbi_connection,
#     $spec,
#     $table_name
#     -convert_from_sql => 1,
#     -typeman => $type_manager);
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
# This code is under the public domain.

package Arad::OneTable::RecordStream::SQL;

use strict;

use Arad::OneTable::RecordStream;

use vars qw(@ISA);

@ISA=qw(Arad::OneTable::RecordStream);


sub initialize
{
    my $self = shift;
    
    $self->{'conn'} = shift;
    $self->{'spec'} = shift;
    $self->{'table_name'} = shift;
    
    my $spec = $self->{'spec'};

    my $table_spec = 
        $spec->{'tables'}->[
            $spec->{'tables_index'}->{ $self->{'table_name'} }
        ];
    
    $self->{'table_spec'} = $table_spec;
    
    my $opt;
    
    $self->{'bToConvert'} = 0;
    
    while ($opt = shift(@_))
    {
        if ($opt eq '-typeman')
        {
            $self->{'typeman'} = shift;
        }
        elsif ($opt eq '-convert_from_sql')
        {
            $self->{'bToConvert'} = shift;
        }
    }
    
    $self->start_query();
}

sub destroy_
{
    my $self = shift;
    
    my $member;

    foreach $member (qw(spec table_spec conn query))
    {
        delete($self->{$member});
    }
}

sub construct_sql_query
{
    my $self = shift;

    my $spec = $self->{'spec'};
    my $table_name = $self->{'table_name'};
    my $table_spec = $self->{'table_spec'};
    
    my (@field_names, $query, $field_record, $where_clause, $order_by_clause);
    
    foreach $field_record (@{$table_spec->{'fields'}})
    {
        push @field_names, $field_record->{'name'};
    }
    
    $where_clause = exists($table_spec->{'sql_where'}) ? (" WHERE " . $table_spec->{'sql_where'} . " ") : "";
    
    $order_by_clause = exists($table_spec->{'sql_order_by'}) ? (" ORDER BY " . $table_spec->{'sql_order_by'}) : "";
    
    $query = "SELECT " . join(",", @field_names) .
        " FROM " . $table_name . 
        $where_clause .
        $order_by_clause ;
        
    return $query;
}

sub start_query
{
    my $self = shift;
    
    my $spec = $self->{'spec'};
    
    my $table_name = $self->{'table_name'};
    
    my $table_spec = $self->{'table_spec'};
    
    my $query_string = $self->construct_sql_query();
    
    my $query = $self->{'conn'}->prepare($query_string);
    
    $query->execute();
    
    $self->{'query'} = $query;
    
    return 0;
}

sub get_next_record
{
    my $self = shift;
    
    if ($self->{'bToConvert'})
    {
        return undef;
    }
    else
    {
        return $self->{'query'}->fetchrow_hashref();
    }
}

sub skip
{
    my $self = shift;
 
    my $how_many = shift;
    
    my $i;
    
    my $query = $self->{'query'};
    
    for($i=0;$i<$how_many;$i++)
    {
    	$query->fetchrow_arrayref;
    }
    
    return 0;
}

1;