#!/usr/bin/perl -w

use strict;

#use CGI;
use Contents;
use Quad::Pres;

#my $q = CGI->new();

#print $q->header();

my $contents = Contents::get_contents();

my $document_name = shift || "";

my $p = Quad::Pres->new($contents, $document_name, "harddisk");
#my $p = Quad::Pres->new($contents, $document_name, "server");

$p->render();


