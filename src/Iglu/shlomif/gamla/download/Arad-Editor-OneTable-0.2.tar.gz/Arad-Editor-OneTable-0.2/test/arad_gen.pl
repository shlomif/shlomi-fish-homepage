use Arad::Generate::OneTable;

$q = new Arad::Generate::OneTable;

$q->generate();