#!/usr/local/bin/perl

use MyTable;
use MyTable::SPEC;

use Arad::Types;
use Arad::SQL::DBI;
use Arad::UI::Tk;

my $sql = Arad::SQL::DBI->new();

my $types = Arad::Types->new($sql);

$sql->set_types_manager($types);

my $ui = Arad::UI::Tk->new();

my $spec = MyTable::SPEC::get_spec();

$sql->connect_db(
{
    'dsn' => "",
    'init' => "",
});

my $table = MyTable->new($types, $sql, $ui, $spec);

my $options = '';
$table->create_dialog($options);

$sql->destroy_();
