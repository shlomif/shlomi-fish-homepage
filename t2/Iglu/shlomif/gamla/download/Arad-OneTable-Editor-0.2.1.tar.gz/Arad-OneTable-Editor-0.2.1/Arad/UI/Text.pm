# Arad::UI::Text - The text/readline user-interface.
#
# Most of the functionality is in Arad::UI::Text::TableEditDialog,
# so this is pretty basic stuff.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)



package Arad::UI::Text;

use Arad::UI;

@ISA = qw(Arad::UI);

use strict;

use Term::ReadLine;
use Arad::UI::Text::TableEditDialog;

sub initialize
{
    my $self = shift;

    $self->{'dialog_options'} = '';
}

sub set_dialog_options
{
    my $self = shift;

    my $options = shift;

    $self->{'dialog_options'} = $options;
}

sub create_new_dialog
{
    my $self = shift;

    my $what = shift;

    my $options;
    if (scalar(@_))
    {
        $options = shift;
    }
    else
    {
        $options = $self->{'dialog_options'};
    }

    my $dialog = undef;

    if ($what->{'type'} eq 'table')
    {
        $dialog = Arad::UI::Text::TableEditDialog->new($self, $options);
    }

    return $dialog;
}

# Display a message box.
# Currently supported type are "ok" and "yes-no"
sub message_box
{
    my $self = shift;

    my $text = shift;
    my $type = shift;
    my $readline_handle = shift;

    if (! $readline_handle)
    {
        $readline_handle = Term::ReadLine->new('Arad Message Box');
    }

    my ($input);

    print $text, "\n";
    if ($type eq 'ok')
    {
        $readline_handle->readline();
    } 
    elsif ($type eq 'yes-no')
    {
        $input = $readline_handle->readline();
        while ($input !~ /^(yes|y|no|n)$/i)
        {
            $input = $readline_handle->readline();
        }
        return ( ($input =~ /^(yes|y)$/i) ? 'yes' : 'no');
    }
}

1;