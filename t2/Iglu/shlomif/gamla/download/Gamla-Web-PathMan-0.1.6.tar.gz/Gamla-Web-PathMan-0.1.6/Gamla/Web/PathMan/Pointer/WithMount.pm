package Gamla::Web::PathMan::Pointer::WithMount;

use strict;

use vars qw(@ISA);

use Gamla::Object;

@ISA=qw(Gamla::Object);

sub init_scalars
{
    my $self = shift;

    my $params = shift;

    my $pathman = shift(@{$params});
    $self->{'path_man'} = $pathman;

    $self->{'cur_dir'} = ($pathman->get_root_dir());

    $self->{'pm_path'} = [];

    $self->{'is_in_mounted'} = 0;

    $self->handle_mounting();

    return 0;
}

sub init_options
{
    my $self = shift;

    $self->{'recursive_mount'} = 0;
    $self->{'recursive_write'} = 1;

    my ($opt, @ret);

    while ($opt = shift)
    {
        if ($opt =~ /^-?recursive(_|-)mount$/i)
        {
            $self->{'recursive_mount'} = (!!shift);
        }
        elsif ($opt =~ /^-?recursive(_|-)write$/i)
        {
            $self->{'recursive_write'} = (!!shift);
        }
        else
        {
            push @ret, $opt, shift(@_);
        }
    }

    if (! $self->{'recursive_write'} )
    {
        $self->{'recursive_mount'} = 0;
    }

    return @ret;
}

sub initialize
{
    my $self = shift;

    $self->init_scalars(\@_);

    $self->init_options(@_);

    return 0;
}

sub handle_mounting
{
    my $self = shift;

    if ($self->is_mounting_point())
    {
        my $mounted_pointer = $self->get_mounted_pathman_pointer();
        $mounted_pointer->cd($self->get_mounted_pathman_path_to_start_from());
        $self->{'mounted_pointer'} = $mounted_pointer;
        $self->{'is_in_mounted'} = 1;
        $self->{'len_orig_path'} = scalar(@{$self->{'pm_path'}});
    }
}

sub mkdir_
{
    my $self = shift;

    my $subdir_name = shift;

    if ($self->{'is_in_mounted'})
    {
        if ($self->{'recursive_write'})
        {
            return $self->{'mounted_pointer'}->mkdir_($subdir_name);
        }
        else
        {
            return (1, "No recursive writes are allowed in mounted pathmans");
        }
    }
    else
    {
        if ($self->dir_exists($subdir_name))
        {
            return (2, "There's already a directory by that name");
        }
        else
        {
            $self->local_mkdir($subdir_name);
        }
    }
}

sub pwd_
{
    my $self = shift;

    return [ @{$self->{'pm_path'}} ];
}

sub atomic_cd
{
    my $self = shift;

    my $subdir_name = shift;

    if ($subdir_name eq "..")
    {
        return $self->cd_up();
    }
    elsif ($subdir_name eq ".")
    {
    }
    else
    {
        my @ret;
        if ($self->{'is_in_mounted'})
        {
            @ret = $self->{'mounted_pointer'}->cd($subdir_name);
        }
        else
        {
            if ($self->dir_exists($subdir_name))
            {
                $self->local_atomic_cd($subdir_name);
                $self->handle_mounting();
                @ret = (0, "");
            }
            else
            {
                @ret = (1, "The sub-dir does not exist.");
            }
        }
        if (! $ret[0])
        {
            push @{$self->{'pm_path'}}, $subdir_name;
        }
        return @ret;
    }
}

sub cd_up
{
    my $self = shift;

    my $pm_path = $self->{'pm_path'};

    if (scalar(@$pm_path) == 0)
    {
        return (1, "Already at root");
    }
    pop(@$pm_path);

    my $local_cd_up = 0;

    if ($self->{'is_in_mounted'})
    {
        if ($self->{'len_orig_path'} == scalar(@$pm_path))
        {
            delete($self->{'mounted_pointer'});
            $self->{'is_in_mounted'} = 0;
            $local_cd_up = 1;
        }
        else
        {
            $self->{'mounted_pointer'}->cd([ ".." ]);
        }
    }
    else
    {
        $local_cd_up = 1;
    }
    if ($local_cd_up)
    {
        return $self->local_cd_up();
    }
    return (0, "");
}

sub cd_
{
    my $self = shift;

    my $path = shift;

    my ($subdir_name, @ret);
    
    foreach $subdir_name (@{$path})
    {
        @ret = $self->atomic_cd($subdir_name);
        if ($ret[0])
        {
            return @ret;
        }
    }
    return (0, "");
}

sub duplicate_by_cd
{
    my $self = shift;

    my $ptr = ref($self)->new($self->{'path_man'});

    $ptr->cd_($self->pwd_());

    return $ptr;
}

sub duplicate_by_elements_copy
{
    my $self = shift;

    my $ptr = {};

    bless $ptr, ref($self);

    $ptr->{'path_man'} = $self->{'path_man'};
    $ptr->{'pm_path'} = [ @{$self->{'pm_path'}} ];
    $ptr->{'cur_dir'} = $self->{'cur_dir'};
    $ptr->{'is_inmounted'} = $self->{'is_in_mounted'};

    if ($self->{'is_in_mounted'})
    {
        $ptr->{'mounted_pointer'} = $self->{'mounted_pointer'}->duplicate();
        $ptr->{'len_orig_path'} = $self->{'len_orig_path'};
    }

    return $ptr;
}

sub duplicate
{
    my $self = shift;

    return $self->duplicate_by_elements_copy();
}

sub set_attribs
{
    my $self = shift;

    my $attribs = shift;

    if ($self->{'is_in_mounted'})
    {
        if ($self->{'recursive_write'})
        {
            return $self->{'mounted_pointer'}->set_attribs($attribs);
        }
    }
    else
    {
        return $self->local_set_attribs($attribs);
    }
}

sub get_attribs
{
    my $self = shift;

    my $attrib_names = shift;

    if ($self->{'is_in_mounted'})
    {
        return $self->{'mounted_pointer'}->get_attribs($attrib_names);
    }
    else
    {
        return $self->local_get_attribs($attrib_names);
    }
}

sub ls_
{
    my $self = shift;

    if ($self->{'is_in_mounted'})
    {
        return $self->{'mounted_pointer'}->ls_(); 
    }
    else
    {
        return $self->local_ls();
    }
}
