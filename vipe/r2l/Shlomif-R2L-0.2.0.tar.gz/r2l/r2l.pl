#!/usr/bin/perl

use Getopt::Long;

use Gtk;
use Shlomif::R2L::Gui;

my $filename = "";
$result = GetOptions ('filename=s' => \$filename);

if ($filename eq "")
{
    $filename = $ENV{'HOME'} . ".r2l";
}

my $gui = Shlomif::R2L::Gui->new($filename );

Gtk->init();

$gui->run();

Gtk->main();


