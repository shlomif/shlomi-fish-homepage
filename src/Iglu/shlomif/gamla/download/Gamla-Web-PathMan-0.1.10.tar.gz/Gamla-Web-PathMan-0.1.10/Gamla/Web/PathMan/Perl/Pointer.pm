package Gamla::Web::PathMan::Perl::Pointer;

use strict;

use Gamla::Web::PathMan::Pointer::WithMount;

use vars qw(@ISA);

@ISA=qw(Gamla::Web::PathMan::Pointer::WithMount);

sub is_mounting_point
{
    my $self = shift;

    my $cur_dir = $self->{'cur_dir'};

    return $cur_dir->{'is_mounted'};
}

sub get_mounted_pathman_pointer
{
    my $self = shift;

    my $cur_dir = $self->{'cur_dir'};

    return $cur_dir->{'mounted_pathman'}->get_base_pointer();
}

sub get_mounted_pathman_path_to_start_from
{
    my $self = shift;

    my $cur_dir = $self->{'cur_dir'};

    return [ @{$cur_dir->{'mounted_start_path'}} ];
}

sub dir_exists
{
    my $self = shift;

    my $subdir_name = shift;

    my $cur_dir = $self->{'cur_dir'};

    return exists($cur_dir->{'subdirs'}->{$subdir_name});
}

sub local_mkdir
{
    my $self = shift;

    my $subdir_name = shift;

    my $cur_dir = $self->{'cur_dir'};

    $cur_dir->{'subdirs'}->{$subdir_name} = 
    {
        '..' => $cur_dir,
        'is_mounted' => 0,
        'attrbs' => {},
        'subdirs' => {},
    };

    return 0;
}

sub local_cd_up
{
    my $self = shift;

    if (defined($self->{'cur_dir'}->{'..'}))
    {
        $self->{'cur_dir'} = $self->{'cur_dir'}->{'..'};
        return (0,"");
    }
    return (2, "Already at root");    
}

sub local_atomic_cd
{
    my $self = shift;

    my $subdir_name = shift;

    $self->{'cur_dir'} = $self->{'cur_dir'}->{'subdirs'}->{$subdir_name};

    return (0, "");
}

sub local_get_attribs
{
    my $self = shift;

    my $attrib_names = shift;

    my $cur_dir = $self->{'cur_dir'};

    my (%ret);

    @ret{ @{$attrib_names} } = @{ $cur_dir->{'attrbs'} }{ @{$attrib_names} };

    return \%ret;
}

sub local_set_attribs
{
    my $self = shift;

    my $attribs = shift;

    @{ $self->{'cur_dir'}->{'attrbs'} }{ keys(%$attribs) } = values(%$attribs);

    return 0;
}

sub local_ls
{
    my $self = shift;

    return [ keys(%{$self->{'cur_dir'}->{'subdirs'}}) ];
}

sub local_rmdir
{
    my $self = shift;

    my $subdir_name = shift;

    my $subdirs = $self->{'cur_dir'}->{'subdirs'};

    delete($subdirs->{$subdir_name}->{'..'});
    delete($subdirs->{$subdir_name});

    return (0, "");
}

sub local_unmount
{
    my $self = shift;

    my $cur_dir = $self->{'cur_dir'};

    $cur_dir->{'is_mounted'} = 0;
    delete($cur_dir->{'mounted_pathman'});
    delete($cur_dir->{'mounted_start_path'});

    return 0;
}

sub local_mount
{
    my $self = shift;

    my $new_pathman = shift;
    my $init_path = shift;

    my $cur_dir = $self->{'cur_dir'};

    $cur_dir->{'is_mounted'} = 1;
    $cur_dir->{'mounted_pathman'} = $new_pathman;
    $cur_dir->{'mounted_start_path'} = $init_path;

    return 0;
}
