package Packet::Logic;

use strict;

use IPTables::IPv4::IPQueue qw(:constants);
use NetPacket::IP;
use NetPacket::TCP;

my $t2_ip = "132.68.7.4";

sub new
{
    my $class = shift;
    my $self = {};

    bless $self, $class;

    $self->initialize(@_);

    return $self;
}

sub initialize
{
    my $self = shift;

    srand(24);

    return 0;
}

# This method should return
# $ret == 0 - if the packet should be accepted immidiately
# $ret  > 0 - if the packet should be delayed by $ret quanta
# $ret  < 0 - if the packet should be dropped.
sub decide_what_to_do_with_packet
{
    my $self = shift;

    my $msg = shift;

    if ($msg->data_len())
    {
        my $payload = $msg->payload();

        my $ip = NetPacket::IP->decode($payload);

        my $tcp = NetPacket::TCP->decode(NetPacket::IP::ip_strip($payload));

        if ($ip->{src_ip} eq $t2_ip)
        {
            my $prob = rand(1);

            if ($prob < 0.4)
            {
                return 0;
            }
            elsif ($prob < 0.6)
            {
                return -1;
            }
            else
            {
                my $length = int(rand(3000));

                return $length;
            }            
        }
    }
    else
    {
        return 0;
    }
}
