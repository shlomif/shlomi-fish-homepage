/* -------------------------------------------------------------

   toplevel.cpp (part of Klipper - Cut & paste history for KDE)

   (C) by Andrew Stanley-Jones
   (C) 2000 by Carsten Pfeiffer <pfeiffer@kde.org>

   Generated with the KDE Application Generator

 ------------------------------------------------------------- */

#include <qclipboard.h>
#include <qcursor.h>
#include <qintdict.h>
#include <qmenudata.h>
#include <qpainter.h>
#include <qstrlist.h>
#include <qvbox.h>

#include <kaction.h>
#include <kapp.h>
#include <kconfig.h>
#include <kkeydialog.h>
#include <klocale.h>
#include <kwin.h>
#include <kstringhandler.h>
#include <kiconloader.h>

#include "configdialog.h"
#include "toplevel.h"
#include "urlgrabber.h"


#define QUIT_ITEM    50
#define CONFIG_ITEM  60
#define URLGRAB_ITEM 70

// the <clipboard empty> item
#define EMPTY 6

/* XPM */
static const char*mouse[]={
"20 20 8 1",
"d c #ffa858",
"e c #c05800",
"# c #000000",
"c c #ff8000",
". c None",
"b c #a0a0a4",
"a c #dcdcdc",
"f c #ffffff",
".....###########....",
"..####aaaaaaab####..",
".#cccc#a....b#cccc#.",
".#cd####abbb####de#.",
".#cd#fff####ff.#de#.",
".#cd#fffffffff.#de#.",
".#cd#f.######f.#de#.",
".#cd#fffffffff.#de#.",
".#cd#f.#####ff.#de#.",
".#cd#fffffffff.#de#.",
".#cd#ff#ff#fff.#de#.",
".#cd#ff#f#ffff.#de#.",
".#cd#ff##fffff.#de#.",
".#cd#ff#f#ffff.#de#.",
".#cd#ff#ff#fff.#de#.",
".#cd#fffffffff.#de#.",
".#cd#..........#de#.",
".#cd############de#.",
".#ccccccccccccccde#.",
"..################.."};

void TopLevel::r2lSetTimer(int ms, int (*cb)(void *), void * data)
{
    r2l_timer = new QTimer(kapp, "r2l_timer");
    r2l_timer->start(ms, FALSE);
    r2lTimer_callback = cb;
    r2lTimer_data = data;
    connect(
        r2l_timer,
        SIGNAL(timeout()) , 
        this,
        SLOT(r2lTimer())
        );
}

void TopLevel::r2lTimer()
{
    r2lTimer_callback(r2lTimer_data);
}

TopLevel::TopLevel()
  : KMainWindow(0)
{
    clip = kapp->clipboard();
    pSelectedItem = -1;

    toggleURLGrabAction = new KToggleAction( this );
    toggleURLGrabAction->setEnabled( true );

    myURLGrabber = 0L;
    KConfig *kc = kapp->config();
    readConfiguration( kc );
    setURLGrabberEnabled( bURLGrabber );

    QSlast = "";
    pQPMmenu = new KPopupMenu(0x0, "main_menu");
    connect(pQPMmenu, SIGNAL(activated(int)),
            this, SLOT(clickedMenu(int)));

    pQIDclipData = new QIntDict<QString>();
    pQIDclipData->setAutoDelete(TRUE);

    readProperties(kapp->config());
    connect(kapp, SIGNAL(saveYourself()), SLOT(saveProperties()));

    pQTcheck = new QTimer(this, "timer");
    pQTcheck->start(1000, FALSE);
    connect(pQTcheck, SIGNAL(timeout()),
            this, SLOT(newClipData()));
    pQPpic = new QPixmap(mouse);
    resize( pQPpic->size() );

    globalKeys = new KGlobalAccel();
    KGlobalAccel* keys = globalKeys;
#include "klipperbindings.cpp"
    globalKeys->connectItem("show-klipper-popupmenu", this,
                            SLOT(slotPopupMenu()));
    globalKeys->connectItem("repeat-last-klipper-action", this,
                            SLOT(slotRepeatAction()));
    globalKeys->connectItem("toggle-clipboard-actions", this,
                            SLOT( toggleURLGrabber()));
    globalKeys->readSettings();
    toggleURLGrabAction->setAccel( globalKeys->currentKey( "toggle-clipboard-actions" ));


    connect( toggleURLGrabAction, SIGNAL( toggled( bool ) ), this,
             SLOT( setURLGrabberEnabled( bool )));
    setBackgroundMode(X11ParentRelative);

    mybox = new QVBox(this);
    mybox->setMargin(0);
    mybox->move(0,0);
    mybox->setMinimumSize(15,30);
    mybox->resize(15,30);

    
    on_off_button = new QPushButton("1", mybox);
    r2l_button = new QPushButton("<", mybox);    

    on_off_button->setMinimumSize(10,10);
    //on_off_button->setMaximumSize(10,10);
    on_off_button->resize(10,10);
    r2l_button->setMinimumSize(10,10);
    //r2l_button->setMaximumSize(10,10);
    r2l_button->resize(10,10);

    connect(
        on_off_button,
        SIGNAL( clicked() ),
        this,
        SLOT( r2lOnOffButtonPressed() )
        );
    
    connect(
        r2l_button,
        SIGNAL( clicked() ),
        this,
        SLOT ( r2lRtlButtonPressed() )
        );
}

TopLevel::~TopLevel()
{
    delete globalKeys;
    delete pQTcheck;
    delete pQPMmenu;
    delete pQIDclipData;
    delete pQPpic;
    delete myURLGrabber;
}

void TopLevel::mousePressEvent(QMouseEvent *e)
{
    if ( e->button() == LeftButton || e->button() == RightButton )
        showPopupMenu( pQPMmenu );
}

void TopLevel::paintEvent(QPaintEvent *)
{
  QPainter p(this);



}

void TopLevel::newClipData()
{
    QString clipData = clip->text().stripWhiteSpace();
    // If the string is null bug out
    if(clipData.isEmpty()) {
	if (pSelectedItem != -1) {
            pQPMmenu->setItemChecked(pSelectedItem, false);
	    pSelectedItem = -1;
	}
        return;
    }

    if(clipData != QSlast) {
        QSlast = clipData.copy();

        QString *data = new QString(clipData);

        if ( bURLGrabber && myURLGrabber ) {
            if ( myURLGrabber->checkNewData( clipData ))
                return; // don't add into the history
        }


        if (bClipEmpty) { // remove <clipboard empty> from popupmenu and dict
            if (*data != QSempty) {
                bClipEmpty = false;
                pQPMmenu->removeItemAt(EMPTY);
                pQIDclipData->clear();
            }
        }

        while(pQPMmenu->count() > 12){
            int id = pQPMmenu->idAt(EMPTY);
            pQIDclipData->remove(id);
            pQPMmenu->removeItemAt(EMPTY);

        }
        if(clipData.length() > 50){
            clipData.truncate(47);
            clipData.append("...");
        }
        long int id = pQPMmenu->insertItem(KStringHandler::csqueeze(clipData.simplifyWhiteSpace(), 45), -2, -1); // -2 means unique id, -1 means at end
        pQIDclipData->insert(id, data);

        if (pSelectedItem != -1)
            pQPMmenu->setItemChecked(pSelectedItem, false);
        pSelectedItem = id;
        pQPMmenu->setItemChecked(pSelectedItem, true);
    }
}

void TopLevel::clickedMenu(int id)
{
    switch ( id ) {
    case -1:
        break;
    case CONFIG_ITEM:
        slotConfigure();
        break;
    case QUIT_ITEM:
        saveProperties();
        kapp->quit();
        break;
    case URLGRAB_ITEM: // handled with an extra slot
	break;
    default:
        pQTcheck->stop();
        //CT mark up the currently put into clipboard - so that user can see later
        pQPMmenu->setItemChecked(pSelectedItem, false);
        pSelectedItem = id;
        pQPMmenu->setItemChecked(pSelectedItem, true);
        QString *data = pQIDclipData->find(id);
        if(data != 0x0 && *data != QSempty){
            clip->setText(*data);
            if (bURLGrabber && bReplayActionInHistory)
                myURLGrabber->checkNewData(*data);
            QSlast = data->copy();
        }

        pQTcheck->start(1000);
    }
}


void TopLevel::showPopupMenu( QPopupMenu *menu )
{
    ASSERT( menu != 0L );

    menu->move(-1000,-1000);
    menu->show();
    menu->hide();

    if (bPopupAtMouse) {
        QPoint g = QCursor::pos();
        if ( menu->height() < g.y() )
            menu->popup(QPoint( g.x(), g.y() - menu->height()));
        else
            menu->popup(QPoint(g.x(), g.y()));
    }

    else {
        KWin::Info i = KWin::info( winId() );
        QRect g = i.geometry;

        if ( g.x() > QApplication::desktop()->width()/2 &&
             g.y() + menu->height() > QApplication::desktop()->height() )
            menu->popup(QPoint( g.x(), g.y() - menu->height()));
        else
            menu->popup(QPoint( g.x() + width(), g.y() + height()));

        //      menu->exec(mapToGlobal(QPoint( width()/2, height()/2 )));
    }
}


void TopLevel::readProperties(KConfig *kc)
{
  QStringList dataList;
  pQPMmenu->clear();
  pQPMmenu->insertTitle(kapp->miniIcon(), i18n("Klipper - Clipboard Tool"));
  pQPMmenu->insertItem(SmallIcon("exit"), i18n("&Quit"), QUIT_ITEM );
  pQPMmenu->insertSeparator();
  pQPMmenu->insertItem(SmallIcon("configure"), i18n("&Preferences..."), CONFIG_ITEM);
  // we can't specify the id in plug(), just the index. So we set the right
  // id aftwards for the given index.
  toggleURLGrabAction->plug( pQPMmenu, URLGRAB_ITEM );
  pQPMmenu->setId( URLGRAB_ITEM, URLGRAB_ITEM );
  pQPMmenu->insertSeparator();
  long int id;

  if (bKeepContents) { // load old clipboard if configured
      KConfigGroupSaver groupSaver(kc, "General");
      dataList = kc->readListEntry("ClipboardData");

      for (QStringList::ConstIterator it = dataList.begin();
           it != dataList.end(); ++it)
      {
          id = pQPMmenu->insertItem( KStringHandler::csqueeze(*it, 45), -2, -1 );
          pQIDclipData->insert( id, new QString( *it ));
      }
  }

  QSempty = i18n("<empty clipboard>");
  bClipEmpty = ((QString)clip->text()).simplifyWhiteSpace().isEmpty() && dataList.isEmpty();

  if(bClipEmpty)
    clip->setText(QSempty);
  newClipData();
}


void TopLevel::readConfiguration( KConfig *kc )
{
    kc->setGroup("General");
    bPopupAtMouse = kc->readBoolEntry("PopupAtMousePosition", false);
    bKeepContents = kc->readBoolEntry("KeepClipboardContents", true);
    bURLGrabber = kc->readBoolEntry("URLGrabberEnabled", false);
    bReplayActionInHistory = kc->readBoolEntry("ReplayActionInHistory", false);
}

void TopLevel::writeConfiguration( KConfig *kc )
{
    kc->setGroup("General");
    kc->writeEntry("PopupAtMousePosition", bPopupAtMouse);
    kc->writeEntry("KeepClipboardContents", bKeepContents);
    kc->writeEntry("ReplayActionInHistory", bReplayActionInHistory);

    if ( myURLGrabber )
        myURLGrabber->writeConfiguration( kc );

    kc->sync();
}


// session management
void TopLevel::saveProperties()
{
  if (bKeepContents) { // save the clipboard eventually
      QString  *data;
      QStringList dataList;
      KConfig  *kc = kapp->config();
      KConfigGroupSaver groupSaver(kc, "General");
      QIntDictIterator<QString> it( *pQIDclipData );

      while ( (data = it.current()) ) {
          dataList.prepend( *it );
          ++it;
      }

      kc->writeEntry("ClipboardData", dataList);
      kc->sync();
  }
}


void TopLevel::slotConfigure()
{
    bool haveURLGrabber = bURLGrabber;
    if ( !myURLGrabber ) { // temporary, for the config-dialog
        setURLGrabberEnabled( true );
        readConfiguration( kapp->config() );
    }

    KKeyEntryMap map = globalKeys->keyDict();
    ConfigDialog *dlg = new ConfigDialog( myURLGrabber->actionList(),
                                          &map );
    dlg->setKeepContents( bKeepContents );
    dlg->setPopupAtMousePos( bPopupAtMouse );
    dlg->setReplayActionInHistory( bReplayActionInHistory);
    dlg->setPopupTimeout( myURLGrabber->popupTimeout() );
    dlg->setNoActionsFor( myURLGrabber->avoidWindows() );

    if ( dlg->exec() == QDialog::Accepted ) {
        bKeepContents = dlg->keepContents();
        bPopupAtMouse = dlg->popupAtMousePos();
        bReplayActionInHistory = dlg->replayActionInHistory();
        globalKeys->setKeyDict( map );
        globalKeys->writeSettings();
        toggleURLGrabAction->setAccel( globalKeys->currentKey( "toggle-clipboard-actions" ));

        myURLGrabber->setActionList( dlg->actionList() );
        myURLGrabber->setPopupTimeout( dlg->popupTimeout() );
	myURLGrabber->setAvoidWindows( dlg->noActionsFor() );
	
        writeConfiguration( kapp->config() );
    }

    setURLGrabberEnabled( haveURLGrabber );

    delete dlg;
}


void TopLevel::slotRepeatAction()
{
    if ( !myURLGrabber ) {
	myURLGrabber = new URLGrabber();
	connect( myURLGrabber, SIGNAL( sigPopup( QPopupMenu * )),
		 SLOT( showPopupMenu( QPopupMenu * )) );
    }

    myURLGrabber->invokeAction( QSlast );
}

void TopLevel::setURLGrabberEnabled( bool enable )
{
    bURLGrabber = enable;
    toggleURLGrabAction->setChecked( enable );
    KConfig *kc = kapp->config();
    kc->setGroup("General");
    kc->writeEntry("URLGrabberEnabled", bURLGrabber);
    kc->sync();

    if ( !bURLGrabber ) {
        delete myURLGrabber;
        myURLGrabber = 0L;
        toggleURLGrabAction->setText(i18n("Enable &actions"));
    }

    else {
        toggleURLGrabAction->setText(i18n("&Actions enabled"));
        if ( !myURLGrabber ) {
            myURLGrabber = new URLGrabber();
            connect( myURLGrabber, SIGNAL( sigPopup( QPopupMenu * )),
                     SLOT( showPopupMenu( QPopupMenu * )) );
        }
    }
}

void TopLevel::toggleURLGrabber()
{
    setURLGrabberEnabled( !bURLGrabber );
}
#include "toplevel.moc"
