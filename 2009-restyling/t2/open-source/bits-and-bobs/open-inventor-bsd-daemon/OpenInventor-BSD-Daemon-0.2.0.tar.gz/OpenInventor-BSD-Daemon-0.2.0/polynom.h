#ifdef __cplusplus
extern "C"
{
#endif

struct polynom_struct
{
    int num_points;
    float * coeffs;
};

typedef struct polynom_struct polynom_t;

polynom_t * polynom_alloc(int num_points, const float * coeffs);
void polynom_free(polynom_t * p);
polynom_t * polynom_add(polynom_t * a, polynom_t * b);
float polynom_eval(polynom_t * p, float value);
polynom_t * polynom_mult(polynom_t * a, polynom_t * b);
void polynom_factor(polynom_t * p, float factor);
polynom_t * polynom_get_bezier(int n, float * p_ks);

    
#ifdef __cplusplus
};
#endif
