/* -------------------------------------------------------------

   toplevel.h (part of Klipper - Cut & paste history for KDE)

   (C) by Andrew Stanley-Jones

   Generated with the KDE Application Generator

 ------------------------------------------------------------- */


#ifndef _TOPLEVEL_H_
#define _TOPLEVEL_H_

#include <kapp.h>
#include <kglobalaccel.h>
#include <kmainwindow.h>
#include <kpopupmenu.h>
#include <qintdict.h>
#include <qtimer.h>
#include <qpixmap.h>
#include <qvbox.h>

class QClipboard;
class KToggleAction;
class URLGrabber;

class TopLevel : public KMainWindow
{
  Q_OBJECT

public:
    TopLevel();
    ~TopLevel();

    KGlobalAccel *globalKeys;

    QPushButton * on_off_button;
    QPushButton * r2l_button;
    QTimer * r2l_timer;
    int (*r2lTimer_callback)(void *);
    void * r2lTimer_data;
    void r2lSetTimer(int ms, int (*cb)(void *), void * data);
    int on_off_state, rtl_state;
    void * ui_;

protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
    void readProperties(KConfig *);
    void readConfiguration(KConfig *);
    void writeConfiguration(KConfig *);

protected slots:
    void slotPopupMenu() { showPopupMenu( pQPMmenu ); }
    void showPopupMenu( QPopupMenu * );
    void saveProperties();
    void r2lTimer();
    void r2lOnOffButtonPressed();
    void r2lRtlButtonPressed();

private slots:
    void clickedMenu(int);

private:
    QClipboard *clip;

    QString QSlast;
    KPopupMenu *pQPMmenu;
    QTimer *pQTcheck;
    QPixmap *pQPpic;
    bool bPopupAtMouse, bClipEmpty, bKeepContents, bURLGrabber, bReplayActionInHistory;
    QString QSempty;
    int pSelectedItem;
    QVBox * mybox;
};

#endif
