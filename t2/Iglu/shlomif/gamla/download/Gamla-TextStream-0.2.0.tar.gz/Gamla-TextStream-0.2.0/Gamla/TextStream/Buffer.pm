package Gamla::TextStream::Buffer;

use strict;

use Gamla::TextStream;

use vars qw(@ISA);

@ISA=qw(Gamla::TextStream);

my $class_name = "Gamla::TextStream::Buffer";

sub initialize
{
    my $self = shift;

    my $func_name = "initialize";

    $self->{'buffer'} = "";

    return ([[0, $class_name."::".$func_name."()", ""]], [ @_ ]);
}

sub append
{
    my $self = shift;

    $self->{'buffer'} .= shift;

    return 0;
}

# We don't have to flush
sub flush
{
    return 0;
}

sub get_buffer
{
    my $self = shift;

    return $self->{'buffer'};
}
