package Gamla::Object;

use strict;

use Arad::Object;

use vars qw(@ISA);

@ISA=qw(Arad::Object);

