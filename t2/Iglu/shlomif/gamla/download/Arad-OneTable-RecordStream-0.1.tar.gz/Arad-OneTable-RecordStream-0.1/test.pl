use Arad::OneTable::RecordStream::PerlArray;

use strict;

my @employees = 
(
{
	'first_name' => 'Shlomi',
	'last_name' => 'Fish',
	'phone' => '03-6424668',
},
{
	'first_name' => 'Ron',
	'last_name' => 'Zwanzinger',
	'phone' => '04-5673901',
},
{
	'first_name' => "Falk",
	'last_name' => "Fish",
	'phone' => "09-7129087",
},
{
	'first_name' => "Oded",
	'last_name' => "Golombek",
	'phone' => "04-8203333",
},
{
	'first_name' => 'Shlomi',
	'last_name' => 'Fish',
	'phone' => '03-6424668',
},
{
	'first_name' => 'Ron',
	'last_name' => 'Zwanzinger',
	'phone' => '04-5673901',
},
{
	'first_name' => "Falk",
	'last_name' => "Fish",
	'phone' => "09-7129087",
},
{
	'first_name' => "Oded",
	'last_name' => "Golombek",
	'phone' => "04-8203333",
},
{
	'first_name' => 'Shlomi',
	'last_name' => 'Fish',
	'phone' => '03-6424668',
},
{
	'first_name' => 'Ron',
	'last_name' => 'Zwanzinger',
	'phone' => '04-5673901',
},
{
	'first_name' => "Falk",
	'last_name' => "Fish",
	'phone' => "09-7129087",
},
{
	'first_name' => "Oded",
	'last_name' => "Golombek",
	'phone' => "04-8203333",
},
{
	'first_name' => 'Shlomi',
	'last_name' => 'Fish',
	'phone' => '03-6424668',
},
{
	'first_name' => 'Ron',
	'last_name' => 'Zwanzinger',
	'phone' => '04-5673901',
},
{
	'first_name' => "Falk",
	'last_name' => "Fish",
	'phone' => "09-7129087",
},
{
	'first_name' => "Oded",
	'last_name' => "Golombek",
	'phone' => "04-8203333",
},
);

my $stream = Arad::OneTable::RecordStream::PerlArray->new(\@employees);


my $r;

$stream->skip(1);
while ($r = $stream->get_next_record())
{
	printf("%-20s%-20s%-20s\n", @{$r}{'first_name','last_name','phone'});
}

