#ifndef R2LLIB_H_
#define R2LLIB_H_

#ifdef __cplusplus
extern "C" {
#endif

/** the possible R2L states */
typedef enum
{
     R2L_ENABLED = 0, 
     R2L_DISABLED,
     R2L_ERROR
} R2L_STATE;

/** the possible biditext base states */
typedef enum
{
     BT_BASE_NEUTRAL = 0,     /**< A good default        */
     BT_BASE_LTR,             /**< Force LTR ("English") */
     BT_BASE_RTL,             /**< Force RTL ("Hebrew")  */
     BT_BASE_ERROR            /**< An invalid value      */
} BIDITEXT_BASE_STATE;

typedef enum
{
     R2L_SUCCESS = 0,         /**< No error                                     */
     R2L_ERR_OOM,             /**< We ran out of memory                         */
     R2L_ERR_INVALID_REPR,    /**< The user passed us an invalid representation */
     R2L_ERR_ACCESS           /**< We cannot access the file the user specified */ 
} R2L_ERROR_TYPE;

typedef struct r2llib_type * r2llib_t;

/** implemented in r2llib.c */

/**
 * initalize the r2l library.
 * parse argv and remove the following options (if they were given)
 * * --r2l-file-name [file-name]
 * @returns a valid r2lib_t for use in subsequent calls to the r2l library.
 *  or NULL if initialization failed. If err was supplied, returns in it the 
 *  reason for failure if we failed, otherwise err is unchanged
 */
r2llib_t r2l_init(int* argc, char* argv[], R2L_ERROR_TYPE* err);

/** @return a serialized encoding of this rtl, in plain text */
const char* r2l_get_text_serialization(r2llib_t rtl);

/** @return a new r2l token from this textual representation 
 *   if err was supplied, return in it the reason for failure if we failed
 *   otherwise err is unchanged
 */
r2llib_t 
r2l_init_from_text_serialization(const char* repr, R2L_ERROR_TYPE* err);

/** perform cleanup */
void r2l_destroy(r2llib_t rtl);

/** @return in r2l_state the current r2l_state and in bt_state
 *   the current biditext base state. Passing NULL for either is
 *   allowed.
 */
void r2l_query_state(r2llib_t rtl, R2L_STATE* r2l_state, 
		     BIDITEXT_BASE_STATE* bt_state);

/** set the R2L state and biditext base state to the states specified
 *  in r2l_state and bt_state. You may pass NULL for either, which means 
 *  'keep the current state'. 
 *  @return in r2l_state and bt_state the current state after setting it
 */
void r2l_set_state(r2llib_t rtl, 
		   R2L_STATE* r2l_state,
		   BIDITEXT_BASE_STATE* bt_state);


/** @return 1 on success, -1 on failure */
int r2l_enable(r2llib_t rtl);

/** @return 1 on success, -1 on failure */
int r2l_disable(r2llib_t rtl);

/** @return 1 on success, -1 on failure */
int r2l_toggle(r2llib_t rtl);

/** @return the R2L_STATE on success, and STATE_ERROR on failure */
R2L_STATE r2l_get_current_r2l_state(r2llib_t rtl);

/** @return 1 on success, -1 on failure */
int 
r2l_set_biditext_base_state_neutral(r2llib_t rtl);

/** @return 1 on success, -1 on failure */
int
r2l_set_biditext_base_state_rtl(r2llib_t rtl);

/** @return 1 on success, -1 on failure */
int 
r2l_set_biditext_base_state_ltr(r2llib_t rtl);

/** @return the base biditext state on succes, BT_ERROR on failure */
BIDITEXT_BASE_STATE
r2l_get_current_biditext_base_state(r2llib_t rtl);


#ifdef __cplusplus
}
#endif

#endif /* R2LLIB_H_ */
