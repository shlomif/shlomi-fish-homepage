#!/bin/bash

source twiki-install-common.bash

cat <<EOHTTPD
# TWiki Installation 
 
ScriptAlias /${www_base}/bin/ "${dest_dir}/bin/"
Alias /${www_base}/ "${dest_dir}/"
<Directory "${dest_dir}/bin">
   Options +ExecCGI
   SetHandler cgi-script
   Allow from all
</Directory>
<Directory "${dest_dir}/pub">
   Options FollowSymLinks +Includes
   AllowOverride None
   Allow from all
</Directory>
<Directory "${dest_dir}/data">
   deny from all
</Directory>
<Directory "${dest_dir}/templates">
   deny from all
</Directory>

# End of TWiki Installation
EOHTTPD


