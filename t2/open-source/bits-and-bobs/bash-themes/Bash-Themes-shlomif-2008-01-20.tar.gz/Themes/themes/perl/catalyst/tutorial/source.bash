load_common completion
# load_common gen_patch

base="$HOME/progs/perl/www/Catalyst/tutorial-examples"
tutorial_app="$base/MyApp"
reference_impl="$base/examples-tutorial-reference-implementation"
this="$tutorial_app"

# Make sure that gvim's filename completion ignores filenames that it should
# not edit.

cd $this

