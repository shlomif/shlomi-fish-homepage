# Arad::UI::Tk - The Perl/Tk user-interface.
#
# Most of the functionality is in Arad::UI::Tk::TableEditDialog,
# so this is pretty basic stuff.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)

package Arad::UI::Tk;

use Arad::UI;

@ISA = qw(Arad::UI);

use strict;

use Arad::UI::Tk::TableEditDialog;

sub initialize
{
    my $self = shift;

    
}

sub create_new_dialog
{
    my $self = shift;

    my $what = shift;

    my $options = shift;

    my $dialog = undef;

    if ($what->{'type'} eq 'table')
    {
        $dialog = Arad::UI::Tk::TableEditDialog->new($self, $options);
    }

    return $dialog;
}

{
    my %type_map =
        (
         'yes-no' => 'YesNo',
         'ok' => 'OK'
         );

    # Display a message box. Currently supported types are "ok" and "yes-no".
sub message_box
{
    my $self = shift;

    my $text = shift;
    my $type = shift;
    my $window = shift;

    my $button = $window->messageBox(-type => $type_map{$type}, -message => $text);

    if ($button eq 'Yes')
    {
        return 'yes';
    }
    elsif ($button eq 'No')
    {
        return 'no';
    }

    return 0;
}
}
1;