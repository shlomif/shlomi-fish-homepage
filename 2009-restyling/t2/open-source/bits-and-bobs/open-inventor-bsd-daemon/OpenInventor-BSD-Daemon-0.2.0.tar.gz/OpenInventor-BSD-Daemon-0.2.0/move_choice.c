#include <Xm/Form.h>
#include <Xm/RowColumn.h>

#include "move_choice.h"

Widget move_choice_dialog;
static Widget move_choice_radio_box;
enum PATH_TYPE type_of_path = PATH_BEZIER;
enum PATH_TYPE new_type_of_path = PATH_BEZIER;

static void toggled (Widget widget, XtPointer client_data, XtPointer call_data)
{
    int which = (int) client_data;
    
    if (which)
    {
        new_type_of_path = PATH_BEZIER;
    }
    else
    {
        new_type_of_path = PATH_MATRIX;
    }
}

void create_move_choice_dialog(Widget pb)
{
    Arg args[50];
    int n = 0;
    XmString matrix, bezier;
    

    XtSetArg (args[n], XmNautoUnmanage, False); n++;
    XtSetArg (args[n], XmNuserData, 0); n++;
    XtSetArg (args[n], XmNfractionBase, 1); n++;
        
    move_choice_dialog = XmCreateFormDialog (pb, "Move Choice", args, n);
    
    matrix = XmStringCreateLocalized("Matrix Transformation");
    bezier = XmStringCreateLocalized("Bezier Curve");
    
    
    move_choice_radio_box =
        XmVaCreateSimpleRadioBox(
            move_choice_dialog,
            "move_choice_radio",
            0,
            toggled,
            XmVaRADIOBUTTON, matrix, NULL, NULL, NULL,
            XmVaRADIOBUTTON, bezier, NULL, NULL, NULL,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNbottomAttachment, XmATTACH_POSITION,
            XmNbottomPosition, 1,
            XmNleftPosition, 0,
            XmNrightPosition, 1,
            XmNleftAttachment, XmATTACH_POSITION,
            XmNrightAttachment, XmATTACH_POSITION,
            NULL
            );

    XmStringFree(matrix);
    XmStringFree(bezier);

    XtManageChild(move_choice_radio_box);
    
    XtManageChild(move_choice_dialog);
}
