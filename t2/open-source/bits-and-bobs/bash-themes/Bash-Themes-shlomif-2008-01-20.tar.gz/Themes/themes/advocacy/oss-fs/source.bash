load_common mymake

this="$HOME/Svn/Docs/Philosophy/IP/OSS_FS/docbook"

cd $this


