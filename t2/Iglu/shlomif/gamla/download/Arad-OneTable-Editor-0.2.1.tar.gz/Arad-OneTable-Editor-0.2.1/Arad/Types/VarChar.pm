# Arad::Types::VarChar - an SQL "varchar" data type. (variable length string).
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)

package Arad::Types::VarChar;

use Arad::Types::Base;

@ISA = qw(Arad::Types::Base);

use strict;

sub initialize
{
    my $self = shift;

    $self->{'type'} = 'varchar';
}

sub check_value
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if (length($value) > $type_params->{'len'})
    {
        return (1, "The length of \$F must be shorter than " . $type_params->{'len'} . " bytes.");
    }
    else
    {
        return (0, "");
    }
}

sub to_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value eq undef)
    {
        return (0, "null");
    }

    return (3, $value);
}

sub from_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;    

    return $value;
}

sub compare
{
    my $self = shift;

    my $type_params = shift;

    my $value1 = shift;
    my $value2 = shift;

    return ($value1 cmp $value2);
}
