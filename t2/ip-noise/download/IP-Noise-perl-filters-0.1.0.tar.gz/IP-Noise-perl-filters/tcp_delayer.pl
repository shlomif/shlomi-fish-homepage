# tcp_delayer.pl
#
# This script delays incoming and outgoing traffic from t2.technion.ac.i
# by 0.5 seconds.
#
# It relies on two assumptions:
# 
# 1. That there is a constant traffic through the filter.
# 2. That all packets are delayed for a constant duration.
#
# A better implementation would be by using a separate thread that would 
# release the delayed packets in time, but this is a proof of concept program.
#
# Copyright (c) 2000-2001 James Morris <jmorris@intercode.com.au>
# This code is GPL.
#
# Modified by Shlomi Fish <shlomif@vipe.technion.ac.il>, 2001
# 

package ipq_example;
use strict;
$^W = 1;

use IPTables::IPv4::IPQueue qw(:constants);
use NetPacket::IP;
use NetPacket::TCP;

use Time::HiRes qw(gettimeofday);

srand(24);

sub dump_payload
{
	my ($payload, $ip, $tcp);
	
	$payload = shift;

	#
	# IP Header
	#
	$ip = NetPacket::IP->decode($payload);
	
    $tcp = NetPacket::TCP->decode(NetPacket::IP::ip_strip($payload));

    my $verdict;

    # Drop all packets to or from the host "t2.technion.ac.il"

    my $t2_ip = "132.68.7.4";

    $verdict = ( ($ip->{src_ip} eq $t2_ip) || 
                 ($ip->{dest_ip} eq $t2_ip) ); 
    
    if (0)
    {
        if ($verdict)
        {
            # Generate a random number between 0 and 1
            my $prob_value = rand(1); 
            # Drop the packet in a probability of 0.5
            $verdict = ($prob_value < 0.5); 
        }
    }

    return $verdict;
}

sub dump_meta
{
	my $msg = shift;

	print <<EOT;
[ Metadata ]
Packet ID         : @{[ $msg->packet_id() ]}
Mark              : @{[ $msg->mark() ]}
Timestamp (sec)   : @{[ $msg->timestamp_sec() ]}
Timestamp (usec)  : @{[ $msg->timestamp_usec() ]}
Hook              : @{[ $msg->hook() ]}
In Device         : @{[ $msg->indev_name() ]}
Out Device        : @{[ $msg->outdev_name() ]}
HW Protocol       : @{[ $msg->hw_protocol() ]}
HW Type           : @{[ $msg->hw_type() ]}
HW Address Length : @{[ $msg->hw_addrlen() ]}
HW Address        : @{[ unpack('H*', $msg->hw_addr()) ]}
Data Length       : @{[ $msg->data_len() ]}
EOT
}

sub main
{
    my @messages_to_delay_queue = ();
    
	my $queue = new IPTables::IPv4::IPQueue(copy_mode => IPQ_COPY_PACKET,
	                                        copy_range => 2048)
		or die IPTables::IPv4::IPQueue->errstr;

	while (1) {
		my $msg = $queue->get_message()
			or die IPTables::IPv4::IPQueue->errstr;
        my ($seconds, $microseconds) = gettimeofday();

        # As long as there are messages in the delay queue that need to
        # be released by now - release them.
        while (scalar(@messages_to_delay_queue) > 0)
        {
            my $first_one = $messages_to_delay_queue[0];

            # Check if the time of this message has come
            if (($seconds > $first_one->{'sec'}) ||
                  ( 
                    ($first_one->{'sec'} == $seconds)        &&
                    ($microseconds >= $first_one->{'usec'}) 
                  )
               )
            {
                my $delayed_msg = $first_one->{'msg'};
                $queue->set_verdict($delayed_msg->packet_id, NF_ACCEPT);
                
                # Remove it from the queue
                shift(@messages_to_delay_queue);
            }
            else
            {
                # No more corresponding messages so let's exit this loop.
                last;
            }
        }
	
		my $verdict = dump_payload($msg->payload()) if $msg->data_len();
        if ($verdict)
        {
            # Find the time to delay
            my $delay_to_microseconds = $microseconds + 500000;
            my $delay_to_seconds = $seconds;
            if ($delay_to_microseconds >= 1000000)
            {
                $delay_to_seconds += int($delay_to_microseconds/1000000);
                $delay_to_microseconds %= 1000000;
            }
            
            # Enqueue the message in the delayed messages queue
            push @messages_to_delay_queue, 
                {
                    'msg' => $msg,
                    'sec' => $delay_to_seconds,
                    'usec' => $delay_to_microseconds,
                }
                ;
        }
        else
        {
		    $queue->set_verdict($msg->packet_id, NF_ACCEPT);
        }
	}
}

main();
