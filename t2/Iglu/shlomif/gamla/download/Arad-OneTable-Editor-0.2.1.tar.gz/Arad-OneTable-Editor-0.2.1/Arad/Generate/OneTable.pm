package Arad::Generate::OneTable;

use strict;

use Getopt::Long;


my $default_editor_module = "Arad::Templates::MyTable";
my $default_spec_module = "Arad::Templates::MyTable::SPEC";


sub initialize
{
    my $self = shift;
}

sub new
{
    my $class = shift(@_);
    my $self = {};
    bless $self, $class;

    $self->initialize(@_);

    return $self;
}

my @options =
(
 {
     'option' => 'database',
     'type' => 'string',
     'default' => '',
     'help1' => "--database=[Database name]",
     'help2' => "Sets the database name. (doesn't apply to DBI)",
 },   
 {
     'option' => 'db-type',
     'type' => 'string',
     'default' => 'DBI',
     'help1' => "--db-type=[database type]",
     'help2' => ("Sets the database type. Supported Values:\n" .
         "\tDBI (default) - DBI connection\n" .
         "\tPostgres - Postgres Database")
 },
 {
     'option' => 'dbi-init',
     'type' => 'string',
     'default' => '',
     'help1' => "--dbi-init=[DBI's Initialization code]",
     'help2' => "Code to intialize the database to ISO Date style"
 },

 {
     'option' => 'dsn',
     'type' => 'string',
     'default' => '',
     'help1' => "--dsn=[DBI's DSN]",
     'help2' => "Sets the DBI's DSN."
 }, 
 {
     'option' => 'default-editor',
     'type' => 'bool',
     'default' => 0,
     'help1' => '--default-editor',
     'help2' => 'Use the default table editor (Arad::Templates::MyTable)',
 },
 {
     'option' => 'help',
     'type' => 'bool',
     'default' => 0,
     'help1' => '--help',
     'help2' => 'Display this help screen',
 },
 {
     'option' => 'host',
     'type' => 'string',
     'default' => '',
     'help1' => "--host=[Host name or IP]",
     'help2' => "Sets the database's host. (doesn't apply to DBI)",
 },    
 {
     'option' => 'module',
     'type' => 'string',
     'default' => 'MyTable',
     'help1' => "--module=[editor's module name]",
     'help2' => "Sets the editor's module name.",
 },
 {
     'option' => 'only-script',
     'type' => 'bool',
     'default' => 0,
     'help1' => '--help',
     'help2' => "Generate only the script file without creating the Modules",
 },
 
 {
     'option' => 'password',
     'type' => 'string',
     'default' => '',
     'help1' => "--password=[Password]",
     'help2' => "Sets the password for the database login. (doesn't apply to DBI)",
 },
 {
     'option' => 'perl',
     'type' => 'string',
     'default' => '',
     'help1' => "--perl=[Path to perl executable]",
     'help2' => "Specifies the path to the perl executable (Default: \"/usr/bin/perl\")",
 },


 {
     'option' => 'port',
     'type' => 'string',
     'default' => '',
     'help1' => "--port=[Port Number]",
     'help2' => "Sets the port number of the database server. (doesn't apply to DBI)",
 },   
 
 {
     'option' => 'script',
     'type' => 'string',
     'default' => 'table.pl',
     'help1' => "--script=[script's filename]",
     'help2' => "Sets the filename of the script that will be used to invoke the table dialog",
 }, 
 {
     'option' => 'spec-module',
     'type' => 'string',
     'default' => '',
     'help1' => "--spec-module=[SPEC's module name]",
     'help2' => "Sets the SPEC's module name. (By default \$module::SPEC)",
 },  
 {
     'option' => 'ui',
     'type' => 'string',
     'default' => 'Tk',
     'help1' => "--ui=[user-interface type]",
     'help2' => ("Sets the user-interface. Supported Values:\n" .
         "\ttext - Text/ReadLine user-interface\n" .
         "\tTk (default) - Perl/Tk user-interface")
 },
 {
     'option' => 'username',
     'type' => 'string',
     'default' => '',
     'help1' => "--username=[Username]",
     'help2' => "Sets the username for the database login. (doesn't apply to DBI)",
 },   

 );

sub copy_file
{
    my $self = shift;

    my $module = shift;
    my $orig_module = shift;

    my $editor_module = shift;
    my $spec_module = shift;

    my $module_fn = $module;

    $module_fn =~ s!::!/!g;
    $module_fn .= '.pm';

    my $orig_module_fn = $orig_module;

    $orig_module_fn =~ s!::!/!g;
    $orig_module_fn .= '.pm';

    my ($inc, $text, @portions, $i, $dir);

    foreach $inc (@INC)
    {
        if (-e ($inc . "/" . $orig_module_fn))
        {
            open I, ("<" . $inc . "/" . $orig_module_fn);
            $text = join("", <I>);
            close(I);

            last;            
        }
    }
    if (! defined($text))
    {
        print STDERR ("Could not find " . $orig_module . " in the include path. Arad does not seems to be installed.\n");
        return 1;
    }

    $text =~ s!$default_spec_module!$spec_module!g;
    $text =~ s!$default_editor_module!$module!g;

    $text =~ s!^[\x00-\xFF]*?#-+!!;

    @portions = split(m!/!, $module_fn);

    for($i=0;$i<scalar(@portions)-1;$i++)
    {
        $dir = join("/", @portions[0 .. $i]);

        if ((-e $dir) && (! -d $dir))
        {
            print STDERR ($dir . " exists and is not a directory. Unable to create module " . $module_fn . "\n");
            return 2;
        }
        elsif (! -e $dir)
        {                    
            mkdir($dir, 0777);
        }
    }

    open O, (">" . $module_fn);
    print O $text;
    close(O);
    
    return 0;
}

sub generate
{
    my $self = shift;

    my (%optctl, @opt_descriptors, $o);

    foreach $o (@options)
    {
        $optctl{$o->{'option'}} = eval { my $opt_var = $o->{'default'} ; \$opt_var ; };
        if ($o->{'type'} eq 'string')
        {
            push @opt_descriptors, ($o->{'option'} . "=s");
        }
        elsif ($o->{'type'} eq 'bool')
        {
            push @opt_descriptors, ($o->{'option'} . "!");
        }
    }

    GetOptions(\%optctl, @opt_descriptors);

    if (${$optctl{'help'}})
    {
        print "perl arad_generate.pl [options] - generate an Arad distribution.\n\n";
        print "Available options:\n";
        foreach $o (@options)
        {
            print $o->{'help1'}, "\n";
            my $text = $o->{'help2'};
            $text =~ s!^!\t!mg;
            print $text, "\n";
        }
    }
    else
    {
        my $def_editor = ${$optctl{'default-editor'}};
        my $module = ${$optctl{'module'}};

        if (! $module)
        {
            $module = 'MyTable';
        }

        my $spec_module = ${$optctl{'spec-module'}};

        if (! $spec_module)
        {
            $spec_module = ($module . "::SPEC");
        }

        
        if (! ${$optctl{'only-script'}})
        {
            if (! $def_editor)
            {
                $self->copy_file($module, $default_editor_module, $module, $spec_module);
            }
            $self->copy_file(
                             $spec_module,
                             $default_spec_module,
                             ($def_editor ? $default_editor_module : $module),
                             $spec_module
                            );
        }

        my $script_fn = ${$optctl{'script'}};

        if (($script_fn eq "") || (! defined($script_fn)))
        {
            $script_fn = 'table.pl';
        }
        
        open O, (">" . $script_fn);

        my $perl_path = ${$optctl{'perl'}};

        if (! $perl_path)
        {
            $perl_path = "/usr/bin/perl";
        }
        
        print O "#!" . $perl_path . "\n\n";
        if ($def_editor)
        {
            print O "use " . $default_editor_module . ";\n";
        }
        else
        {
            print O "use " . $module . ";\n";
        }
        print O "use " . $spec_module . ";\n";
        print O "\n";

        print O "use Arad::Types;\n";

        my $db_type = ${$optctl{'db-type'}};

        $db_type = lc($db_type);

        if (($db_type ne 'dbi') && ($db_type ne 'postgres'))
        {
            $db_type = 'dbi';
        }

        if ($db_type eq 'dbi')
        {
            print O "use Arad::SQL::DBI;\n";
        }
        elsif ($db_type eq 'postgres')
        {
            print O "use Arad::SQL::Postgres;\n";
        }
        
        my $ui = ${$optctl{'ui'}};

        $ui = lc($ui);

        if (($ui ne 'text') && ($ui ne 'tk'))
        {
            $ui = 'tk';
        }

        if ($ui eq 'tk')
        {
            print O "use Arad::UI::Tk;\n";
        }
        elsif ($ui eq 'text')
        {
            print O "use Arad::UI::Text;\n";
        }

        print O "\n";

        print O "my \$sql = " . (($db_type eq 'dbi') ? "Arad::SQL::DBI" : (($db_type eq 'postgres') ? "Arad::SQL::Postgres" : "")) . "->new();\n";
        print O "\n";
        print O "my \$types = Arad::Types->new(\$sql);\n";
        print O "\n";
        print O "\$sql->set_types_manager(\$types);\n";
        print O "\n";
        print O "my \$ui = " . (($ui eq 'tk') ? "Arad::UI::Tk" : (($ui eq 'text') ? "Arad::UI::Text" : "")) . "->new();\n";
        print O "\n";
        print O "my \$spec = " . $spec_module . "::get_spec();\n";
        print O "\n";
        if ($db_type eq 'dbi')
        {
            print O "\$sql->connect_db(\n";
            print O "{\n";
            print O "    'dsn' => \"" . ${$optctl{'dsn'}} . "\",\n";
            print O "    'init' => \"" . ${$optctl{'dbi-init'}} . "\",\n";
            print O "});\n";
        }
        elsif ($db_type eq 'postgres')
        {
            print O "\$sql->connect_db(\n";
            print O "{\n";
            print O "    'database' => \"". ${$optctl{'database'}} . "\",\n";
            my $i;
            foreach $i ('host', 'port', 'username', 'password')
            {
                if (${$optctl{$i}})
                {
                    print O "    '".$i."' => \"" . ${$optctl{$i}} . "\",\n";
                }
            }
            print O "});\n";            
        }
        print O "\n";
        print O "my \$table = " . ($def_editor ? $default_editor_module : $module ) . "->new(\$types, \$sql, \$ui, \$spec);\n";
        print O "\n";
        print O "my \$options = '';";
        print O "\n";
        print O "\$table->create_dialog(\$options);\n";
        print O "\n";
        print O "\$sql->destroy_();\n";
        

        close (O);
    

        
    }
}

1;