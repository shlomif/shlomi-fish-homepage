0:

$type = 'int32';
$param = {};
$value1 = 5;
$value2 = 6;
$check = [
           '0',
           ''
         ];
$compare = -1;


1:

$type = 'int32';
$param = {};
$value1 = 'abc';
$value2 = 901;
$check = [
           1,
           '$F must be an integer.'
         ];
$compare = '0';


2:

$type = 'int32';
$param = {};
$value1 = '54857239857239487523984723948';
$value2 = 567;
$check = [
           1,
           '$F must be in the range -2147483648 - +2147483647.'
         ];
$compare = 1;


3:

$type = 'varchar';
$param = {
           'len' => 20
         };
$value1 = 'hello';
$value2 = 'your';
$check = [
           '0',
           ''
         ];
$compare = -1;


4:

$type = 'varchar';
$param = {
           'len' => 10
         };
$value1 = 'There\'s more than one way to do it.';
$value2 = 'Wonderful';
$check = [
           1,
           'The length of $F must be shorter than 10 bytes.'
         ];
$compare = -1;


5:

$type = 'double';
$param = {};
$value1 = '-5.6e8';
$value2 = '-9.1e10';
$check = [
           '0',
           ''
         ];
$compare = 1;


6:

$type = 'double';
$param = {};
$value1 = '5a89';
$value2 = '590.53';
$check = [
           1,
           '$F must be an floating point value.'
         ];
$compare = -1;


7:

$type = 'bounded_int';
$param = {
           'min' => 9,
           'max' => 500,
           'range_spec' => '[]'
         };
$value1 = 89;
$value2 = 300;
$check = [
           '0',
           ''
         ];
$compare = -1;


8:

$type = 'bounded_int';
$param = {
           'min' => 9,
           'max' => 500,
           'range_spec' => '[]'
         };
$value1 = 5;
$value2 = 300;
$check = [
           1,
           '$F is below 9'
         ];
$compare = -1;


9:

$type = 'bounded_int';
$param = {
           'min' => 9,
           'max' => 500,
           'range_spec' => '[]'
         };
$value1 = 1000;
$value2 = 300;
$check = [
           1,
           '$F is above 500'
         ];
$compare = 1;


10:

$type = 'bounded_int';
$param = {
           'min' => 9,
           'max' => 500,
           'range_spec' => '(]'
         };
$value1 = 9;
$value2 = 300;
$check = [
           1,
           '$F is not greater than 9'
         ];
$compare = -1;


