package Shlomif::R2L::Gui;

use strict;

use Gtk;
use Gtk::Atoms;

use Shlomif::R2L::Poller::File;

my $false = 0;
my $true = 1;


# The time in milliseconds to poll the hard-disk to see what is the 
# status of the file.
my $poll_time = 5000;

my $notify_on_change_outside_of_application_default = $true;

my $config_file_filename = $ENV{'HOME'} . "/.r2l-gui";

sub new
{
    my $class = shift;

    my $self = {};

    bless $self, $class;

    $self->initialize(@_);

    return $self;
}

sub get_main_menu
{
    my ( $window , $menu_items_ref) = @_;

    my $menubar;
    my $item_factory;
    my $accel_group;

    $accel_group = new Gtk::AccelGroup();

    # This function initializes the item factory.
    # Param 1: The type of menu - can be 'Gtk::MenuBar', 'Gtk::Menu',
    #          or 'Gtk::OptionMenu'.
    # Param 2: The path of the menu.
    # Param 3: The accelerator group.  The item factory sets up
    #          the accelerator table while generating menus.
    $item_factory = new Gtk::ItemFactory( 'Gtk::MenuBar',
                                          '<main>',
                                          $accel_group );

    # This function generates the menu items. Pass the item factory,
    # the number of items in the array, the array itself, and any
    # callback data for the the menu items.
    $item_factory->create_items( @{$menu_items_ref} );

    # Attach the new accelerator group to the window.
    $window->add_accel_group( $accel_group );

    # Finally, return the actual menu bar created by the item factory.
    #*menubar = gtk_item_factory_get_widget (item_factory, "&lt;main>");
    return ( $item_factory->get_widget( '<main>' ) );
}

# This function automates the creation of a button with an underline
# and an appropriate accelarator.
sub create_button
{
    my $window = shift; # The window on which this button will appear

    my $accel_group = shift;  # The Accelarator Group to which this button belongs

    my $title = shift; # The title of the button. Should contain one underscore

    my $class = shift || "button"; # Pass "button" to create a normal button.
                                   # Pass "checkbutton" to create a check button.                                   

    my $button;

    if ($class eq "button")
    {
         $button = Gtk::Button->new($title);
    }
    elsif ($class eq "checkbutton")
    {
        $button = Gtk::CheckButton->new($title);
    }
    else
    {
        die "Unknown Class passed to create_button!\n";
    }

    my $acc = $button->child->parse_uline($title);

    $button->add_accelerator(
        "clicked",
        $accel_group,
        $acc,
        'mod1_mask',
        [ "visible", "locked"]
        );

    return $button;
}

sub show_help_contents_dialog
{
    my $self = shift;

    if (! exists($self->{'help_contents_dialog'}))
    {
        my $help_contents_dialog = Gtk::Window->new('-toplevel');

        $self->{'help_contents_dialog'} = $help_contents_dialog;
        
        $help_contents_dialog->set_title("R2L Help");
        
        # This closure removes the Help contents dialog from any place
        # that refers to it.
        my $destroy_dialog = sub {
            delete($self->{'help_contents_dialog'});
            $help_contents_dialog = undef;
        };
        
        $help_contents_dialog->signal_connect("destroy", $destroy_dialog);
        $help_contents_dialog->signal_connect("delete_event", $destroy_dialog);
        
        
        my $about_vbox = Gtk::VBox->new($false, 1);
        
        $about_vbox->border_width(10);
        
        $help_contents_dialog->add($about_vbox);
        
        $about_vbox->show();
        
        my $about_text = Gtk::Text->new(undef, undef);
        
        $about_vbox->pack_start($about_text, $false, $true, 0);
        
        $about_text->set_editable($false);
        
        $about_text->insert(
            undef,
            $about_text->style->black,
            undef,
            (
                "R2L is a GUI front-end for switching the behaviour of biditext. " .
                "To do so, press the button.\n" .
                "\n" .
                "I am too lame to write more for now, but this is not the final " . 
                "dialog for the Help.\n"        
            )
        );
        
        $about_text->show();
        
        my $ok_button_box = Gtk::VBox->new(0, 10);
        
        $ok_button_box->border_width(10);
        
        my $ok_button = Gtk::Button->new("OK");
        
        $ok_button->signal_connect(
            "clicked" => sub { $help_contents_dialog->destroy(); }
            );
            
        $ok_button_box->pack_start($ok_button, $false, $true, 0);
        
        $ok_button->show();
        
        $ok_button_box->show();
        
        $about_vbox->pack_start($ok_button_box, $false, $true, 0);    
        
        $help_contents_dialog->show();
    }
    
    if (! $self->{'help_contents_dialog'}->visible)
    {
        $self->{'help_contents_dialog'}->show();
    }
}

sub get_notify_on_change
{
    my $self = shift;

    return $self->{'notify_on_change'};
}

sub show_preferences_dialog
{
    my $self = shift;

    my $preferences_dialog_box = Gtk::Window->new('-toplevel');
    
    $preferences_dialog_box->set_title("Haifux' R2L");
    
    my $accel_group = Gtk::AccelGroup->new();
    $accel_group->attach($preferences_dialog_box);
           
    my $main_vbox = Gtk::VBox->new($false, 1);
    
    $main_vbox->border_width(10);

    $preferences_dialog_box->add($main_vbox);
    
    my $notebook = Gtk::Notebook->new();
    
    $notebook->set_tab_pos('-top');
    
    $notebook->border_width(10);
    
    my $notebook_vbox = Gtk::VBox->new($false, 1);
    
    $notebook_vbox->border_width(10);
        
    #my $notify_check_button = Gtk::CheckButton->new("Notify on outside change of status");
    my $notify_check_button = create_button(
        $preferences_dialog_box,
        $accel_group,
        "_Notify on external change of status", 
        "checkbutton"
    );
    
    $notify_check_button->set_active(
        $self->get_notify_on_change()
        );
            
    my $h_label = Gtk::Label->new("General");
    
    my $v_label = Gtk::Label->new("General");
    
    $notebook_vbox->pack_start($notify_check_button, $false, $true, 0);    
    
    $notebook->append_page_menu($notebook_vbox, $h_label, $v_label);    
    
    $notify_check_button->show();
    $h_label->show();
    $v_label->show();
    
    $notebook_vbox->show();
    
    $main_vbox->pack_start($notebook, $false, $true, 0);
    
    $notebook->realize();
        
    $notebook->show();
    
    my $button_bar = Gtk::HButtonBox->new();
    
    $button_bar->set_layout('-spread');
    
    my $commit_changes = sub {
        $self->{'notify_on_change'} = $notify_check_button->get_active();
    
        open O, ">" . $config_file_filename;
        print O "[general]\n";
        print O "notify_on_outside_change=" . 
            ($self->get_notify_on_change() ? "1" : "0")
            . "\n";
        close(O);    
    };
    
    my $ok_button = create_button(
        $preferences_dialog_box,
        $accel_group,
        "_OK");
    
    $ok_button->signal_connect(
        "clicked" => 
            sub { 
                $commit_changes->();
                $preferences_dialog_box->destroy();
            }
    );    
        
    $button_bar->add($ok_button);
    $ok_button->show();
    
    my $apply_button = 
        create_button(
            $preferences_dialog_box, 
            $accel_group, 
            "_Apply"
            );
    
    $apply_button->signal_connect(
        "clicked" =>
            sub {
                $commit_changes->();
            }
    );
    
    $button_bar->add($apply_button);
    $apply_button->show();
    
    my $cancel_button = 
        create_button(
            $preferences_dialog_box,
            $accel_group,
            "_Cancel"
            );
    
    $cancel_button->signal_connect(
        "clicked" =>
            sub {
                $preferences_dialog_box->destroy();
            }
        );
    
    $button_bar->add($cancel_button);
    
    $cancel_button->show();
    
    $main_vbox->pack_start($button_bar, $false, $true, 0);
    
    $button_bar->show();
    
    $main_vbox->show();
        
    $preferences_dialog_box->set_modal($true);
    $preferences_dialog_box->show();
}

sub show_about_dialog
{
    my $about_dialog_box = Gtk::Window->new('-toplevel');
    
    $about_dialog_box->set_title("About Haifux' R2L");
    
    my $about_vbox = Gtk::VBox->new($false, 1);
    
    $about_vbox->border_width(10);
    
    $about_dialog_box->add($about_vbox);
    
    $about_vbox->show();
    
    my $about_text = Gtk::Text->new(undef, undef);
    
    $about_vbox->pack_start($about_text, $false, $true, 0);
    
    $about_text->set_editable($false);
    
    $about_text->insert(
        undef,
        $about_text->style->black,
        undef,
            (
                "Haifux' R2L - a program to control biditext's behaviour.\n" .
                "\n" .
                "Written by Shlomi Fish <shlomif\@vipe.technion.ac.il>\n" .
                "\n" .
                "This program is a project of the Haifa Linux Club.\n" .
                "\n" .
                "Visit the club's web-site: http://linuxclub.il.eu.org/"
            )
        );
    
    $about_text->show();
    
    my $ok_button_box = Gtk::VBox->new(0, 10);
    
    $ok_button_box->border_width(10);
    
    my $ok_button = Gtk::Button->new("OK");
    
    $ok_button->signal_connect(
        "clicked" => sub { $about_dialog_box->destroy() }
        );
        
    $ok_button_box->pack_start($ok_button, $false, $true, 0);
    
    $ok_button->show();
    
    $ok_button_box->show();
    
    $about_vbox->pack_start($ok_button_box, $false, $true, 0);    
    
    # Make it a modal dialog box
    $about_dialog_box->set_modal($true);
    
    $about_dialog_box->show();
}

sub get_button_label_for_state
{
    my $self = shift;

    my $state = shift;

    return ($state ? "_Turn Off" : "_Turn On");
}

sub show_status_has_changed_message_box
{
    my $dialog = Gtk::Window->new('-toplevel');
    
    my $main_vbox = Gtk::VBox->new($false, 1);
    
    $main_vbox->border_width(10);
    
    $dialog->add($main_vbox);
    
    my $label = Gtk::Label->new(
        "The R2L status has changed outside " . 
        "this application.\n\n" .
        "The display will be updated accordingly."
    );
    
    $label->set_justify("-left");
    
    $main_vbox->pack_start($label, $false, $true, 0);
    
    $label->show();
    
    my $ok_button = Gtk::Button->new("OK");
    
    $ok_button->border_width(10);
    
    $ok_button->signal_connect(
        "clicked" =>
            sub { $dialog->destroy(); }
    );
    
    $main_vbox->pack_start($ok_button, $false, $true, 0);
        
    $ok_button->show();
    
    $main_vbox->show();
    
    $dialog->show();
}

sub get_status_label_for_state
{
    my $self = shift;
    
    my $state = shift;

    return "Status: " . ($state ? "R2L" : "Disabled");
}

sub update_labels_according_to_status
{
    my $self = shift;

    # Make some member variables readily accesible
    my $r2l_logic = $self->{'r2l_logic'};
    my $status_label = $self->{'status_label'};

    my $turn_onoff_button_label = 
        $self->get_button_label_for_state(
            $r2l_logic->get_status()
        );

    my $turn_onoff_button = $self->{'turn_onoff_button'};
    
    $turn_onoff_button->child->parse_uline($turn_onoff_button_label);

    my $status_label_text = 
        $self->get_status_label_for_state(
            $r2l_logic->get_status()
        );

    $status_label->set_text($status_label_text);        
}

sub destroy_windows
{
    my $self = shift;

    Gtk->timeout_remove($self->{'timer_function_id'});
    $self->{'main_window'}->destroy();

    delete($self->{'main_window'});

    # Make sure the help contents dialog terminates too in case it is visible.
    if (exists($self->{'help_contents_dialog'}))
    {
        $self->{'help_contents_dialog'}->destroy();

        delete($self->{'help_contents_dialog'});
    }

    $self->{'exit_notifier'}->();
}

sub create_main_dialog
{
    my $self = shift;

    my ($window, $main_vbox, $menubar, $accel_group);

    my $r2l_logic = $self->{'r2l_logic'};

    $window = Gtk::Window->new('toplevel');
    $window->set_name("Haifux\' R2L");

    $self->{'main_window'} = $window;

    # Instruct the window to close Gtk+ if it is connected.
    $window->signal_connect("destroy" => sub { $self->destroy_windows(); });
    # This one was ripped from the Perl/Gtk widget demonstration.
    # I have no idea what it does. :-)
    $window->signal_connect("delete_event" => \&Gtk::false);

    $main_vbox = Gtk::VBox->new($false, 1);

    $window->add($main_vbox);
    $main_vbox->show();

    my @menu_items = 
    ( 
        { 
            'path' => '/_File',
            'type' => '<Branch>',
        },
        {
            'path' => '/File/E_xit',
            'callback' => sub { $window->destroy(); }
        },
        {
            'path' => '/_Settings',
            'type' => '<Branch>',
        },
        {
            'path' => '/Settings/_Preferences...',
            'callback' => sub { $self->show_preferences_dialog(); }
        },
        {
            'path' => '/_Help',
            'type' => '<Branch>',
        },
        {
            'path' => '/Help/_Contents',
            'callback' => sub { $self->show_help_contents_dialog(); },
        },
        {  
            'path' => '/Help/sep1',
            'type' => '<Separator>',
        },
        {
            'path' => '/Help/_About...',
            'callback' => sub { &show_about_dialog(); },
        },
    );
    
    $menubar = get_main_menu($window, \@menu_items);

    $main_vbox->pack_start($menubar, $false, $true, 0);

    $menubar->show();

    my $status_label_text = 
        $self->get_status_label_for_state(
            $r2l_logic->get_status()
        );
        
    my $status_label = Gtk::Label->new(
        $status_label_text
        );

    $main_vbox->pack_start(
        $status_label, 
        $false, $true, 0
        );
    
    $status_label->show();

    $self->{'status_label'} = $status_label;

    my $turn_onoff_button_table = Gtk::Table->new(3, 3, 0);

    my $turn_onoff_button_table_top_padding = Gtk::Label->new("");

    $turn_onoff_button_table_top_padding->set_usize(0, 30);

    $turn_onoff_button_table->attach(
        $turn_onoff_button_table_top_padding, 
        1, 2, 0, 1,
        [ "fill" ],
        [ ],
        0 , 0
        );

    $turn_onoff_button_table_top_padding->show();

    my $turn_onoff_button_table_bottom_padding = Gtk::Label->new("");

    $turn_onoff_button_table_bottom_padding->set_usize(0, 30);

    $turn_onoff_button_table->attach(
        $turn_onoff_button_table_bottom_padding, 
        1, 2, 2, 3,
        [ "fill" ],
        [ ],
        0 , 0
        );

    $turn_onoff_button_table_bottom_padding->show();

    $accel_group = Gtk::AccelGroup->new();
    $accel_group->attach($window);
            
    my $turn_onoff_button_label = 
        $self->get_button_label_for_state(
            $r2l_logic->get_status()
        );

    my $turn_onoff_button = 
        &create_button(
            $window,
            $accel_group,
            $turn_onoff_button_label
        );

    $turn_onoff_button->signal_connect(
        "clicked" => sub {
            $r2l_logic->switch();

            $self->update_labels_according_to_status();
         }
    );

    $turn_onoff_button_table->attach(
        $turn_onoff_button,
        1, 2, 1, 2, 
        [ "expand", "fill" ],
        [ ],
        0, 0
        );
    
    $turn_onoff_button->set_border_width(7);

    $turn_onoff_button->show();

    $self->{'turn_onoff_button'} = $turn_onoff_button;

    $main_vbox->pack_start(
        $turn_onoff_button_table, 
        $false, $true, 0
        );

    $turn_onoff_button_table->show();

    my $timeout_id = Gtk->timeout_add($poll_time, sub { $self->timer_function(); });

    $self->{'timer_function_id'} = $timeout_id;
  
    $window->show();
}

sub timer_function
{
    my $self = shift;

    my $r2l_logic = $self->{'r2l_logic'};

    my $status_has_changed = $r2l_logic->poll();

    $self->update_labels_according_to_status();
    
    if ($status_has_changed && $self->get_notify_on_change())
    {
        &show_status_has_changed_message_box();
    }

    # A timeout function should return TRUE to continue being processed.
    return $true;
}


# This function reads the configuration from the file $HOME/.r2l-gui
# At the moment it only reads one thing - 
#     notify_on_change
sub read_config
{
    my $self = shift;
    
    my $filename = $config_file_filename;
    my $line;
    # Check if the file exists at all (if it does not - default to the 
    # hard-coded default.
    if ((-r $filename) && (-f $filename))
    {
        open I, "<$filename";
        while ($line = <I>)
        {
            chomp($line);
            if ($line =~ /^\s*notify_on_outside_change\s*=/)
            {
                # Remove everything up to and including the equal sign
                $line =~ s/^.*?=\s*//;
                # Remove any trailing whitespace at the end.
                $line =~ s/\s+.*$//;
                # If the line is "yes", "1" or "true" set $notify to TRUE,
                # and set it to FALSE otherwise        
                $self->{'notify_on_change'} = 
                    ($line =~ /^(yes|1|true)$/i) ? $true : $false;
                last;            
            }
        }
        close(I);
    }
}

# Internal Function
sub initialize
{
    my $self = shift;

    my $filename = shift || ($ENV{'HOME'}."/.r2l");

    # Initialize a new object to handle the logic of enabling, disabling
    # and polling the file.
    $self->{'r2l_logic'} = Shlomif::R2L::Poller::File->new($filename);
    
    # Assign a default value to notify on change
    $self->{'notify_on_change'} = $notify_on_change_outside_of_application_default;

    $self->read_config();

    return $self;
}

#
# API Function:
# 
# $self->run(\&exit_notifier)
#
# Creates and shows the dialog box.
#
# &exit_notifier() will be called once the user terminates it.
# It defaults to Gtk->exit()
#
sub run
{
    my $self = shift;

    my $exit_notifier = shift || (sub { Gtk->exit(0); });

    $self->create_main_dialog();

    $self->{'exit_notifier'} = $exit_notifier;
}

1;
