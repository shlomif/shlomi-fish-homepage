# Arad::Types::Int64 - a 64-bit signed integer SQL data type.
#
# This module uses Math::BigInt to compare integers to their 64-bit limit.
# I do it because on many systems comparing numbers with many digits will get
# out of scope, and not necessarily return the right result.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)


package Arad::Types::Int64;

use Math::BigInt;

use Arad::Types::Base;

@ISA = qw(Arad::Types::Base);

use strict;

my $min_value = "-9223372036854775808";
my $max_value = "9223372036854775807";

sub initialize
{
    my $self = shift;

    $self->{'type'} = 'int64';
}

sub check_value
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;
  
    if (($value eq undef) || ($value eq ''))
    {
        return (0, "")
    }
    elsif ($value !~ /^[-+]?\d+$/)
    {
        return (1, "\$F must be an integer.");
    }    
    elsif (($self->compare($type_params, $value, $max_value) > 0) ||
           ($self->compare($type_params, $value, $min_value) < 0))
    {
        return (1, ("\$F must be in the range " . $min_value . " - " . $max_value . "."));
    }
    else
    {
        return (0, "");
    }
}

sub to_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if (($value eq undef) || ($value eq ''))
    {
        return (0, "null");
    }
    
    return (0, $value);
}

sub from_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value eq undef)
    {
        return '';
    }
    
    return $value;
}

sub compare
{
    my $self = shift;

    my $type_params = shift;

    my $value1 = shift;
    my $value2 = shift;

    my $ret = ((Math::BigInt->new($value1)) <=> (Math::BigInt->new($value2)));
    $ret =~ s!^\+!!;
    return $ret;
}

