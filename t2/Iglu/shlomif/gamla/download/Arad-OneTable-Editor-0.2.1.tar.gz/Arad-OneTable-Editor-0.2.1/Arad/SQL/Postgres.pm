# Arad::SQL::Postgres - The SQL driver that uses the Pg module to connect
# to the PostgreSQL database server.
#
# I wrote this code before I installed Perl/DBI and wrote Arad::SQL::DBI,
# so I'm keeping it here. You will probably prefer to use Arad::SQL::DBI to
# connect to PostgreSQL too.
#
# See the Arad::SQL::DBI module for descriptions of this module's methods.
# 
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)

package Arad::SQL::Postgres;

use Arad::SQL::Base;

@ISA=qw(Arad::SQL::Base);

use strict;

use Pg;


{
    my @options = (
                   ['host', 'host'],
                   ['port', 'port'],
                   ['postgresql_options', 'options'],
                   ['postgresql_tty', 'tty'],
                   ['database', 'dbname'],
                   ['username', 'user'],
                   ['password', 'password'],
                   );
        
sub connect_db
{
    my $self = shift;
    my $params = shift;

    my $conn_string = "";
    my $a;

    foreach $a (@options)
    {
        if (exists($params->{$a->[0]}))
        {
            if ($conn_string ne "")
            {
                $conn_string .= ' ';
            }
            $conn_string .= $a->[1] . "=" . $params->{$a->[0]};
        }
    }

    $self->{'conn'} = Pg::connectdb($conn_string);

    if ($self->{'conn'})
    {
        my $conn = $self->{'conn'};

        $conn->exec("SET DateStyle = 'ISO'");

        return 0;
    }
    else
    {
        return 1;
    }
}

}

sub disconnect_db
{
    my $self = shift;

    $self->{'conn'} = undef;
}

sub can_convert_from
{
    my $self = shift;

    my $type = shift;

    return 0;    
}

sub can_convert_to
{
    my $self = shift;

    my $type = shift;

    return 0;
}

# Note: For compatibility with MySQL, I suggest this function will not be used
# with sub-queries and the such.
sub perform_select_query
{
    my $self = shift;

    my $query_str = shift;

    my $conn = $self->{'conn'};

    my $handle = $conn->exec($query_str);

    return {'type' => 'select', 'handle' => $handle};
}

sub get_query_row
{
    my $self = shift;

    my $query = shift;

    return ($query->{'handle'}->fetchrow());
}

sub end_query
{
    my $self = shift;

    my $query = shift;

    %{$query} = ();
}

sub perform_update_transaction
{
    my $self = shift;

    my $table_name = shift;

    my $update_values = shift;

    my $where_clause = shift;


    my $types = $self->{'types'};

    my $conn = $self->{'conn'};

    my ($set_clause, $field, $value);

    # For the time being, put everything in one big UPDATE query.
    # Does PostgreSQL has a limit on the length of its queries?
    while (($field, $value) = each(%{$update_values}))
    {
        if (length($set_clause) > 0)
        {
            $set_clause .= ",";
        }
        $set_clause .= ($field . "=" .
                             ( ($value->[0] & 0x1) ?
                               $types->quote_sql_value($value->[1]) :
                               $value->[1]
                             )
                       );        
    }

    my $result = $conn->exec("UPDATE " . $table_name . " SET " . $set_clause . " WHERE " . $where_clause);

    if ($result->resultStatus() != PGRES_COMMAND_OK)
    {
        return (1, "Error in input. Database returned: " . $conn->errorMessage());
    }

    return (0, "");
}

sub perform_insert_transaction
{
    my $self = shift;
    my $table_name = shift;
    my $insert_values = shift;

    my $types = $self->{'types'};
    my $conn = $self->{'conn'};

    my ($field, $value, $fields_clause, $values_clause);

    while (($field, $value) = each(%{$insert_values}))
    {
        if (length($fields_clause)>0)
        {
            $fields_clause .= ',';
        }
        if (length($values_clause)>0)
        {
            $values_clause .= ',';
        }
        $fields_clause .= $field;
        $values_clause .=  ( ($value->[0] & 0x1) ?                             
                             $types->quote_sql_value($value->[1]) :
                             $value->[1]
                           );
    }

    my $result = $conn->exec("INSERT INTO " . $table_name .
                             " (" . $fields_clause . ") " .
                             "VALUES (" . $values_clause . ")");
    
    if ($result->resultStatus() != PGRES_COMMAND_OK)
    {
        return (1, "Error in input. Database returned: " . $conn->errorMessage());
    }

    return (0, "");        
}

sub perform_delete_transaction
{
    my $self = shift;
    my $table_name = shift;
    my $where_clause = shift;

    my $conn = $self->{'conn'};

    my $result = $conn->exec("DELETE FROM " . $table_name .
                             " WHERE " . $where_clause);

    if ($result->resultStatus() != PGRES_COMMAND_OK)
    {
        return (1, "Error in input. Database returned: " . $conn->errorMessage());
    }

    return (0, "");    
}

1;
