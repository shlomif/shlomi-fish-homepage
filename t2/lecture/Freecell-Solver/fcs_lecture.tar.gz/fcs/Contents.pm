package Contents;

use strict;

my $contents =
{
    'title' => "Contents",
    'subs' =>
    [
        {
            'url' => "intro.html",
            'title' => "Introduction",
        },
        {
            'url' => "rules.html",
            'title' => "Rules of Freecell",
        },
        {
            'url' => "0.0-0.2",
            'title' => "From version 0.0 to version 0.2",
            'subs' =>
            [
                {
                    'url' => "algorithm.html",
                    'title' => "Algorithm",
                },
                
            ],
        },        
    ],
};

sub get_contents
{
    return $contents;
}
