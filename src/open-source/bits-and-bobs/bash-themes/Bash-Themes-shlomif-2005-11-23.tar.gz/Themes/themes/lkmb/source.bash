load_common mymake

this="$HOME/Svn/progs/CLAN/trunk/module-compiler"

cd $this

. tests/convenience.sh

