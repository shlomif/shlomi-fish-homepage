#!/bin/bash

RSYNC="rsync --progress --verbose --rsh=ssh"

cd /var/www/html/shlomi/perl-mongers/lecture/Quad-Pres
$RSYNC -r slides/ shlomif@vipe:public_html/lecture/Quad-Pres/slides

