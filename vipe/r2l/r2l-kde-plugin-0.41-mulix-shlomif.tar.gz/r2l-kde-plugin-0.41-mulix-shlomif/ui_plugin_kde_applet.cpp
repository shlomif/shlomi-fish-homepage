#include <stdlib.h>
#include <stdio.h>

#include <qpushbutton.h>

#include <klocale.h>
#include <kcmdlineargs.h>
#include <kwin.h>
#include <kaboutdata.h>
#include <kuniqueapp.h>

#include "ui_plugin.h"
#include "toplevel.h"

static const char *description =
       I18N_NOOP("Haifux' R2L KDE Applet");

static const char *version = "v0.41-mulix";

struct ui_plugin_data
{
    KAboutData * aboutData;
    KUniqueApplication * app;
    TopLevel * toplevel;
    QTimer * timer;
    r2llib_t r2l_ctrl;
};

ui_plugin_t
ui_init(int argc, char * argv[], r2llib_t r2l_ctrl)
{
    ui_plugin_t ui = (ui_plugin_t)malloc(sizeof(struct ui_plugin_data));

    KAboutData * aboutData = new KAboutData("haifux_r2l", I18N_NOOP("Haifux' R2L"),
        version, description, KAboutData::License_Artistic,
        "(c) 1998-2000, Andrew Stanley-Jones");
    aboutData->addAuthor("Andrew Stanley-Jones", 0, "asj@cban.com");
    aboutData->addAuthor("Carsten Pfeiffer", 0, "pfeiffer@kde.org");

    ui->aboutData = aboutData;

    KCmdLineArgs::init( argc, argv, aboutData );
    KUniqueApplication::addCmdLineOptions();

    if (!KUniqueApplication::start()) {
       fprintf(stderr, "%s is already running!\n", aboutData->appName());
       exit(0);
    }
    KUniqueApplication * app = new KUniqueApplication();
    app->disableSessionManagement();

    ui->app = app;

    TopLevel *toplevel = new TopLevel();

    ui->toplevel = toplevel;
    toplevel->ui_ = ui;

    KWin::setSystemTrayWindowFor( toplevel->winId(), 0 );
    toplevel->setGeometry(-100, -100, 42, 42 );
    toplevel->show();

    ui->r2l_ctrl = r2l_ctrl;

    return ui;
}

int ui_provides_main_loop(ui_plugin_t ui)
{
    return 1;
}

void ui_main_loop(ui_plugin_t ui)
{
    ui->app->exec();
}

int
ui_register_timer_callback(ui_plugin_t ui,
                        int ms,
                        int (*cb)(void*),
                        void* data)
{
#if 0
    ui->timer = gtk_timeout_add(ms, cb, data);
#endif
    /*
     * TODO TODO TODO :: Fill In
     *
     *
     * */

    ui->toplevel->r2lSetTimer(ms, cb, data);

    return 1;
}

void
ui_notify_of_r2l_mode(ui_plugin_t ui, R2L_STATE md, BIDITEXT_BASE_STATE bs)
{
    ui->toplevel->on_off_state = md;
    ui->toplevel->rtl_state = bs;
    ui->toplevel->on_off_button->setText((md == R2L_ENABLED) ? "1" : "0");
    ui->toplevel->r2l_button->setText((bs == BT_BASE_NEUTRAL) ? "-" : ((bs == BT_BASE_LTR) ? ">" : "<"));
    ui->toplevel->r2l_button->setEnabled(md == R2L_ENABLED);
}

void TopLevel::r2lOnOffButtonPressed()
{
    int should_refresh = 0;
    int rc;

    ui_plugin_t ui = (ui_plugin_t)ui_;
    
    if (on_off_state == R2L_ENABLED)
    {
        rc = r2l_disable(ui->r2l_ctrl);
        if (rc == 1)
        {
                on_off_state = R2L_DISABLED;
                should_refresh = 1;              
        }        
    }
    else if (on_off_state == R2L_DISABLED)
    {
        rc = r2l_enable(ui->r2l_ctrl);
        if (rc == 1)
        {
                on_off_state = R2L_ENABLED;
                should_refresh = 1;
        }
    }
    if (should_refresh)
    {
        on_off_button->setText((on_off_state == R2L_ENABLED) ? "1" : "0");
        r2l_button->setEnabled(on_off_state == R2L_ENABLED);
        repaint();
    }
}

void TopLevel::r2lRtlButtonPressed()
{
    ui_plugin_t ui = (ui_plugin_t)ui_;
    int rc;
    int should_refresh = 0;
    static int num_times = 0;
    
    if (rtl_state == BT_BASE_LTR) {
       rc = r2l_set_biditext_base_state_neutral(ui->r2l_ctrl);
       if (rc == 1) {
           rtl_state = BT_BASE_NEUTRAL;
           should_refresh = 1;
       }
    }
    else if (rtl_state == BT_BASE_NEUTRAL) {
       rc = r2l_set_biditext_base_state_rtl(ui->r2l_ctrl);
       if (rc == 1) {
           rtl_state = BT_BASE_RTL;
           should_refresh = 1;
       }
    }
    else if (rtl_state == BT_BASE_RTL) {
       rc = r2l_set_biditext_base_state_ltr(ui->r2l_ctrl);
       if (rc == 1) {
           rtl_state = BT_BASE_LTR;
           should_refresh = 1;
       }
    }
    
    if (should_refresh)
    {
        r2l_button->setText((BT_BASE_NEUTRAL == rtl_state) ? "-" : ((rtl_state == BT_BASE_LTR) ? ">" : "<"));
        repaint();
    }    
}
/* returns a file descriptor that the UI would like r2l to listen on. */
/* for the command-line plugin - this is stdin.                           */
int
ui_get_listening_fd(ui_plugin_t ui)
{
    return -1;
}


/* callback invoked when r2l discovers the file descriptor of the UI */
/* is active. NOT USED in this plugin!                               */
void
ui_perform_callback(ui_plugin_t ui, r2llib_t r2l_ctrl)
{
    /* do nothing. */
}


/* cleanup the ui plugin. after this call, 'ui' may no longer be used. */
void
ui_cleanup(ui_plugin_t ui)
{
    delete ui->toplevel;
    delete ui->app;
    delete ui->aboutData;
    free(ui);
}
