load_common mymake

this="$HOME/Docs/homepage/homepage/trunk"

cd $this

