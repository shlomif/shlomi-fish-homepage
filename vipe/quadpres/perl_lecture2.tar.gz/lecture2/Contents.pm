package Contents;

use strict;

my $contents =
{
    'title' => "Contents",
    'subs' =>
    [
        {
            'url' => "for",
            'title' => "The for loop",
            'subs' =>
            [
                {
                    'url' => "next.html",
                    'title' => "Behaviour of next in the for loop",
                },
                {
                    'url' => "whence_for.html",
                    'title' => "Whence for?",
                },
            ],
        },
        {
            'url' => "hashes",
            'title' => "Hashes",
            'subs' =>
            [
                {
                    'url' => "functions.html",
                    'title' => "Hash Functions",
                },
            ],
        },
        {
            'url' => "my",
            'title' => "Declaring Local Variables with \"my\"",
            'subs' =>
            [
                {
                    'url' => "use_strict.html",
                    'title' => "\"use strict\", Luke!",
                },
            ],
        },
        {
            'url' => "functions",
            'title' => "Functions",
            'subs' =>
            [
                {
                    'url' => "recursion.html",
                    'title' => "Function Recursion",
                },
                {
                    'url' => "shift.html",
                    'title' => "Use of \"shift\" in functions",
                },
            ],
        },
        {
            'url' => "files",
            'title' => "File Input/Output",
            'subs' =>
            [
                {
                    'url' => "print.html",
                    'title' => "Using print with files",
                },
                {
                    'url' => "readline.html",
                    'title' => "The <FILEHANDLE> operator",
                }
            ],
        },
    ],
    'images' => 
    [ 
        'style.css',
    ],
};

sub get_contents
{
    return $contents;
}
