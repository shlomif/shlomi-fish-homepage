load_common mymake
load_common completion

fcs="/home/shlomi/progs/freecell/"
trunk="$fcs/trunk"
c_src="$trunk/fc-solve/source"
site="$trunk/fc-solve/site/wml"
presets="$fcs/Presets/auto-gen-trunk"

this="$c_src"

cd $this

