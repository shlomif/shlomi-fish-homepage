package My::Types::BoundedInt;

sub get_type_params
{
    return ("bounded_int",
        {
            'inherits' => ["int32", "bounded"],
        });
}

1;
