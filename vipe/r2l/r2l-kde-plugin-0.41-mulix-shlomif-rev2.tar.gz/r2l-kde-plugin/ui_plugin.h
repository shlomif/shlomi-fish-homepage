#ifndef _ui_plugin_h_
# define _ui_plugin_h_

/* ui_plugin.h - interface for the user-interface part of the r2l program. */

#include "r2llib.h"

#ifdef __cplusplus
extern "C" {
#endif

/* opaque pointer to a ui plugin's data. */
typedef struct ui_plugin_data* ui_plugin_t;

/* initialize a given ui. returns a ui_plugin_t opaque pointer. */
ui_plugin_t ui_init(int argc, char* argv[], r2llib_t r2l_ctrl);

/* define whether the ui plugin runs its own main loop. */
/* returns '1' for true, '0' for false.                 */
/* note that if it does, it must also support the timer */
/* registration interface.                              */
int ui_provides_main_loop(ui_plugin_t ui);

/* execute the ui plugin's main loop - invoked only if */
/* 'ui_provides_main_loop' returned '1' previously.    */
void ui_main_loop(ui_plugin_t ui);

/* register a callback with the ui plugin to be invoked */
/* every 'ms' milliseconds.                             */
/* invoked only if 'ui_provides_main_loop' returned '1' */
/* previously.                                          */
int ui_register_timer_callback(ui_plugin_t ui,
			       int ms,
			       int (*cb)(void*),
			       void* data);

/* notify the ui plugin about a mode change. */
void ui_notify_of_r2l_mode(ui_plugin_t ui, R2L_STATE md, BIDITEXT_BASE_STATE bs);

/* returns a file descriptor that the UI would like r2l to listen on. */
/* for the command-line plugin - this is stdin.			      */
int ui_get_listening_fd(ui_plugin_t ui);

/* callback invoked when r2l discovers the file descriptor of the UI is active. */
void ui_perform_callback(ui_plugin_t ui, r2llib_t r2l_ctrl);

/* cleanup the ui plugin. after this call, 'ui' may no longer be used. */
void ui_cleanup(ui_plugin_t ui);

#ifdef __cplusplus
}
#endif

#endif /* _ui_plugin_h_ */
