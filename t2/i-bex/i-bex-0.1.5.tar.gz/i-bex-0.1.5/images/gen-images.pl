#!/usr/bin/perl -w

use strict;

use Gimp ":auto";

use Cwd;

Gimp::init();

if (! -d "gen")
{
    mkdir("gen", 0777);
}

system("rm -f gen/*.png");

my $filename = getcwd() . "/tile_u.xcf";

my @dirs = qw(u r d l);

for(my $bit_mask = 1 ; $bit_mask < (1<<4) ; $bit_mask++)
{
    my $new_filename = getcwd() . "/gen/moving-block-" . join("", (map { ($bit_mask & (1 << $_)) ? $dirs[$_] : "-" } (0 .. 3))) . ".png";

    my @dirs_in_image = (grep { $bit_mask & (1 << $_) } (0 .. 3));
    
    my $arrow_img = gimp_file_load($filename, $filename);

    my @layers = $arrow_img->get_layers();

    foreach my $d (@dirs_in_image[1 .. $#dirs_in_image])
    {
        my $new_layer = $layers[0]->copy(0);
        $arrow_img->add_layer($new_layer,0);
        push @layers, $new_layer;
        $new_layer->set_mode(MULTIPLY_MODE);
        if ($d > 0)
        {
            $arrow_img->plug_in_rotate($new_layer, $d, 0);
        }
    }
    my $d = $dirs_in_image[0];
    if ($d > 0)
    {
        $arrow_img->plug_in_rotate($layers[0], $d, 0);
    }

    if (0)
    {
        if ($d > 0)
        {
            $arrow_img->plug_in_rotate($arrow_img->active_drawable(), $d, 1)
        }   
    }

    $arrow_img->flatten();

    print "$new_filename\n";

    $arrow_img->gimp_file_save(
        $arrow_img->active_drawable(), 
        $new_filename, 
        $new_filename
        );

    $arrow_img->delete();
}

foreach my $fn (qw(chasm platform wall actor you_win exit))
{
    $filename = getcwd() . "/$fn.xcf";
    my $img = gimp_file_load($filename, $filename);
    $img->flatten();
    my $new_filename = getcwd() . "/gen/$fn.png";
    print $new_filename, "\n";
    $img->gimp_file_save(
        $img->active_drawable(),
        $new_filename,
        $new_filename
        );
}

