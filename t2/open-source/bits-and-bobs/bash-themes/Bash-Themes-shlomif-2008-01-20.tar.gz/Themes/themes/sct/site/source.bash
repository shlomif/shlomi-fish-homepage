load_common mymake

this="$HOME/Download/unpack/kernel/Sys-Call-Track/wwwdocs"

export CVS_RSH=ssh
export CVSROOT=":ext:shlomif@cvs.syscalltrack.sourceforge.net:/cvsroot/syscalltrack"

cd $this

