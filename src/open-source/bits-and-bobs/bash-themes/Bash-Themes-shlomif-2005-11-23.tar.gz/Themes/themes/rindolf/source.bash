load_common mymake

this="$HOME/Svn/Docs/Rindolf/Spec"

cd $this

