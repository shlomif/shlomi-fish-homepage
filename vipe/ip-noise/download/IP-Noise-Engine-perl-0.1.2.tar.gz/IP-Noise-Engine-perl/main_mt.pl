#!/usr/bin/perl
use strict;

use Thread;
use IPTables::IPv4::IPQueue qw(:constants);
use Time::HiRes qw(usleep);

use Packet::Logic;
use Delayer;


my $packet_logic = Packet::Logic->new();

my $queue = IPTables::IPv4::IPQueue->new(
    'copy_mode' => IPQ_COPY_PACKET,
    'copy_range' => 2048
    );

if (!$queue) 
{
    die IPTables::IPv4::IPQueue->errstr();
}


my $release_callback = 
    sub {
        my $msg = shift;

        $queue->set_verdict($msg->packet_id, NF_ACCEPT);
    };

my $delayer = Delayer->new($release_callback);    

my $terminate = 0;

sub release_packets_thread_func
{
    while (! $terminate)
    {
        {
            lock($delayer);
            $delayer->release_packets_poll_function();
        }
        usleep(500);
    }
}

while (1)
{
    my $msg = $queue->get_message();

    if (! $msg)
    {
        die IPTables::IPv4::IPQueue->errstr();
    }
    
    my $verdict = $packet_logic->decide_what_to_do_with_packet($msg);

    if ($verdict->{'action'} eq "accept")
    {
        # Accept immidiately
        $release_callback->($msg);
    }
    elsif ($verdict->{'action'} eq "drop")
    {
        # Drop the packet
        $queue->set_verdict($msg->packet_id, NF_DROP);
    }
    elsif ($verdict->{'action'} eq "delay")
    {
        # Delay the packet for $verdict quanta
        lock($delayer);
        $delayer->delay_packet(
            $msg,
            $verdict->{'delay_len'},
            );
    }
    else
    {
        $terminate = 1;
        die "Unknown Action!\n";
    }    
}


