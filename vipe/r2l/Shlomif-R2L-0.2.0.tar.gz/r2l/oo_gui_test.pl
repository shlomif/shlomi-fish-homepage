#!/usr/bin/perl

use Gtk;

use Shlomif::R2L::Gui;

my $gui = Shlomif::R2L::Gui->new();
my $gui2 = Shlomif::R2L::Gui->new();

Gtk->init();

my $num_windows = 2;

sub my_on_exit
{
    $num_windows--;
    if ($num_windows == 0)
    {
        Gtk->exit(0);
    }
}

$gui->run(\&my_on_exit);
$gui2->run(\&my_on_exit);

Gtk->main();


