function switch_to_new_automake
{
    PATH="$HOME/apps/prog/automake-1.6/bin:$PATH"
}

