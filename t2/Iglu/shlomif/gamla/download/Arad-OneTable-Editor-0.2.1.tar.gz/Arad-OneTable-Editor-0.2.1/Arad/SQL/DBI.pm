# Arad::SQL::DBI - The SQL driver that uses the DBI interface
#
# Right now only database that support the LIMIT clause are supported for
# sequence handling. 
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)

package Arad::SQL::DBI;

use Arad::SQL::Base;

@ISA=qw(Arad::SQL::Base);

use strict;

use DBI;

# $sql_driver->connect_db(\%params)
# Connects to the database driver. Accepted paramaters in the %params hash:
# 'dsn' => contains the DBI dsn to connect to the datbase
# 'init' => Initialization statements. Mainly to tell the database to use
#           ISO-style dates (YYYY-MM-DD)
# 'no-limit-clause' => If this key exists than the database does not support
#                      the limit clause.
sub connect_db
{
    my $self = shift;
    my $params = shift;

    my $conn_string = "";
    my $a;
    my ($dsn, $init, $no_limit);

    $no_limit = 0;

    foreach $a (keys(%{$params}))
    {
        if ($a eq 'dsn')
        {
            $dsn = $params->{$a};
        }
        elsif ($a eq 'init')
        {
            $init = $params->{$a};
        }
        elsif ($a eq 'no-limit-clause')
        {
            $no_limit = 1;
        }
    }

    $self->{'conn'} = DBI->connect($dsn);

    if ($self->{'conn'})
    {
        my $conn = $self->{'conn'};

        if ($init)
        {
            my @init_statements = split(/\n/, $init);

            for($a=0;$a<scalar(@init_statements);$a++)
            {
                $conn->do($init_statements[$a]);
            }
        }

        $self->{'no_limit'} = $no_limit;

        return 0;
    }
    else
    {
        return 1;
    }
}

sub disconnect_db
{
    my $self = shift;

    $self->{'conn'} = undef;
}

# This driver can't convert SQL values at all.
sub can_convert_from
{
    my $self = shift;

    my $type = shift;

    return 0;    
}

# This driver can't convert SQL values at all.
sub can_convert_to
{
    my $self = shift;

    my $type = shift;

    return 0;
}

# Note: For compatibility with MySQL, I suggest this function will not be used
# with sub-queries and the such.
sub perform_select_query
{
    my $self = shift;

    my $query_str = shift;

    my $conn = $self->{'conn'};

    my $handle = $conn->prepare($query_str);

    $handle->execute();

    return {'type' => 'select', 'handle' => $handle};
}

sub get_query_row
{
    my $self = shift;

    my $query = shift;

    my (@row);

    # After a query reaches its last row, it returns a null row. Afterwards
    # subsequent calls to fetchrow_array() will return rows from the beginning.

    if (@row = $query->{'handle'}->fetchrow_array())
    {
        return @row;
    }
    else
    {
        $query->{'handle'} = undef;
        return @row;
    }
}

# Terminates a query. Should be called after all the desire query data was
# retrieved, in order to deallocate resources.
sub end_query
{
    my $self = shift;

    my $query = shift;

    %{$query} = ();
}

# ($error_code, $error_string) =
#       $sql_driver->perform_update_transaction($table_name, \%update_values, $where_clause);
#
# Perform an "UPDATE $table_name SET field1=value1, field2=value2..." query.
# Arguments:
#
# $table_name - the name of the table.
# %update_values - a hash containing the field_names as keys, and an array reference with
#                  the return of $types->convert_to_sql().. as values.
# $where_clause - The WHERE clause, without the WHERE.
#
# $error_code - 0 if succesful, non-zero if otherwise.
# $error_string - If unsuccesful returns an error string.
#
# At the moment assumes that the query length is unlimited.
# 
sub perform_update_transaction
{
    my $self = shift;

    my $table_name = shift;

    my $update_values = shift;

    my $where_clause = shift;


    my $types = $self->{'types'};

    my $conn = $self->{'conn'};

    my ($set_clause, $field, $value);

    # For the time being, put everything in one big UPDATE query.
    # Does PostgreSQL has a limit on the length of its queries?
    while (($field, $value) = each(%{$update_values}))
    {
        if (length($set_clause) > 0)
        {
            $set_clause .= ",";
        }
        $set_clause .= ($field . "=" .
                             ( ($value->[0] & 0x1) ?
                               $types->quote_sql_value($value->[1]) :
                               $value->[1]
                             )
                       );        
    }

    my $result = $conn->do("UPDATE " . $table_name . " SET " . $set_clause . " WHERE " . $where_clause);

    if (!defined($result))
    {
        return (1, "Error in input. Database Returned: " . $conn->errstr());
    }

    return (0, "");
}

sub perform_insert_transaction
{
    my $self = shift;
    my $table_name = shift;
    my $insert_values = shift;

    my $types = $self->{'types'};
    my $conn = $self->{'conn'};

    my ($field, $value, $fields_clause, $values_clause);

    while (($field, $value) = each(%{$insert_values}))
    {
        if (length($fields_clause)>0)
        {
            $fields_clause .= ',';
        }
        if (length($values_clause)>0)
        {
            $values_clause .= ',';
        }
        $fields_clause .= $field;
        $values_clause .=  ( ($value->[0] & 0x1) ?                             
                             $types->quote_sql_value($value->[1]) :
                             $value->[1]
                           );
    }

    my $result = $conn->do("INSERT INTO " . $table_name .
                             " (" . $fields_clause . ") " .
                             "VALUES (" . $values_clause . ")");
    
    if (!defined($result))
    {
        return (1, "Error in input. Database returned: " . $conn->errstr());
    }

    return (0, "");        
}

sub perform_delete_transaction
{
    my $self = shift;
    my $table_name = shift;
    my $where_clause = shift;

    my $conn = $self->{'conn'};

    my $result = $conn->do("DELETE FROM " . $table_name .
                             " WHERE " . $where_clause);

    if (!defined($result))
    {
        return (1, "Error in input. Database returned: " . $conn->errstr());
    }

    return (0, "");    
}

sub quote_sql_value
{
    my $self = shift;

    my $value = shift;

    my $conn = $self->{'conn'};

    if ($conn)
    {
        return ($conn->quote($value));
    }
    else
    {
        return ("'" . Arad::Utils::backslash_string($value, "'", "oct") . "'");
    }

}
1;