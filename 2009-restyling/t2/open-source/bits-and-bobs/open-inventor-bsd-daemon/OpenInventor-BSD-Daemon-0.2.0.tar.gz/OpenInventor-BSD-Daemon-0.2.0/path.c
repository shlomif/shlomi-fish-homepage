#include <stdlib.h>
#include <math.h>

#include <Xm/Form.h>
#include <Xm/LabelG.h>
#include <Xm/TextF.h>
#include <Xm/List.h>
#include <Xm/PushB.h>

#include "bezier.h"

point_t * path = NULL;
int path_len = 0;
static int max_path_len = 0;
Widget path_dialog;
static Widget listbox;
static Widget x_entry, y_entry, z_entry;
static Widget x_ang_entry, y_ang_entry, z_ang_entry;
static int item_pos = -1;
int path_changed = 0;

static int rad2deg(float rad)
{
    int ret = (int)(rad * 180 / M_PI);
    return (ret % 360);        
}

static float deg2rad(int degrees)
{
    return ((M_PI/180)*(degrees%360));    
}

XmString render_item(point_t * point)
{
    char buffer[1024];
    sprintf(buffer, "x=%.4f y=%.4f z=%.4f x_ang=%i y_ang=%i z_ang=%i", 
           (double)point->x, (double)point->y, (double)point->z,
           rad2deg(point->x_ang), rad2deg(point->y_ang), rad2deg(point->z_ang)
        );
    return XmStringCreateLocalized(buffer);
}

void callback_button_new(Widget w, XtPointer client_data, XtPointer call_data)
{
    XmString item_str;
    if (max_path_len == path_len)
    {
        max_path_len += 10;
        path = realloc(path, sizeof(path[0]) * max_path_len);
    }
    path[path_len].x = 0.0;
    path[path_len].y = 0.0;
    path[path_len].z = 0.0;
    path[path_len].x_ang = path[path_len].y_ang = path[path_len].z_ang = 0.0;
    path_len++;
    item_str = render_item(&path[path_len-1]);
    XmListAddItem(listbox, item_str, 0);
    XmStringFree(item_str);    
}

void callback_button_delete(Widget w, XtPointer client_data, XtPointer call_data)
{
    int * position_list;
    int position_count;
    int pos;
    if (XmListGetSelectedPos(listbox, &position_list, &position_count))
    {
        printf("pos_count=%i\n", position_count);
        pos = position_list[0]-1;
        XmListDeletePos(listbox, pos+1);
        memmove(path+pos, path+pos+1, sizeof(path[0]) * (path_len-pos-1));
        path_len--;
        XtFree((char *)position_list);
    }
}

float get_editbox_value(Widget w)
{
    char * text;
    float ret;

    text = XmTextFieldGetString(w);
    if (text == NULL)
    {
        return 0.0;
    }
    
    ret = atof(text);
    XtFree(text);
    return ret;
}

float get_editbox_ang(Widget w)
{
    char * text;
    float ret;

    text = XmTextFieldGetString(w);
    if (text == NULL)
    {
        return 0.0;
    }

    ret = deg2rad(atoi(text));
    XtFree(text);
    return ret;
}

static void update_item(int item_pos)
{
   point_t * point = &path[item_pos];
   {
        XmString item_str;
        item_str = render_item(point);
        XmListReplaceItemsPos(listbox, &item_str, 1, item_pos+1);
        XmStringFree(item_str);
        path_changed = 1;
    }
}


void callback_button_update(Widget w, XtPointer client_data, XtPointer call_data)
{
    point_t * point;
    if (item_pos < 0)
    {
        return;
    }
    point = &path[item_pos];

    point->x = get_editbox_value(x_entry);
    point->y = get_editbox_value(y_entry);
    point->z = get_editbox_value(z_entry);
    point->x_ang = get_editbox_ang(x_ang_entry);
    point->y_ang = get_editbox_ang(y_ang_entry);
    point->z_ang = get_editbox_ang(z_ang_entry);
    update_item(item_pos);
}
 


static void exchange(int item_pos)
{
    point_t temp;
    temp = path[item_pos];
    path[item_pos] = path[item_pos+1];
    path[item_pos+1] = temp;

    update_item(item_pos);
    update_item(item_pos+1);        

    path_changed = 1;
}

void callback_button_up(Widget w, XtPointer client_data, XtPointer call_data)
{
    point_t * point;
    if (item_pos < 0)
    {
        return;
    }

    if (item_pos == 0)
    {
        return;
    }

    exchange(item_pos-1);    
}

void callback_button_down(Widget w, XtPointer client_data, XtPointer call_data)
{
    point_t * point;
    if (item_pos < 0)
    {
        return;
    }

    if (item_pos >= path_len-1)
    {
        return;
    }

    exchange(item_pos);    
}


void set_editbox_to_float(Widget edit, float value)
{
    char str[256];
    sprintf(str, "%f", (double)value);
    XmTextFieldSetString(edit, str);
}

void set_editbox_to_ang(Widget edit, float ang)
{
    char str[256];
    sprintf(str, "%i", rad2deg(ang));
    XmTextFieldSetString(edit, str);
}

void listbox_select_callback(Widget w, XtPointer client_data, XtPointer call_data)
{
    int * position_list;
    int position_count;
    int pos;
    if (XmListGetSelectedPos(listbox, &position_list, &position_count))
    {
        char str[256];
        point_t * point;
        
        item_pos = position_list[0]-1;
        point = &path[item_pos];
        
        set_editbox_to_float(x_entry, point->x);
        set_editbox_to_float(y_entry, point->y);
        set_editbox_to_float(z_entry, point->z);
        set_editbox_to_ang(x_ang_entry, point->x_ang);
        set_editbox_to_ang(y_ang_entry, point->y_ang);
        set_editbox_to_ang(z_ang_entry, point->z_ang);
    }
}



void create_path_dialog(Widget pb)
{
    Widget entry_form, x_entry_label;
    Widget y_entry_label;
    Widget z_entry_label;
    Widget listbox_form;
    Widget buttons_form;
    Widget button_up, button_down, button_new, button_delete;
    Widget super_entry_form, side_buttons_form, button_update;
    Widget x_ang_entry_label, y_ang_entry_label, z_ang_entry_label;

    Arg args[50];
    int n = 0;

    XtSetArg (args[n], XmNautoUnmanage, False); n++;
    XtSetArg (args[n], XmNuserData, 0); n++;
    XtSetArg (args[n], XmNfractionBase, 1); n++;
        
    path_dialog = XmCreateFormDialog (pb, "Path Creation", args, n);

    super_entry_form = 
        XtVaCreateManagedWidget(
            "super_entry",
            xmFormWidgetClass, path_dialog,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNleftPosition, 0,
            XmNrightPosition, 1,
            XmNleftAttachment, XmATTACH_POSITION,
            XmNrightAttachment, XmATTACH_POSITION,
            XmNfractionBase, 1,
            NULL           
            );

    
    entry_form = 
        XtVaCreateManagedWidget(
            "entry",
            xmFormWidgetClass, super_entry_form,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNleftAttachment, XmATTACH_POSITION,            
            XmNleftPosition, 0,
            XmNfractionBase, 1,
            NULL           
            );

    side_buttons_form = 
        XtVaCreateManagedWidget(
            "side_buttons_form",
            xmFormWidgetClass, super_entry_form,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, entry_form,
            XmNrightAttachment, XmATTACH_POSITION,
            XmNrightPosition, 1,
            XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNbottomWidget, entry_form,
            NULL
            );

    button_update =
        XtVaCreateManagedWidget(
            "Update",
            xmPushButtonWidgetClass, side_buttons_form,

            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            NULL
            );

    XtAddCallback(button_update, XmNactivateCallback, callback_button_update, NULL);
    
    x_entry_label = 
        XtVaCreateManagedWidget(
            "x:  ",
            xmLabelGadgetClass, entry_form,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            NULL
            );

    x_entry = 
        XtVaCreateManagedWidget(
            "x_entry",
            xmTextFieldWidgetClass, entry_form,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, x_entry_label,
            //XmNrightAttachment, XmATTACH_POSITION,
            //XmNrightPosition, 1,            
            NULL
            );

    XtVaSetValues(x_entry_label,
        XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
        XmNbottomWidget, x_entry,
        NULL
            );

    x_ang_entry_label =
        XtVaCreateManagedWidget(
            "X Angle:  ",
            xmLabelGadgetClass, entry_form,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, x_entry,
            XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNbottomWidget, x_entry,
            NULL
            );

    x_ang_entry = 
        XtVaCreateManagedWidget(
            "x_ang_entry",
            xmTextFieldWidgetClass, entry_form,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, x_ang_entry_label,
            XmNrightAttachment, XmATTACH_POSITION,
            XmNrightPosition, 1,
            XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNbottomWidget, x_entry,
            NULL
            );
            


    y_entry_label = 
        XtVaCreateManagedWidget(
            "y:  ",
            xmLabelGadgetClass, entry_form,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, x_entry_label,
            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            XmNrightAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNrightWidget, x_entry_label,
            NULL
            );

    y_entry =
        XtVaCreateManagedWidget(
            "y_entry",
            xmTextFieldWidgetClass, entry_form,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, x_entry,
            XmNleftAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNleftWidget, x_entry,
            //XmNrightAttachment, XmATTACH_POSITION,
            //XmNrightPosition, 1,
            NULL
            );

    y_ang_entry_label =
        XtVaCreateManagedWidget(
            "Y Angle:  ",
            xmLabelGadgetClass, entry_form,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, x_ang_entry_label,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, y_entry,
            XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNbottomWidget, y_entry,
            NULL
            );

    y_ang_entry = 
        XtVaCreateManagedWidget(
            "x_ang_entry",
            xmTextFieldWidgetClass, entry_form,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, x_ang_entry,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, y_ang_entry_label,
            XmNrightAttachment, XmATTACH_POSITION,
            XmNrightPosition, 1,
            XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNbottomWidget, y_entry,
            NULL
            );

    
#if 1
    XtVaSetValues(y_entry_label,
        XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
        XmNbottomWidget, y_entry,
        NULL
        );
#endif

    z_entry_label = 
        XtVaCreateManagedWidget(
            "z:  ",
            xmLabelGadgetClass, entry_form,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, y_entry_label,
            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            XmNrightAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNrightWidget, y_entry_label,
            NULL
            );

    z_entry =
        XtVaCreateManagedWidget(
            "z_entry",
            xmTextFieldWidgetClass, entry_form,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, y_entry,
            XmNleftAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNleftWidget, y_entry,
            //XmNrightAttachment, XmATTACH_POSITION,
            //XmNrightPosition, 1,
            NULL
            );

    XtVaSetValues(z_entry_label,
        XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
        XmNbottomWidget, z_entry,
        NULL
        );

    z_ang_entry_label =
        XtVaCreateManagedWidget(
            "Z Angle:  ",
            xmLabelGadgetClass, entry_form,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, y_ang_entry_label,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, z_entry,
            XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNbottomWidget, z_entry,
            NULL
            );

    z_ang_entry = 
        XtVaCreateManagedWidget(
            "x_ang_entry",
            xmTextFieldWidgetClass, entry_form,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, y_ang_entry,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, z_ang_entry_label,
            XmNrightAttachment, XmATTACH_POSITION,
            XmNrightPosition, 1,
            XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET,
            XmNbottomWidget, z_entry,
            NULL
            );
    
    

    listbox_form = 
        XtVaCreateManagedWidget(
            "listbox_form",
            xmFormWidgetClass, path_dialog,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, super_entry_form,
            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            XmNrightAttachment, XmATTACH_POSITION,
            XmNrightPosition, 1,
            XmNbottomAttachment, XmATTACH_POSITION,
            XmNbottomPosition, 1,
            XmNfractionBase, 1,
            NULL
                );

    listbox = 
        XtVaCreateManagedWidget(
            "listbox",
            xmListWidgetClass, listbox_form,
            XmNvisibleItemCount, 10,

            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNbottomAttachment, XmATTACH_POSITION,
            XmNbottomPosition, 1,
            NULL
            );

    XtAddCallback(listbox, XmNbrowseSelectionCallback, listbox_select_callback, NULL);

    buttons_form = 
        XtVaCreateManagedWidget(
            "buttons",
            xmFormWidgetClass, listbox_form,
            XmNfractionBase, 1,
            XmNleftAttachment, XmATTACH_WIDGET,
            XmNleftWidget, listbox,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            XmNbottomAttachment, XmATTACH_POSITION,
            XmNbottomPosition, 1,
            NULL
            );

    button_new =
        XtVaCreateManagedWidget(
            "New Point",
            xmPushButtonWidgetClass, buttons_form,

            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            XmNtopAttachment, XmATTACH_POSITION,
            XmNtopPosition, 0,
            NULL            
        );

    XtAddCallback(button_new, XmNactivateCallback, callback_button_new, NULL);

    button_delete =
        XtVaCreateManagedWidget(
            "Delete Point",
            xmPushButtonWidgetClass, buttons_form,

            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, button_new,
            NULL
            );

    XtAddCallback(button_delete, XmNactivateCallback, callback_button_delete, NULL);

    button_up = 
        XtVaCreateManagedWidget(
            "Up",
            xmPushButtonWidgetClass, buttons_form,
            
            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, button_delete,
            NULL
            );

    XtAddCallback(button_up, XmNactivateCallback, callback_button_up, NULL);

    button_down = 
        XtVaCreateManagedWidget(
            "Down",
            xmPushButtonWidgetClass, buttons_form,
            
            XmNleftAttachment, XmATTACH_POSITION,
            XmNleftPosition, 0,
            XmNtopAttachment, XmATTACH_WIDGET,
            XmNtopWidget, button_up,
            NULL
            );
            
    XtAddCallback(button_down, XmNactivateCallback, callback_button_down, NULL);
    
    XtManageChild(path_dialog);
}
