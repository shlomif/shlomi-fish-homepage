mymake()
{
    args="$*"
    (cd $this && make $args)
}

