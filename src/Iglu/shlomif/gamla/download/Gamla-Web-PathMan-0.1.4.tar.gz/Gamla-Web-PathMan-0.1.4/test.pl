#!/usr/bin/perl

use strict;

use Data::Dumper;

#use Gamla::Web::PathMan::Pointer::WithMount;
use Gamla::Web::PathMan::Perl;

my $pathman = Gamla::Web::PathMan::Perl->new();

my $p = $pathman->get_base_pointer();

$p->mkdir_("Hello");
$p->mkdir_("Shlomif");
$p->atomic_cd("Hello");
$p->mkdir_("You");
my $p2 = $p->duplicate1();
$p->atomic_cd("..");
$p->mkdir_("Chen");
$p->atomic_cd("Chen");
$p->mkdir_("Shapira");
$p->cd_(["..", ".."]);
$p->mkdir_("Ira");
$p->cd_(["Ira", "..", "Chen" , "Shapira" , ".", ".."]);
$p->mkdir_("Hackers-IL");

$p2->mkdir_("World");
$p2->mkdir_("Bill (Gates Naturally)");


my $d = Data::Dumper->new([$pathman, $p],["\$pathman", "\$p"]);

my $dump_text =  $d->Dump();

open O, ">dump.pl";
print O $dump_text;
close(O);
