    keys->insertItem(i18n("Show klipper popupmenu"),
                                "show-klipper-popupmenu", "CTRL+ALT+V");
    keys->insertItem(i18n("Manually invoke action on current clipboard"),
                                "repeat-last-klipper-action", "CTRL+ALT+R");
    keys->insertItem(i18n("Enable/disable clipboard actions"),
                           "toggle-clipboard-actions", "CTRL+ALT+X" );
