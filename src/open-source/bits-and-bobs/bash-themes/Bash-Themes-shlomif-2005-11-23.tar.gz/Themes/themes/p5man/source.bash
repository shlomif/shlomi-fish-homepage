load_common mymake

p5man_home="/home/shlomi/progs/perl/POD-Revamp/perl5-man-pages/perl5-man-pages/trunk"
this="$p5man_home"

cd $this

pman()
{
    nroff -man $p5man_home/man/$1.1 | less -isrr
}

