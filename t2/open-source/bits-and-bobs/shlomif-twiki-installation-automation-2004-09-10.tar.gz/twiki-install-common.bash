downloads_base_dir="/home/shlomi/Download/unpack/net/www/wikis/TWiki"
source_dir="$downloads_base_dir/TWiki-base"
dest_dir="/var/www/Wikis/twiki"
www_base="twiki"
httpd_user="apache"
httpd_default_url="http://localhost"

function adjust_permissions()
{
    (cd "$dest_dir" ;
    find ./data -type f | xargs chmod 664
    find ./data -type d | xargs chmod 775
    chown -R "$httpd_user" ./data
    find ./pub -type d | xargs chmod 775
    find ./pub -type d | xargs chown "$httpd_user"
    )
}
