# Arad::UI::Text::TableEditDialog - The text/readline table editing
# dialog.
#
# Notice that it has two readline history lists: one for entering commands
# and one
# for entering database values. Since GNU readline supports only one global
# history list, I needed to set and reset the history list before switching
# to the value entering.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)

package Arad::UI::Text::TableEditDialog;

use Arad::UI::TableEditDialog;

@ISA = qw(Arad::UI::TableEditDialog);

use strict;

use Arad::Utils;

use Term::ReadLine;

require 'flush.pl';

my $cmds_history_size = 100;
my $values_history_size = 200;

sub initialize
{
    my $self = shift;

    my $ui = shift;

    $self->SUPER::initialize($ui);

    my $options = shift;

    if ($options =~ /no_readline/)
    {
        $self->{'cmds_readline'} = Term::ReadLine::Stub->new('Arad Commands Prompt');
        $self->{'values_readline'} = Term::ReadLine::Stub->new('Arad Values Prompt');        
    }
    else
    {        
        $self->{'cmds_readline'} = Term::ReadLine->new('Arad Commands Prompt');
        $self->{'values_readline'} = Term::ReadLine->new('Arad Values Prompt');
    }

    $self->{'cmds_history'} = [];
    $self->{'values_history'} = [];
}

# Present the values of the fields. It is invoked when the show command is
# initiated and on the beginning of the dialog.
sub present_values
{
    my $self = shift;

    my $editor = $self->{'editor'};

    my $position = $editor->get_record_position();

    if ($position < 0)
    {
        print "[out of filter]\n\n";
    }
    else
    {
        print "Record No. " . $position . "\n\n";
    }

    my ($a, $field_name, $value);

    for($a=0 ; $a < scalar(@{$self->{'fields'}}) ; $a++)
    {
        $field_name = $self->{'fields'}->[$a]->{'name'};

        $value = $editor->get_field_value($field_name);

        print $field_name . ("." x (40-length($field_name))) .
            substr(Arad::Utils::backslash_string($value),0,40) . "\n";        
    }
}

# Those handle_cmd_ functions are the command processors, which handle
# different commands which the dialog receives.

my (@command_processors);

sub handle_cmd_help
{
    my $self = shift;

    my $rest = shift;

    my ($a);
    for($a=0;$a<scalar(@command_processors);$a++)
    {
        print $command_processors[$a]->{'help'} . "\n";
    }

    return 0;
}

sub handle_cmd_show
{
    my $self = shift;
    my $rest = shift;

    $self->present_values();

    return 0;
}

sub handle_cmd_exit
{
    my $self = shift;
    my $rest = shift;

    return 'exit';
}

sub handle_cmd_set
{
    my $self = shift;
    my $rest = shift;

    my $field_name = $rest;

    my $term = $self->{'values_readline'};
    my $editor = $self->{'editor'};

    if (!exists($self->{'fields_index'}->{$field_name}))
    {
        print "No such field";
    }
    else
    {
        my ($input, @ret);

        print "Enter the new value of " . $field_name . ":\n\n";
        #$input = <>;
        #chomp($input);
        my $value = $editor->get_field_value($field_name);

        # Set readline's history to the values' history
        {
            my ($a);
            $term->clear_history();

            for($a=0; $a < scalar(@{$self->{'values_history'}}) ; $a++)
            {
                $term->add_history($self->{'values_history'}->[$a]);
            }
        }
        

        $input = $term->readline(($field_name . "="), Arad::Utils::backslash_string($value));

        # Add the newly entered value to the values' history list
        if ($input =~ /\S/)
        {
            push @{$self->{'values_history'}}, $input;
            while (scalar(@{$self->{'values_history'}}) > $values_history_size)
            {
                shift(@{$self->{'values_history'}});
            }            
        }

        $input = Arad::Utils::unbackslash_string($input);

        @ret = $editor->set_field_value($field_name, $input);

        if ($ret[0] != 0)
        {
            print "\n" . $ret[1] . "\n";
        }

        # Reset the readline's history list to the commands' history
        {
            my ($a);
            $term->clear_history();

            for($a=0; $a < scalar(@{$self->{'cmds_history'}}) ; $a++)
            {
                $term->add_history($self->{'cmds_history'}->[$a]);
            }
        }

    }

    return 0;
}

sub handle_cmd_save
{
    my $self = shift;
    my $rest = shift;

    my (@ret);

    @ret = $self->{'editor'}->save_record("");

    if ($ret[0] != 0)
    {
        print $ret[1] . "\n";
    }
    else
    {
        print "Record Saved.\n";
    }
}

sub handle_cmd_load
{
    my $self = shift;
    my $rest = shift;

    my $editor = $self->{'editor'};

    if ($editor->has_record_changed())
    {
        my $result = $self->message_box("The current record has changed. Are you sure you want to load a new one (and lose the changes)?", "yes-no");

        if ($result eq 'no')
        {
            return 0;
        }
    }

    my (@ret, @pkey, %pkey_values, $a, $input);

    @ret = $editor->get_primary_key();

    @pkey = @{$ret[0]};

    foreach $a (@pkey)
    {
        print "\nEnter the value for " . $a . ":\n\n";
        $input = <>;
        chomp($input);
    
        $pkey_values{$a} = $input;
    }

    @ret = $editor->load_record_by_primary_key(\%pkey_values);

    if ($ret[0] != 0)
    {
        print "\n" . $ret[1] . "\n";
    }
    else
    {
        $self->present_values();
    }

    return 0;
}

sub handle_cmd_new
{
    my $self = shift;
    my $rest = shift;

    my $editor = $self->{'editor'};

    if ($editor->has_record_changed())
    {
        my $result = $self->message_box("The current record has changed. Are you sure you want to create a new one (and lose the changes)?", "yes-no");

        if ($result eq 'no')
        {
            return 0;
        }
    }
    

    my (@ret);

    @ret = $editor->new_record();

    if ($ret[0] != 0)
    {
        print "\n" . $ret[1] . "\n";        
    }
    else
    {
        $self->present_values();
    }
}

sub handle_cmd_next
{
    my $self = shift;
    my $rest = shift;

    my $editor = $self->{'editor'};

    if ($editor->has_record_changed())
    {
        my $result = $self->message_box("The current record has changed. Are you sure you want to move to a new one (and lose the changes)?", "yes-no");

        if ($result eq 'no')
        {
            return 0;
        }
    }
    

    my ($offset, @ret);

    if ($rest =~ /[+\-]?\d+/)
    {
        $offset = $rest;
    }
    elsif ($rest eq '')
    {
        $offset = 1;
    }
    else
    {
        print "Incorrect argument for next.\n";
    }

    @ret = $editor->next_or_prev_record($offset);

    if ($ret[0] != 0)
    {
        print "\n" . $ret[1] . "\n";        
    }
    else
    {
        $self->present_values();
    }
}

sub handle_cmd_prev
{
    my $self = shift;
    my $rest = shift;

    my $editor = $self->{'editor'};

    if ($editor->has_record_changed())
    {
        my $result = $self->message_box("The current record has changed. Are you sure you want to move to a new one (and lose the changes)?", "yes-no");

        if ($result eq 'no')
        {
            return 0;
        }
    }
    

    my ($offset, @ret);

    if ($rest =~ /[+\-]?\d+/)
    {
        $offset = $rest;
    }
    elsif ($rest eq '')
    {
        $offset = 1;
    }
    else
    {
        print "Incorrect argument for next.\n";
    }

    @ret = $editor->next_or_prev_record(-$offset);

    if ($ret[0] != 0)
    {
        print "\n" . $ret[1] . "\n";        
    }
    else
    {
        $self->present_values();
    }
}

sub handle_cmd_delete
{
    my $self = shift;
    my $rest = shift;

    my $editor = $self->{'editor'};

    my $result = $self->message_box("Are you sure you want to delete this record?", "yes-no");

    if ($result eq 'no')
    {
        return 0;
    }

    

    my @ret = $editor->delete_record();

    if ($ret[0] != 0)
    {
        print "\n" . $ret[1] . "\n";
    }
    else
    {
        $self->present_values();
    }
}

# An array of the command processor functions. Each receive the instance of the
# dialog, (so basically they are methods), and the rest of the line that was
# entered.
#
# To add your own command, write a method for it, and add it to this list. The
# list is ordered alphabetically, so you should add it at the proper place.
@command_processors =
(
 {
     # regex is the regular expression to be matched against the first word of the entered line
     'regex' => '(delete)',
     # help is the line to write when invoking the help command
     'help' => 'delete - deletes the current record',
     # func is a reference to the command's function.
     'func' => \&handle_cmd_delete,
 },
 {
     'regex' => '(exit|quit)',
     'help' => 'exit - exits from the program',
     'func' => \&handle_cmd_exit,
 }, 
 {
     'regex' => '(help|h)',
     'help' => 'help/h - displays this help screen',
     'func' => \&handle_cmd_help,
 },
 {
     'regex' => '(load)',
     'help' => 'load - loads a different record from the table',
     'func' => \&handle_cmd_load,
 },
 {
     'regex' => '(next|n)',
     'help' => 'next/n [offset=1] - moves to the next record',
     'func' => \&handle_cmd_next,
 },
 {
     'regex' => '(new)',
     'help' => 'new - creates a new record',
     'func' => \&handle_cmd_new,
 },
 {
     'regex' => '(prev|p)',
     'help' => 'prev/p [offset=1] - moves to the previous record',
     'func' => \&handle_cmd_prev,
 }, 
 {
     'regex' => '(save)',
     'help' => 'save - saves the current record',
     'func' => \&handle_cmd_save,
 },
 {
     'regex' => '(set)',
     'help' => 'set [field_name] - changes the value of the field [field_name]',
     'func' => \&handle_cmd_set
 },
 {
     'regex' => '(show|sh)',
     'help' => 'show/sh - displays the current values of the field',
     'func' => \&handle_cmd_show,
 },
);

# Process a line of input that was received and act accordingly. Returns what
# the command processor returned.
sub process_input
{
    my $self = shift;

    my $input = shift;


    my ($cmd, $rest);

    $cmd = $input;
    $rest = $input;
    $cmd =~ s!\s.*$!!;
    if ($input =~ /\s/)
    {
        $rest =~ s!.*\s+!!;
    }
    else
    {
        $rest = '';
    }

    $cmd =~ tr!A-Z!a-z!;

    my ($a, $regex);

    for($a=0;$a<scalar(@command_processors);$a++)
    {
        $regex = $command_processors[$a]->{'regex'};
        if ($cmd =~ /^$regex$/)
        {
            return &{$command_processors[$a]->{'func'}}($self, $rest);
        }
    }
}

# The dialog loop: input a line, process it, input another line, process it
# etc.
sub dialog_loop
{
    my $self = shift;

    my $term = $self->{'cmds_readline'};

    print "type \"help\" for help.\n\n";

    my ($input, $prompt, @ret);

    $prompt = ">";


    $self->present_values();

    while ($ret[0] ne 'exit')
    {
        print "\n";

        # the readline() method automatically adds the entry to the history list
        $input = $term->readline($prompt); 

        if (!defined($input))
        {
            last;
        }

        push @{$self->{'cmds_history'}}, $input;
        while (scalar(@{$self->{'cmds_history'}}) > $cmds_history_size)
        {
            shift(@{$self->{'cmds_history'}});
        }

        print "\n";
    
        @ret = $self->process_input($input);

    } 
    
    return 0;
}

# Inputs a single field from the user, for instance when a
# new record is created
sub get_field_from_user
{
    my $self = shift;

    my $field_name = shift;

    my $term = $self->{'values_readline'};
    
    my ($input, @ret);

    print "Enter the value of " . $field_name . ":\n\n";

    {
        my ($a);
        $term->clear_history();

        for($a=0; $a < scalar(@{$self->{'values_history'}}) ; $a++)
        {
            $term->add_history($self->{'values_history'}->[$a]);
        }
    }

    $input = $term->readline(($field_name . "="));

    # Add the newly entered value to the values' history list
    if ($input =~ /\S/)
    {
        push @{$self->{'values_history'}}, $input;
        while (scalar(@{$self->{'values_history'}}) > $values_history_size)
        {
            shift(@{$self->{'values_history'}});
        }            
    }

    $input = Arad::Utils::unbackslash_string($input);

    # Reset the readline's history list to the commands' history
    {
        my ($a);
        $term->clear_history();

        for($a=0; $a < scalar(@{$self->{'cmds_history'}}) ; $a++)
        {
            $term->add_history($self->{'cmds_history'}->[$a]);
        }
    }
            
    return $input;    
}

sub message_box
{
    my $self = shift;

    my $text = shift;
    my $type = shift;

    return $self->SUPER::message_box($text, $type, $self->{'cmds_readline'});    
}

