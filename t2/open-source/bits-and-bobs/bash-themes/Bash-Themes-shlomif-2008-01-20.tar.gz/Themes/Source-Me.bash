__themes_dir="$(dirname $BASH_SOURCE[-1])"

function load_common
{
    source "${__themes_dir}/common/$1.bash"
}

function __this_theme_dir
{
    echo "${__themes_dir}/themes/$__theme"
}

function __this_theme_source
{
    echo "$(__this_theme_dir)/source.bash"
}

function Theme
{
    local filename

    __theme="$1"
    shift;

    filename="$(__this_theme_source)"
    test -e "$filename" || { echo "Unknown theme" 1>&2 ; return 1; }
    source "$filename"
}

complete -W "$(cat ${__themes_dir}/list-of-themes.txt)" Theme

