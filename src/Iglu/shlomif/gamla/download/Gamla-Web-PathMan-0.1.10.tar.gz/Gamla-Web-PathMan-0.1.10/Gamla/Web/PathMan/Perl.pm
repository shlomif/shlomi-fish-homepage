package Gamla::Web::PathMan::Perl;

use strict;

use Gamla::Web::PathMan::Base;
use Gamla::Web::PathMan::Perl::Pointer;

use vars qw(@ISA);

@ISA=qw(Gamla::Web::PathMan::Base);

sub initialize
{
    my $self = shift;

    my $root;

    $root = 
    {
        '..' => undef,
        'is_mounted' => 0,
        'attrbs' => {},
        'subdirs' => {},
    };

    $self->{'root'} = $root;
}

sub get_root_dir
{
    my $self = shift;

    return $self->{'root'};
}

sub get_base_pointer
{
    my $self = shift;

    return Gamla::Web::PathMan::Perl::Pointer->new($self);
}
