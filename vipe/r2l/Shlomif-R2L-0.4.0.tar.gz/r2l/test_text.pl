#!/usr/bin/perl -w

use strict;

use Shlomif::R2L::Poller::File;

# Use the default
my $instance = Shlomif::R2L::Poller::File->new($ENV{'HOME'} . "/.r2l");

$instance->disable();

sleep(10);

if ($instance->poll())
{
    print "The value has changed.\n";
}

print $instance->get_status(), "\n";


