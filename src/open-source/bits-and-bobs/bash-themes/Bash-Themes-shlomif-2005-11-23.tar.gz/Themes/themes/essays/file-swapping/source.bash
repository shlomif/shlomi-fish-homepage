load_common mymake

this="$HOME/Svn/Docs/Philosophy/IP/File-Swapping/Case-for"
summary="$this/summary"
docbook="$trunk/docbook"

cd $this

