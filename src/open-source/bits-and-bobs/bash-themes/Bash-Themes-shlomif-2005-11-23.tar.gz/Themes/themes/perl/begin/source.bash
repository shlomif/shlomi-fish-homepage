load_common mymake

this="$HOME/Docs/programming/Perl/web-sites/perl-begin/trunk"

cd $this

