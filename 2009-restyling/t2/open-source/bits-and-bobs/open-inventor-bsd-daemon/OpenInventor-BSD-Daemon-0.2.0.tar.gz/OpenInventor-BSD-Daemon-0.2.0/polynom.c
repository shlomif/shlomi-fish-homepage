#include <stdio.h>
#include <stdlib.h>

struct polynom_struct
{
    int num_points;
    float * coeffs;
};

typedef struct polynom_struct polynom_t;

polynom_t * polynom_alloc(int num_points, const float * coeffs)
{
    polynom_t * ret;

    ret = malloc(sizeof(*ret));

    ret->num_points = num_points;
    ret->coeffs = malloc(sizeof(coeffs[0])*num_points);
    if (coeffs)
    {
        memcpy(ret->coeffs, coeffs, sizeof(coeffs[0])*num_points);
    }
    else
    {
        int i;
        for(i=0;i<num_points;i++)
        {
            ret->coeffs[i] = 0.0;
        }
    }
    return ret;
}

void polynom_free(polynom_t * p)
{
    free(p->coeffs);
    free(p);
}

polynom_t * polynom_add(polynom_t * a, polynom_t * b)
{
    polynom_t * max, * min, * ret;
    int i;
    if (a->num_points > b->num_points)
    {
        max = a;
        min = b;
    }
    else
    {
        max = b;
        min = a;        
    }
    ret = polynom_alloc(max->num_points, max->coeffs);
    for(i=0;i<min->num_points;i++)
    {
        ret->coeffs[i] += min->coeffs[i];
    }
    return ret;
}

float polynom_eval(polynom_t * p, float value)
{
    float ret = 0;
    int i;
    for (i = p->num_points-1; i>=0 ;i--)
    {
        ret = ret * value;
        ret += p->coeffs[i];
    }

    return ret;
}

polynom_t * polynom_mult(polynom_t * a, polynom_t * b)
{
    polynom_t * ret;
    float * coeffs;
    int a_iter, b_iter, ret_num_points;
    int i;

    ret_num_points = (a->num_points+b->num_points-1);

    ret = polynom_alloc(ret_num_points, NULL);

    coeffs = ret->coeffs;
    
    for(i=0;i<ret_num_points;i++)
    {
        coeffs[i] = 0;
    }

    for(a_iter=0;a_iter < a->num_points;a_iter++)
    {
        for(b_iter=0;b_iter < b->num_points;b_iter++)
        {
            coeffs[a_iter+b_iter] += a->coeffs[a_iter] * b->coeffs[b_iter];
        }
    }

    return ret;
}

void polynom_factor(polynom_t * p, float factor)
{
    int i;
    for(i=0;i<p->num_points;i++)
    {
        p->coeffs[i] *= factor;
    }
}

polynom_t * polynom_get_bezier(int n, float * p_ks)
{
    polynom_t * ret = NULL, * new_ret;
    int k, i;
    polynom_t * u, * one_minus_u, * zero;
    static const float u_coeffs[2] = {0 , 1};
    static const float one_minus_u_coeffs[2] = {1, -1};
    static const float identity_coeffs[1] = { 1};
    static const float zero_coeffs[1] = { 0};
    polynom_t * u_k, * new_u_k;
    float c_n_k;
    
    u = polynom_alloc(2, u_coeffs);
    one_minus_u = polynom_alloc(2, one_minus_u_coeffs);
    ret = polynom_alloc(1, zero_coeffs);
    
    for(k=0;k<=n;k++)
    {
        u_k = polynom_alloc(1, identity_coeffs);
        
        for(i=0;i<k;i++)
        {
            new_u_k = polynom_mult(u_k, u);
            polynom_free(u_k);
            u_k = new_u_k;
        }

        for(i=0;i<n-k;i++)
        {
            new_u_k = polynom_mult(u_k, one_minus_u);
            polynom_free(u_k);
            u_k = new_u_k;
        }

        c_n_k = 1.0;
        for(i=k+1;i<=n;i++)
        {
            c_n_k *= i;
        }
        for(i=1;i<=(n-k);i++)
        {
            c_n_k /= i;
        }

        polynom_factor(u_k, c_n_k* p_ks[k]);
        
        new_ret = polynom_add(ret, u_k);

        polynom_free(u_k);

        polynom_free(ret);

        ret = new_ret;
    }

    return ret;
}
