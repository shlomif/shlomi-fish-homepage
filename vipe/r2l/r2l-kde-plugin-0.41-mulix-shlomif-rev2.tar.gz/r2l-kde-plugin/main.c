#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>

#include "r2llib.h"
#include "ui_plugin.h"

/* should we quit the main loop? */
static int quit_flag = 0;

void
handle_signal(int signum)
{
    quit_flag = 1;
}

/* perform r2l's main loop - wait for events and handle them. both r2l */
/* mode external changes, and r2l mode change requests.                */
void
run_main_loop(r2llib_t r2l_ctrl, ui_plugin_t ui)
{
    R2L_STATE md = R2L_ERROR;
    BIDITEXT_BASE_STATE bs = BT_BASE_ERROR;
    int ui_fd = ui_get_listening_fd(ui);
    fd_set read_fds;
    struct timeval timeout;
    int rc;

    r2l_query_state(r2l_ctrl, &md, &bs);
    ui_notify_of_r2l_mode(ui, md, bs);

    /* be ready to handle various signals. */
    signal(SIGINT, handle_signal);
    signal(SIGQUIT, handle_signal);
    signal(SIGHUP, handle_signal);

    while (!quit_flag) {
        FD_ZERO(&read_fds);
	if (ui_fd >= 0) {
            FD_SET(ui_fd, &read_fds);
	}
	timeout.tv_sec = 1;
	timeout.tv_usec = 0;
	rc = select(ui_fd+1, &read_fds, NULL, NULL, &timeout);
	if (rc == 1 && FD_ISSET(ui_fd, &read_fds)) {
	    /* ui's file descriptor is active. */
	    ui_perform_callback(ui, r2l_ctrl);
	}
	else if (rc == 0) { /* timeout. */
	    int should_notify = 0;
    	    BIDITEXT_BASE_STATE bs2 = BT_BASE_ERROR;
    	    R2L_STATE md2 = R2L_ERROR;

	    r2l_query_state(r2l_ctrl, &md2, &bs2);

	    /* check for r2l mode change. */
	    if (md2 != md) {
		md = md2;
		should_notify = 1;
	    }
	    /* check biditext mode change */
	    if (bs2 != bs) {
		bs = bs2;
    		should_notify = 1;
	    }
	    if (should_notify) {
    		ui_notify_of_r2l_mode(ui, md, bs);
	    }
	}
	else if (rc == -1) {
	    if (errno != EINTR)
		quit_flag = 1;
	}
    }
}

struct main_data {
    r2llib_t r2l_ctrl;
    ui_plugin_t ui;
    R2L_STATE md;
    BIDITEXT_BASE_STATE bs;
};

/* timer callback, used if the ui plugin provides its own main loop. */
int
main_timer_cb(void* m_data)
{
    struct main_data* main_data = (struct main_data*)m_data;
    int should_notify = 0;
    R2L_STATE md2;
    BIDITEXT_BASE_STATE bs2;

    assert(m_data);

    /* poll for r2l mode change. */
    md2 = r2l_get_current_r2l_state(main_data->r2l_ctrl);
    if (md2 != main_data->md) {
	main_data->md = md2;
	should_notify = 1;
    }
    bs2 = r2l_get_current_biditext_base_state(main_data->r2l_ctrl);
    if (bs2 != main_data->bs) {
	main_data->bs = bs2;
	should_notify = 1;
    }
    if (should_notify) {
    	ui_notify_of_r2l_mode(main_data->ui, main_data->md, main_data->bs);
    }

    return 1;
}

int
main(int argc, char* argv[])
{
    r2llib_t r2l_ctrl;
    ui_plugin_t ui;
    struct main_data* m_data;
    R2L_ERROR_TYPE r2l_err;

    m_data = (struct main_data*)malloc(sizeof(struct main_data));
    if (!m_data) {
	fprintf(stderr, "main: allocation of m_data: out of memory.\n");
	exit(1);
    }

    r2l_ctrl = r2l_init(&argc, argv, &r2l_err);
    if (!r2l_ctrl) {
	fprintf(stderr, "main: r2l_init failed: ");
	switch(r2l_err) {
	    case R2L_ERR_OOM:
		fprintf(stderr, "out of memory.\n");
		break;
	    case R2L_ERR_INVALID_REPR:
		fprintf(stderr, "control file name isn't a file name.\n");
		break;
	    case R2L_ERR_ACCESS:
		fprintf(stderr, "control file not accessible.\n");
		break;
	    default:
		fprintf(stderr, "unknown error.\n");
		break;
	}
	exit(1);
    }

    ui = ui_init(argc, argv, r2l_ctrl);
    if (!ui) {
	fprintf(stderr, "main: ui_init failed.\n");
	exit(1);
    }

    m_data->r2l_ctrl = r2l_ctrl;
    m_data->ui = ui;
    m_data->md = R2L_ERROR;
    m_data->bs = BT_BASE_ERROR;

    /* use the plugin's mainloop, or our main's mainloop. */
    if (ui_provides_main_loop(ui)) {
        r2l_query_state(m_data->r2l_ctrl, &m_data->md, &m_data->bs);
        ui_notify_of_r2l_mode(ui, m_data->md, m_data->bs);
	ui_register_timer_callback(ui, 1000, main_timer_cb, m_data);
	ui_main_loop(ui);
    }
    else {
        run_main_loop(r2l_ctrl, ui);
    }
    
    /* cleanup before quiting. */
    ui_cleanup(ui);
    r2l_destroy(r2l_ctrl);

    return 0;
}
