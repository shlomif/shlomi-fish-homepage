# tcp_dropper.pl
#
# This script drops incoming and outgoing traffic from t2.technion.ac.il
# with a probability of 0.5.
#
# Copyright (c) 2000-2001 James Morris <jmorris@intercode.com.au>
# This code is GPL.
#
# Modified by Shlomi Fish <shlomif@vipe.technion.ac.il>, 2001
# 
package ipq_example;
use strict;
$^W = 1;

use IPTables::IPv4::IPQueue qw(:constants);
use NetPacket::IP;
use NetPacket::TCP;

# Set the random number generator to a constant seed so we will expected
# results.
srand(24);

sub dump_payload
{
	my ($payload, $ip, $tcp);
	
	$payload = shift;

	#
	# IP Header
	#
	$ip = NetPacket::IP->decode($payload);
	
	print<<EOT;
[ IP Header ]
Version           : $ip->{ver}
Header Length     : $ip->{hlen}
Flags             : $ip->{flags}
Frag. Offset      : $ip->{foffset}
TOS               : $ip->{tos}
Length            : $ip->{len}
ID                : $ip->{id}
TTL               : $ip->{ttl}
Protocol          : $ip->{proto}
Checksum          : $ip->{cksum}
Source IP         : $ip->{src_ip}
Destination IP    : $ip->{dest_ip}
Options           : $ip->{options}

EOT

    $tcp = NetPacket::TCP->decode(NetPacket::IP::ip_strip($payload));

    print <<EOT;
[ TCP Header ]
Source Port               : $tcp->{src_port}
Dest   Port               : $tcp->{dest_port}

EOT

    my $verdict;

    # Drop all packets to or from the host "t2.technion.ac.il"

    my $t2_ip = "132.68.7.4";

    $verdict = ( ($ip->{src_ip} eq $t2_ip) || 
                 ($ip->{dest_ip} eq $t2_ip) ); 
    
    if ($verdict)
    {
        # Generate a random number between 0 and 1
        my $prob_value = rand(1); 
        # Drop the packet in a probability of 0.5
        $verdict = ($prob_value < 0.5); 
    }

    return $verdict;
}

sub dump_meta
{
	my $msg = shift;

	print <<EOT;
[ Metadata ]
Packet ID         : @{[ $msg->packet_id() ]}
Mark              : @{[ $msg->mark() ]}
Timestamp (sec)   : @{[ $msg->timestamp_sec() ]}
Timestamp (usec)  : @{[ $msg->timestamp_usec() ]}
Hook              : @{[ $msg->hook() ]}
In Device         : @{[ $msg->indev_name() ]}
Out Device        : @{[ $msg->outdev_name() ]}
HW Protocol       : @{[ $msg->hw_protocol() ]}
HW Type           : @{[ $msg->hw_type() ]}
HW Address Length : @{[ $msg->hw_addrlen() ]}
HW Address        : @{[ unpack('H*', $msg->hw_addr()) ]}
Data Length       : @{[ $msg->data_len() ]}
EOT
}

sub main
{
	my $queue = new IPTables::IPv4::IPQueue(copy_mode => IPQ_COPY_PACKET,
	                                        copy_range => 2048)
		or die IPTables::IPv4::IPQueue->errstr;

	while (1) {
		my $msg = $queue->get_message()
			or die IPTables::IPv4::IPQueue->errstr;
	
		dump_meta($msg);
		my $verdict = dump_payload($msg->payload()) if $msg->data_len();
		$queue->set_verdict(
            $msg->packet_id, 
            ($verdict ? NF_DROP : NF_ACCEPT)
            );
	}
}

main();
