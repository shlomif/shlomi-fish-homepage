#!/usr/bin/perl -w

use strict;

use Gamla::TextStream::Buffer;
use Gamla::TextStream::File;
use Gamla::TextStream::BufRef;

#my $s = Gamla::TextStream::Buffer->new();
#my $s = Gamla::TextStream::File->new(\*STDOUT);
my $buffer = "Content-Type:text/html\n\n";
my $s = Gamla::TextStream::BufRef->new(\$buffer);

sub output_something3
{
    my $s = shift;

    $s->append("<h1>Text Header</h1>\n\n");
}

sub output_something1
{
    my $s = shift;

    $s->append("<html>\n");
    $s->append("<body bgcolor=\"#FFFFFF\">\n");

    output_something3($s);
}

sub output_something2
{
    my $s = shift;
    
    $s->append("Shlomi Fish Here\n");
    $s->append("</body>\n");
    $s->append("</html>\n");

    return 0;
}

output_something1($s);
output_something2($s);

print $buffer;


#my $text = $s->get_buffer();

#undef($s);

#print $text;
