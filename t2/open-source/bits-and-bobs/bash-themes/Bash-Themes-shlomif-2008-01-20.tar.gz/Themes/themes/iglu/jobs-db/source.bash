load_common mymake
load_common completion

base="$HOME/progs/perl/www/Gamla/Mini-Reporter"
trunk="$base/berlios/trunk/iglu/www"
this="$trunk"

cd $this

