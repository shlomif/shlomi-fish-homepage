# Arad::Types::Char - an implementation of a date SQL data type. Currently,
# only ISO-style dates ("YYYY-MM-DD") are supported
#
# This is the most complex data type I had to implement, and there are quite
# some many nuances to this code. In any case: enjoy!
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)


package Arad::Types::Date;

use Arad::Types::Base;

@ISA = qw(Arad::Types::Base);

use strict;

sub initialize
{
    my $self = shift;

    $self->{'type'} = 'date';
}

{
    my @months_lengths = (0, 31, 28, 31, 30,
                            31, 30, 31, 31,
                            30, 31, 30, 31);

    # This function gets the number of days in a month of the Gregorian
    # Calendar. Since the length of February varries from year to year,
    # the year is inputted as a first parameter.
    sub gregorian_get_days_in_month
    {
        my $year = shift;
        my $month = shift;

        my $ret = $months_lengths[$month];

        if ($month == 2)
        {
            if ($year % 4 == 0)
            {
                $ret++;
            }
            if ($year % 100 == 0)
            {
                $ret--;
            }
            if ($year % 400 == 0)
            {
                $ret++;
            }
        }

        return $ret;
    }    
}

# Expands years given as 1, 2, 3 or 4 digits to a 4-digit precision
# year value.
sub expand_year
{
    my $entered = shift;
    my ($new_year);

    my @curr_time = localtime(time());
    my $curr_year = $curr_time[5]+1900;

    if ($entered < 0)
    {
        return $entered;
    }    
    elsif (length($entered) == 1)
    {
        $new_year = $curr_year - ($curr_year % 10) + $entered;
    }
    elsif (length($entered) == 2)
    {
        # In case somebody decides to travel back in time and still use this software... :-)
        if (($curr_year >= 0) && ($curr_year <= 99))
        {
            $new_year = $curr_year - ($curr_year % 100) + $entered;
        }
        else
        {
            # Create a window from $curr_year-50 to $curr_year+50 
            $new_year = ($curr_year-50 + (($entered - ($curr_year % 100) + 50) % 100));
        }
    }
    elsif (length($entered) == 3)
    {
        if (($curr_year >= 0) && ($curr_year <= 999))
        {
            $new_year = $curr_year - ($curr_year % 1000) + $entered;
        }
        else
        {
            # Create a window from $curr_year-500 to $curr_year+500 
            $new_year = ($curr_year-500 + (($entered - ($curr_year % 1000) + 500) % 1000));
        }
    }
    else
    {
        $new_year = $entered;
    }

    return $new_year;
}


# Right now we support only the ISO date type: YYYY-MM-DD

sub check_value
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value =~ /^-?\d+-\d{1,2}-\d{1,2}$/)
    {
        my @parts = split(/-/, $value);

        # In case the year is a negative one
        if ($value =~ /^-/)
        {
            @parts = ('-'.$parts[1], @parts[2..3]);
        }

        # Neither we nor the databases are Y10K compliant

        if (($parts[1] < 1) || ($parts[1] > 12))
        {
            return (1, "The month in \$F must be in the range 1-12.");
        }
        else
        {
            my $max_days = gregorian_get_days_in_month(expand_year($parts[0]), $parts[1]);
            if (($parts[2] < 1) || ($parts[2] > $max_days))
            {
                return (1, "The day of the month in \$F must be in the range 1-" . $max_days);
            }
            else
            {
                return (0, "");
            }                
        }
    }
    elsif (($value eq '') || ($value eq undef))
    {
        return (0, "");
    }
    else
    {
        return (1, "\$F is a date and must be in the form YYYY-MM-DD");
    }
}

sub to_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    my $new_value = '';

    if ($value =~ /^-?\d+-\d{1,2}-\d{1,2}$/)
    {
        my @parts = split(/-/, $value);

        # In case the year is a negative one.
        if ($value =~ /^-/)
        {
            @parts = ('-'.$parts[1], @parts[2..3]);
        }
        
        my ($new_year);

        $new_year = expand_year($parts[0]);

        $new_value = sprintf("%.4i-%.2i-%.2i%s", abs($new_year), $parts[1], $parts[2], (($new_year >= 0) ? "" : " BC"));

    }
    elsif (($value eq '') || ($value eq undef))
    {
        return (0, "null");
    }
    return (1, $new_value);
}

sub from_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value eq undef)
    {
        return '';
    }
    elsif ($value =~ /BC\s*$/)
    {
        $value =~ s!\s*BC\s*$!!;
        $value = "-" . $value;
    }

    return $value;
}

sub compare
{
    my $self = shift;

    my $type_params = shift;

    my $value1 = shift;
    my $value2 = shift;

    my @parts1 = split(/-/, $value1);
    if ($value1 =~ /^-/)
    {
        @parts1 = ('-'.$parts1[1], @parts1[2..3]);
    }
    
    my @parts2 = split(/-/, $value2);
    if ($value2 =~ /^-/)
    {
        @parts2 = ('-'.$parts2[1], @parts2[2..3]);
    }

    my ($y1,$m1,$d1) = @parts1;
    my ($y2,$m2,$d2) = @parts2;

    # Not the exact number of days since January 1, Year 0, but enough to
    # get a rough estimate of what follows what.
    my $days1 = ($y1*12+$m1)*31+$d1;
    my $days2 = ($y2*12+$m2)*31+$d2;
    
    return ($days1 <=> $days2);
}
