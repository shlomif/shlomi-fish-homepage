#!/usr/bin/perl

use strict;

use Data::Dumper;

#use Gamla::Web::PathMan::Pointer::WithMount;
use Gamla::Web::PathMan::Perl;

my $gamla_pathman_spec = 
{
    "Gamla" => 
    {
        "Gamla::TextStream::Out" =>
        {
            "document" => undef,
            "download" =>
            {
                "0.3.3" => undef,
            },
        },
        "Gamla::Web::PathMan" =>
        {
            "document" => undef,
            "download" => 
            {
                "0.3.3" => undef,
            },
        },
        "Arad::Types" =>
        {
            "document" => undef,
            "download" =>
            {
                "0.3.5" => undef,
            },
        },
    },
};


my $software_pathman_spec = 
{
    'JMikMod' => 
        {
            "README" => undef,
            "Versions" =>
            {
                "2.14" => undef,
            }
        },
    "Freecell Solver" =>
        {
            "README" => undef,
            "CHANGES" => undef,
            "Versions" =>
            {
                "0.4" => undef,
                "0.2" => undef,
            }
        },
};

my $shlomif_site_pathman_spec =
{
    "Links" => undef,
    "Personal" =>
    {
        "Resume" => undef,
        "About Myself" => undef,
    },
    "Humour" =>
    {
        "Collection" => undef,
        "The Enemy" =>
        {
            "Hebrew" =>
            {
                "Word 6.0" => undef,
                "HTML" => undef,
            },
            "English" =>
            {
                "Word 6.0" => undef,
                "HTML" => undef,
            },
        },
        "TOWTF" =>
        {
            "Part1" => undef,
            "Part2" => undef,
        },        
    },
    "Linux" =>
    {
        "OSS" => undef,
        "Haifux Lectures" =>
        {
            "PostgreSQL" => undef,
            "Lambda Calculus" => undef,
            "Newbies" =>
            {
                "Command Line" => undef,
            },
        },
    },
    "Math-Ventures" =>
    {
        "4d6 Minus Min" => undef,
        "Dodecahedron Volume" => undef,
        "Solidarian Disco Circle" => undef,
    },
};


sub fill_pathman_dir
{
    my $spec = shift;

    my $p = shift;
    my $dup;
    my $key;

    if (ref($spec) eq "HASH")
    {
        foreach $key (keys(%{$spec}))
        {
            if ($key eq ".")
            {
                $p->set_attribs($spec->{$key});
            }
            else
            {
                $p->mkdir_($key);
                $dup = $p->duplicate();
                $dup->cd_( [ $key ] );
                fill_pathman_dir($spec->{$key}, $dup);
            }
        }
    }
}


sub compile_pathman
{
    my $spec = shift;

    my $pathman = Gamla::Web::PathMan::Perl->new();

    my $p = $pathman->get_base_pointer();

    fill_pathman_dir($spec, $p);

    return $pathman;
}

my $gamla_pathman = compile_pathman($gamla_pathman_spec);
my $software_pathman = compile_pathman($software_pathman_spec);
my $shlomif_site_pathman = compile_pathman($shlomif_site_pathman_spec);

my $p = $software_pathman->get_base_pointer();

$p->mkdir_("MyGamla");
$p->cd_(["MyGamla"]);
$p->mount($gamla_pathman, ["Gamla"]);
$p->cd_([ "Gamla::TextStream::Out" ]);

my $p = $shlomif_site_pathman->get_base_pointer();
$p->cd_(["Linux", "OSS"]);
$p->mount($software_pathman, []);

sub disp
{
    print "dir: ", join("/", @{$p->pwd_()}), "\n";
    print "ls: ", join(",", @{$p->ls_()}), "\n";
    print "is_in_mounted: " , $p->{'is_in_mounted'}, "\n";
    print "\n";
}

$p->cd_(["OSS"]);
disp();
$p->mkdir_("Gradient-Fu");
disp();
$p->cd_(["Gradient-Fu"]);
$p->mkdir_("Versions");
disp();
$p->cd_([".."]);
disp();
$p->rm_("Gradient-Fu");
disp();
#$p->cd_([".."]);
$p->cd_(["..","..","Humour", "TOWTF"]);
disp();

if (0)
{
    my ($k, $v);
    while (($k,$v) = each(%{$p}))
    {
        print "$k: $v\n";
    }
}
my $d = Data::Dumper->new( [$shlomif_site_pathman] , ["\$shlomif_site_pathman"] );

my $dump_text =  $d->Dump();

open O, ">dump.pl";
print O $dump_text;
close(O);
