
#ifdef __cplusplus
extern "C"
{
#endif

extern Widget move_choice_dialog;
extern int move_choice;

extern void create_move_choice_dialog(Widget pb);

enum PATH_TYPE
{
    PATH_MATRIX,
    PATH_BEZIER,
};

extern enum PATH_TYPE type_of_path;
extern enum PATH_TYPE new_type_of_path;

#ifdef __cplusplus
};
#endif

