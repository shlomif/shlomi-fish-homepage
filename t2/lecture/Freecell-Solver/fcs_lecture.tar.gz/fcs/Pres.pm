package Pres;

use strict;

use Gamla::Object;
use Data::Dumper;

use vars qw(@ISA);

@ISA=qw(Gamla::Object);

sub initialize
{
    my $self = shift;

    $self->{'contents'} = shift;
    my $doc_id = shift;
    $self->{'doc_id'} = [ split(/\//, $doc_id) ];
    $self->{'doc_id_slash_terminated'} = (($doc_id =~ /\/$/) ? 1 : 0);

    return 0;
}

sub get_coords
{
    my $self = shift;
    if (!exists($self->{'coords'}))
    {
        my %locs;
        my $traverse;

        $traverse = 
        sub {
            my $coords = shift;
            my $branch = shift;
            my $path = shift;

            push @$path, $branch->{'url'};

            $locs{join("/", @$path[1..$#$path])} = [ @{$coords} ];
            if (exists ($branch->{'subs'}))
            {
                my $i;

                for($i=0;$i<scalar(@{$branch->{'subs'}});$i++)
                {
                    $traverse->(
                        [ @$coords, $i ],
                        $branch->{'subs'}->[$i],
                        [ @$path ],
                    );
                }
            }
        };

        $traverse->(
            [ ],
            $self->{'contents'},
            [ ],
        );

        if (0)
        {
            print "Content-Type: text/plain\n\n";
            my $d = Data::Dumper->new([\%locs], ["locs"]);
            print $d->Dump();
        }

        my $document_id = join("/", @{$self->{'doc_id'}});
        if (!exists($locs{$document_id}))
        {
            die "Pres::get_coords(): Could not find the document \"" . $document_id . "\".";
        }
        $self->{'coords'} = [ @{$locs{$document_id}} ];
    }
}

sub get_document_base_text
{
    my $self = shift;

    my $document_id = join("/", @{$self->{'doc_id'}});

    my $filename = "./src/" . $document_id;

    if (-f $filename)
    {
        my $text;
        local(*I);
        open I, ("<".$filename);
        $text = join("",<I>);
        close(I);
        return $text;
    }
    elsif ((-d $filename) && (-f $filename."/index.html"))
    {
        my $text;
        local(*I);
        open I, ("<".$filename."/index.html");
        $text = join("",<I>);
        close(I);
        return $text;
    }
    else 
    {
        die "Could not find the file \"" . $document_id . "\"";
    }
}

sub get_url_by_coords
{
    my $self = shift;

    my @coords = @{shift(@_)};

    my @url;
    my $b;
    my $i;

    $b = $self->{'contents'};

    for($i=0;$i<scalar(@coords);$i++)
    {
        $b = $b->{'subs'}->[$coords[$i]];
        push @url, $b->{'url'};
    }

    return \@url;
}


sub get_contents_url
{
    my $self = shift;

    return [];
}

sub get_next_url
{
    my $self = shift;

    my @coords = @{$self->{'coords'}};

    my @branches = ($self->{'contents'});

    my @dest_coords;

    my $i;

    for($i=0;$i<scalar(@coords);$i++)
    {
        $branches[$i+1] = $branches[$i]->{'subs'}->[$coords[$i]];
    }

    if (exists($branches[$i]->{'subs'}))
    {
        @dest_coords = (@coords,0);
    }
    else
    {
        for($i--;$i>=0;$i--)
        {
            if (scalar(@{$branches[$i]->{'subs'}}) > ($coords[$i]+1))
            {
                @dest_coords = (@coords[0 .. ($i-1)], $coords[$i]+1);
                last;
            }
        }
        if ($i == -1)
        {
            return undef;
        }
    }

    return $self->get_url_by_coords(\@dest_coords);
}


sub get_prev_url
{
    my $self = shift;

    my @coords = @{$self->{'coords'}};

    if ($coords[$#coords] > 0)
    {
        return $self->get_url_by_coords(
            [ 
                @coords[0..($#coords-1)],
                $coords[$#coords]-1
            ]
            );
    }
    elsif (scalar(@coords) > 0)
    {
        return $self->get_url_by_coords(
            [ @coords[0 .. ($#coords-1)] ]
            );
    }
    else
    {
        return undef;
    }
}

sub get_up_url
{
    my $self = shift;

    my @coords = @{$self->{'coords'}};

    if (scalar(@coords) == 0)
    {
        return undef;
    }
    else
    {
        return $self->get_url_by_coords(
            [ @coords[0..($#coords-1)] ]
            );
    }    
}

sub get_relative_url
{
    my @this_url = @{shift(@_)};
    my @other_url = @{shift(@_)};
    my $slash_terminated = shift;
    
    while(
        scalar(@this_url) &&
        scalar(@other_url) &&
        ($this_url[0] eq $other_url[0])
    )
    {
        shift(@this_url);
        shift(@other_url);
    }

    if ($slash_terminated)
    {
        return join("/", (map { ".." } @this_url), @other_url); 
    }
    else
    {
        return ("./" . join("/", (map { ".." } @this_url[1..$#this_url]), @other_url)); 
    }
}

sub get_control_text
{
    my $self = shift;

    my $spec = shift;

    my $text = "";

    my @this_url = @{$self->{'doc_id'}};

    my $other_url = $spec->{'url'}->($self);

    if (defined($other_url))
    {
    
        $text .= "<a href=\"" . 
            get_relative_url(
                [ @this_url ], 
                [@$other_url], 
                $self->{'doc_id_slash_terminated'}
            ) .
            "\" class=\"fcs_nav\">";
    
        $text .= $spec->{'caption'};

        $text .= "</a>";
    }
    else
    {
        $text .= "<b>" . $spec->{'caption'} . "</b>";
    }

    return $text;
}

sub get_navigation_bar
{
    my $self = shift;

    if (!exists($self->{'navigation_bar'}))
    {
        # Render the Navigation Bar
        my $text = "";
        my @controls;

        $text .= "<table>\n";
        $text .= "<tr>\n";
        $text .= "<td>\n";

        push @controls, ($self->get_control_text(
            {
                'url' => \&get_contents_url,
                'caption' => "Contents",
            },
        ));

        push @controls, ($self->get_control_text(
            {
                'url' => \&get_up_url,
                'caption' => "Up",
            },
        ));

        push @controls, ($self->get_control_text(
            {
                'url' => \&get_prev_url,
                'caption' => "Previous",
            },
        ));

        push @controls, ($self->get_control_text(
            {
                'url' => \&get_next_url,
                'caption' => "Next",
            },
        ));
        

        $text .= join("</td>\n<td>\n", @controls);

        $text .= "</td>\n";
        $text .= "</tr>\n";
        $text .= "</table>\n";
        $text .= "<br><br>";

        $self->{'navigation_bar'} = $text;
    }

    return $self->{'navigation_bar'};
}

sub get_header
{
    my $self = shift;

    my $text = "";
    my $branch;

    my @coords = @{$self->{'coords'}};

    $branch = $self->{'contents'};
    for(my $i=0;$i<scalar(@coords);$i++)
    {
        $branch = $branch->{'subs'}->[$coords[$i]];
    }

    $text .= "<html>\n";
    $text .= "<head>\n";
    $text .= "<title>" . $branch->{'title'} . "</title>\n";
    $text .= "</head>\n";
    $text .= "<body bgcolor=\"#FFFFFF\">\n";
    $text .= $self->get_navigation_bar();
    $text .= "<h1 class=\"fcs\">" . $branch->{'title'} . "</h1>";

    return $text;
}

sub get_footer
{
    my $self = shift;

    my $text = "";

    $text .= "</body>\n";
    $text .= "</html>\n";

    return $text;
}

sub get_contents_helper
{
    my $self = shift;

    my $branch = shift;
    my $url = shift;

    my $text = "";
    $text .= "<a href=\"" .
        get_relative_url([ @{$self->{'doc_id'}} ], [@$url]) .
        "\" class=\"fcs_contents\">";
    $text .= $branch->{'title'};
    $text .= "</a><br>\n";
    if (exists($branch->{'subs'}))
    {
        $text .= "<ul>\n";
        foreach my $sb (@{$branch->{'subs'}})
        {
            $text .= $self->get_contents_helper($sb, [@$url, $sb->{'url'}]);
        }
        $text .= "</ul>\n";
    }

    return $text;
}

sub get_contents
{
    my $self = shift;

    my $text = "";

    my @coords = @{$self->{'coords'}};
    my @url;

    my $b = $self->{'contents'};

    my $i;

    for($i=0;$i<scalar(@coords);$i++)
    {
        $b = $b->{'subs'}->[$coords[$i]];
        push @url, $b->{'url'};
    }
    
    if (exists($b->{'subs'}))
    {
        for($i=0;$i<scalar(@{$b->{'subs'}});$i++)
        {
            $text .= $self->get_contents_helper(
                $b->{'subs'}->[$i], 
                [@url, $b->{'subs'}->[$i]->{'url'}]
                );
        }
    }

    return $text;
}

sub process_document_text
{
    my $self = shift;

    my $text = shift;

    my $header = $self->get_header();
    my $footer = $self->get_footer();
    my $contents = $self->get_contents();

    $text =~ s/<!-+ *begin_header *-+>[\x00-\xFF]*?<!-+ *end_header *-+>/$header/;
    $text =~ s/<!-+ *begin_footer *-+>[\x00-\xFF]*?<!-+ *end_footer *-+>/$footer/;
    $text =~ s/<!-+ *begin_contents *-+>[\x00-\xFF]*?<!-+ *end_contents *-+>/$contents/;


    return $text;
}

sub render_text
{
    my $self = shift;

    my $base_text = $self->get_document_base_text();
    my $text = $self->process_document_text($base_text);

    return $text;
}

sub render
{
    my $self = shift;
    eval {
        $self->get_coords();
        my $text = $self->render_text();
        print "Content-Type: text/html\n\n";
        print $text;
    };

    if ($@)
    {
        print "Content-Type: text/plain\n\n";
        print "Error!\n\n";
        print $@;
    }
}
