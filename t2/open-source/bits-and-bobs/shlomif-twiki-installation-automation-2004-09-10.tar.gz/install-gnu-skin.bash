source twiki-install-common.bash

(cd "$dest_dir" &&
    (
        unzip "$downloads_base_dir"/addons/WebMenu-1.1.zip
        tar -xzvf "$downloads_base_dir"/addons/GnuSkin-1.2.tgz
    )
)

adjust_permissions

