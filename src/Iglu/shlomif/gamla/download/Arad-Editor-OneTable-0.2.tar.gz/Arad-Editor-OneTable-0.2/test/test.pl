#!/usr/bin/perl

use MyTable;
use MyTable::SPEC;
use MyTable::SPEC_emp2;

use Arad::Types;
use Arad::SQL::DBI;
use Arad::SQL::Postgres;
use Arad::UI::Text;
use Arad::UI::Tk;
use Arad::Templates::MyTable;

#$sql = new Arad::SQL::Postgres;
$sql = new Arad::SQL::DBI;

$types = Arad::Types->new($sql);

$sql->set_types_manager($types);

$ui = new Arad::UI::Tk;

if (0)
{
	$sql->connect_db({ 'database' => 'arad'});
}
elsif(1)
{
	$sql->connect_db(
                 {
                     'dsn' => "dbi:Pg:dbname=arad",
                     'init' => "SET DateStyle = 'ISO'"
                 }
                 );

}

$spec = MyTable::SPEC::get_spec();
#$table = MyTable->new($types, $sql, $ui);
$table = Arad::Templates::MyTable->new($types, $sql, $ui, $spec);

#$table->load_record_by_primary_key({ 'employee_id' => 1});

if ($ARGV[0] eq '--no-readline')
{
    $options = 'no_readline';
}
else
{
    $options = '';
}

$table->create_dialog($options);

$sql->destroy_();


