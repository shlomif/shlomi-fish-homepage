{
    my @links =
    (
    {
        'l' => "Personal/AboutMe",
        'd' => "About Myself",
    },
    {
        'l' => "Personal/Resume",
        'd' => "C.V.",
    },    
    {
        'l' => "Humour",
        'd' => "Humour Collection",
    },
    {
        'l' => "HaifuxLectures",
        'd' => "Lectures to the Linux Club",
    },
    {
        'l' => "Links",
        'd' => "Links",
    },
    {
        'l' => "MathVentures",
        'd' => "MathVentures",
    },
    );

    sub get_links_bar
    {
        my $view = shift;

        my $ptr = $view->get_view_pointer();
        $ptr->cd("/Homepages/Shlomif");
        $ptr->set_defualt_prefix(".");

        my $ret = "";

        foreach my $link (@links)
        {
            my $link_ptr = $ptr->duplicate();
            $link_ptr->cd($link->{'l'});
            if ($view->get_base_directory() eq $link_ptr->pwd())
            {
                $ret .= "<b>" . $link->{'d'} . "</b>";
            }
            else
            {
                $ret .= "<a href=\"" . $link_ptr->get_url() . "\">" .
                    $link->{'d'} . "</a>";
            }
            $ret .= "<br>\n";
        }

        return $ret;
    }
} 

