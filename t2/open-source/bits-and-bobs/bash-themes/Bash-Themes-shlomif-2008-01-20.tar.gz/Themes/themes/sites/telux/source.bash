load_common completion

base="$HOME/Docs/IGLU/Telux"
site="$base/site/trunk/wml"
ann="$base/announcements"

this="$site"
cd $this

