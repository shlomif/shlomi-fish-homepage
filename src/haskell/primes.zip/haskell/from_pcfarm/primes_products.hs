
import Array
import FastSort

products_filtered :: Int -> Int -> [Int] -> [Int]
products_filtered depth bound list = (remove_duplicates (msort (products depth))) where

    products :: Int -> [Int]
    products 1 = (filter (\x -> (x <= bound)) list)
    products mydepth = 
        (filter (\x -> (x <= bound)) 
            [ i*m | i <- list, m <- (products (mydepth-1)) ]
        )

    remove_duplicates :: [Int] -> [Int]
    remove_duplicates (a:[]) = [a]
    remove_duplicates (a:b:as) | (a == b) = remove_duplicates(b:as)
                               | otherwise = a:remove_duplicates(b:as)

        


test how_much = (print products) where 
    
    initial_array :: Array Int Bool
    initial_array = (array (1,how_much) [(i,True) | i <- [1 .. how_much]])

    convert_list :: [(Int,Bool)]
    convert_list = [(i,False) | i <- products_list]

    products :: [Int]
    products = (products_filtered mydepth how_much (1:primes_list))

    products_list :: [Int]
    products_list = (myfilter primes_list products)

    myfilter :: [Int] -> [Int] -> [Int]
    myfilter [] list = list
    myfilter (a:as) (b:bs) | (a==b) = (myfilter as bs)
                           | (a>b) = b:(myfilter (a:as) bs)
                           | (a<b) = (myfilter as (b:bs))

    primes_list :: [Int]
    primes_list = (primes mybound)

    mybound :: Int
    mybound = ceiling(sqrt(fromIntegral(how_much)))

    mydepth :: Int
    mydepth = ceiling(log(fromIntegral(how_much))/log(fromIntegral(2)))










primes_map :: Int -> (Array Int Bool)
primes_map how_much = (initial_array // convert_list) where
    
    initial_array :: Array Int Bool
    initial_array = (array (1,how_much) [(i,True) | i <- [1 .. how_much]])

    convert_list :: [(Int,Bool)]
    convert_list = [(i,False) | i <- products_list]

    products :: [Int]
    products = (products_filtered mydepth how_much (1:primes_list))

    products_list :: [Int]
    products_list = (myfilter primes_list products)

    myfilter :: [Int] -> [Int] -> [Int]
    myfilter [] list = list
    myfilter (a:as) (b:bs) | (a==b) = (myfilter as bs)
                           | (a>b) = b:(myfilter (a:as) bs)
                           | (a<b) = (myfilter as (b:bs))

    primes_list :: [Int]
    primes_list = (primes mybound)

    mybound :: Int
    mybound = ceiling(sqrt(fromIntegral(how_much)))

    mydepth :: Int
    mydepth = ceiling(log(fromIntegral(how_much))/log(fromIntegral(2)))

hello = print 5

primes :: Int -> [Int]
primes 2 = [2]
primes how_much = (filter (mymap!) (tail (indices mymap))) where
    mymap = (primes_map how_much)

