# Arad::SQL::Base - The base class for the SQL database drivers.
#
# Contains code for handling sequences of records. Right now only database
# that support the LIMIT clause are supported.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)

package Arad::SQL::Base;

use strict;

sub initialize
{
    my $self = shift;
}

sub new
{
    my $class = shift(@_);
    my $self = {};
    bless $self, $class;

    $self->initialize(@_);

    return $self;
}

# The SQL Driver and the type manager are a bi-pole. One needs to call
# $sql_driver->destroy_(); at the end of the SQL driver's use, so
# they'll both be deallocated.

sub set_types_manager
{
    my $self = shift;

    my $types = shift;

    $self->{'types'} = $types;
}

sub destroy_
{
    my $self = shift;

    $self->set_types_manager(undef);
}

# $sequence = $sql_driver->create_sequence($table_name, \@fields, $where_clause, $order_by_clause)
#
# Create a sequence that retrieves the fields $fields[0]->{'name'}, $fields[1]->{'name'}, etc.
# from table $table_name, using the filter $where_clause, ordered by $order_by_clause.
#
# As the usual convention, $where_clause should not include the "WHERE" and $order_by_clause
# should not include the "ORDER BY".
#
# create_sequence() returns the sequence handle.
#
# A @fields item is a reference to a hash that contains the following entries:
#
# 'name' => The SQL name of the field
# 'type' => The type of the field
# 'type_params' => The parameters for the type of the field. (unused for most data types).

sub create_sequence
{
    my $self = shift;
    my $table_name = shift;
    my $fields = shift;
    my $where_clause = shift;
    my $order_by_clause = shift;

    my (%seq);

    if ($self->{'no_limit'})
    {
        warn("Cannot create sequences for database that do not support the LIMIT clause");
        return undef;
    }

    $seq{'table'} = $table_name;
    $seq{'fields'} = [ @{$fields} ];
    $seq{'where'} = $where_clause;
    $seq{'order'} = $order_by_clause;

    return (\%seq);
}

# $row = $sql_driver->get_sequence_at_pos($seq, $pos);
# @values = @{$row};
#
# Returns the values of sequence at position $pos. Make sure that $pos is
# in the range 0 - (get_sequence_num_records()-1) before calling this
# function.
sub get_sequence_at_pos
{
    my $self = shift;
    my $seq = shift;
    my $pos = shift;

    $pos = abs(int($pos));

    my ($query_str, $query, @row);

    $query_str =
        "SELECT " . join(",", (map { $_->{'name'}; } @{$seq->{'fields'}})) .
        " FROM " . $seq->{'table'} .
        ($seq->{'where'} ? (" WHERE " . $seq->{'where'}) : "") .
        ($seq->{'order'} ? (" ORDER BY " . $seq->{'order'}) : "") .
        " LIMIT 1," . $pos;
    
    $query = $self->perform_select_query($query_str);

    @row = $self->get_query_row($query);

    $self->end_query($query);

    return [ @row ];
}

# $num_records = $sql_driver->get_sequence_num_records($seq)
#
# Gets the number of records in the sequence $seq. Valid record indexes are in the
# range 0 - ($num_records - 1).
sub get_sequence_num_records
{
    my $self = shift;
    my $seq = shift;

    my ($query_str, $query, @row);

    $query_str =
        "SELECT count(*)" .
        " FROM " . $seq->{'table'} .
        ($seq->{'where'} ? (" WHERE " . $seq->{'where'}) : "");

    $query = $self->perform_select_query($query_str);

    @row = $self->get_query_row($query);

    $self->end_query($query);

    return $row[0];
}

# $pos = $sql_driver->get_sequence_pos_from_values($seq, \@values, $prev_pos);
#
# Finds the record whose values in the sequence are @values.
# $seq - the sequence
# @values - an array of values in the same order as the @fields parameters
#           to the create_sequence() function.
# $prev_pos - the last position this record was at. If $prev_pos is less than 0
#             it is ignored.
#
# Returns the new position in the range 0 - (get_sequence_num_record() - 1) or
# -1 if the record could not be found.
sub get_sequence_pos_from_values
{
    my $self = shift;
    my $seq = shift;
    my $values = shift;
    my $prev_pos = shift;

    if ($prev_pos eq undef)
    {
        $prev_pos = -1;
    }

    my $types = $self->{'types'};

    my ($query_str, $query, @row, $a, $f, $plain_value, $ret);

    $ret = -1;

    $query_str =
        "SELECT " . join(",", (map { $_->{'name'}; } @{$seq->{'fields'}})) .
        " FROM " . $seq->{'table'} .
        ($seq->{'where'} ? (" WHERE " . $seq->{'where'}) : "") .
        ($seq->{'order'} ? (" ORDER BY " . $seq->{'order'}) : "");

    if ($prev_pos >= 0)
    {
        # Try to look for it in the records near its previous position
        $query = $self->perform_select_query($query_str . " LIMIT 3," . (($prev_pos == 0) ? $prev_pos : ($prev_pos-1)));

        for($a=(($prev_pos == 0) ? 0 : -1);$a<=1;$a++)
        {
            if (@row = $self->get_query_row($query))
            {
                for($f=0;$f<scalar(@{$seq->{'fields'}});$f++)
                {
                    $plain_value = $types->convert_from_sql(
                                                      $seq->{'fields'}->[$f]->{'type'} ,
                                                      $seq->{'fields'}->[$f]->{'type_params'} ,
                                                      $row[$f]);

                    if ($types->compare_values(
                                               $seq->{'fields'}->[$f]->{'type'} ,
                                               $seq->{'fields'}->[$f]->{'type_params'} ,
                                               $plain_value,
                                               $values->[$f]) != 0)
                    {
                        last;
                    }
                }
                if ($f == scalar(@{$seq->{'fields'}}))
                {
                    $ret = $prev_pos + $a;
                }
            }
            else
            {
                last;
            }
            if ($ret != -1)
            {
                last;
            }
        }
        $self->end_query($query);
        if ($ret != -1)
        {
            return $ret;
        }
    }

    # Couldn't find it in the nearby records so do a linear scan through the
    # entire table.

    $query = $self->perform_select_query($query_str);

    for($a=0;;$a++)
    {
        if (@row = $self->get_query_row($query))
        {
            for($f=0;$f<scalar(@{$seq->{'fields'}});$f++)
            {
                $plain_value = $types->convert_from_sql(
                                                  $seq->{'fields'}->[$f]->{'type'} ,
                                                  $seq->{'fields'}->[$f]->{'type_params'} ,
                                                  $row[$f]);

                if ($types->compare_values(
                                           $seq->{'fields'}->[$f]->{'type'} ,
                                           $seq->{'fields'}->[$f]->{'type_params'} ,
                                           $plain_value,
                                           $values->[$f]) != 0)
                {
                    last;
                }
            }
            if ($f == scalar(@{$seq->{'fields'}}))
            {
                $ret = $a;
            }
        }
        else
        {
            last;
        }
        if ($ret != -1)
        {
            last;
        }
    }
    $self->end_query($query);

    return $ret;    
}
# Returns -1 if a record could not be found.

sub refresh_sequence
{
    my $self = shift;
    my $seq = shift;

    # Since we use LIMIT 1,$offset - there's no need to do anything

    return 0;
}

sub end_sequence
{
    my $self = shift;
    my $seq = shift;

    %{$seq} = ();
}

1;
