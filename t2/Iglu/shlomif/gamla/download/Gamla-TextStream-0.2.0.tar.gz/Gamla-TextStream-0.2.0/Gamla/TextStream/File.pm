package Gamla::TextStream::File;

use strict;

use Gamla::TextStream;

use vars qw(@ISA);

@ISA=qw(Gamla::TextStream);

my $class_name = "Gamla::TextStream::File";

sub initialize
{
    my $self = shift;

    my $glob = shift;

    my $func_name = "initialize";
    
    $self->{'to'} = $glob;
    
    return ([[0,$class_name."::".$func_name."()", ""]], [@_]);
}

sub append
{
    my $self = shift;

    my $text = shift;

    print {*{$self->{'to'}}} $text;
}

sub flush
{
    my $self = shift;

    &flush(*{$self->{'to'}});
}
