load_common mymake

this="$HOME/Docs/Svn/Docs/Rindolf/Spec"

cd $this

