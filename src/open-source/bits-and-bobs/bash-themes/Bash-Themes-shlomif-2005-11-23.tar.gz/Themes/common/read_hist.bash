read_hist()
{
    theme="$1"
    history -r "$HOME/.bash_themes/themes/$theme/history"
}

