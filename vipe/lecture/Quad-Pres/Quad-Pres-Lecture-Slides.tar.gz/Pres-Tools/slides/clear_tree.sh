#!/bin/bash
rm -fr /var/www/html/shlomi/perl-mongers/lecture/Quad-Pres/slides

