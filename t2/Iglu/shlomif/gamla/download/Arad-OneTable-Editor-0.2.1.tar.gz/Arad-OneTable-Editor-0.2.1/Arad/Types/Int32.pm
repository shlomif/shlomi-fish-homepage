# Arad::Types::Int32 - a 32-bit signed integer SQL data type.
#
# This is the most complex data type I had to implement, and there are quite
# some many nuances to this code. In any case: enjoy!
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)


package Arad::Types::Int32;

use Arad::Types::Base;

@ISA = qw(Arad::Types::Base);

use strict;

my $min_value = -2147483648;
my $max_value = 2147483647;

sub initialize
{
    my $self = shift;

    $self->{'type'} = 'int32';
}

sub check_value
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if (($value eq undef) || ($value eq ''))
    {
        return (0, "")
    }    
    elsif ($value !~ /^[-+]?\d+$/)
    {
        return (1, "\$F must be an integer.");
    }
    elsif (($value > $max_value) || ($value < $min_value))
    {
        return (1, ("\$F must be in the range " . $min_value . " - " . $max_value . "."));
    }
    else
    {
        return (0, "");
    }
}

sub to_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if (($value eq undef) || ($value eq ''))
    {
        return (0, "null");
    }
    
    return (0, $value);
}

sub from_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if ($value eq undef)
    {
        return '';
    }
    
    return $value;
}

sub compare
{
    my $self = shift;

    my $type_params = shift;

    my $value1 = shift;
    my $value2 = shift;

    return ($value1 <=> $value2);
}

