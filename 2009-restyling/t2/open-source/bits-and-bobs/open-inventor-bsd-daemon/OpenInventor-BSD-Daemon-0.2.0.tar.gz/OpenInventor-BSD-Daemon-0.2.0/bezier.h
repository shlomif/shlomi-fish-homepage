#ifdef __cplusplus
extern "C"
{
#endif

struct point_struct
{
    float x;
    float y;
    float z;
    float x_ang, y_ang, z_ang;
};

typedef struct point_struct point_t;

extern point_t * path;
extern int path_len;

extern Widget path_dialog;

extern void create_path_dialog(Widget pb);

#ifdef __cplusplus
};
#endif
