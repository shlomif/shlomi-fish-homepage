package Shlomif::R2L::Poller::File;

use strict;

use vars qw(@ISA);

use Shlomif::R2L::Poller;

# Inherit Shlomif::R2L::Poller
@ISA = qw(Shlomif::R2L::Poller);

my $default_filename = $ENV{'HOME'} . "/.r2l";

sub initialize
{
    my $self = shift;

    my $filename = shift || $default_filename;

    $self->{'filename'} = $filename;

    $self->poll();
}

sub get_filename
{
    my $self = shift;

    return $self->{'filename'};
}

sub proto_poll
{
    my $self = shift;

    my $filename = $self->get_filename();
    
    my $test = (-e $filename);

    return ($test ? 1 : 0); # So it will not be undef.
}

sub proto_enable
{
    my $self = shift;

    # Update the status from the hard-disk
    $self->poll();

    if (! $self->get_status())
    {
        # Touch the file;
        open O, (">".$self->get_filename() );
        close O;
    }
    
    return 1;
}

sub proto_disable
{
    my $self = shift;

    # Update the status from the hard-disk

    $self->poll();

    if ($self->get_status())
    {
        unlink $self->get_filename();
    }

    return 1;
}

1;

