#include <unistd.h>
#include <stdlib.h>

#include <list>

#include <Inventor/Xt/SoXt.h>
#include <Inventor/Xt/viewers/SoXtExaminerViewer.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoScale.h>
#include <Inventor/nodes/SoBaseColor.h>
#include <Inventor/nodes/SoSphere.h>
#include <Inventor/nodes/SoCone.h>
#include <Inventor/nodes/SoCylinder.h>
#include <Inventor/nodes/SoTranslation.h>
#include <Inventor/nodes/SoRotation.h>
#include <Inventor/nodes/SoEventCallback.h>
#include <Inventor/events/SoKeyboardEvent.h>
#include <Inventor/actions/SoWriteAction.h>
#include <Inventor/nodes/SoPerspectiveCamera.h>
#include <Inventor/nodes/SoDirectionalLight.h>
#include <Inventor/nodes/SoSelection.h>
#include <Inventor/manips/SoHandleBoxManip.h>
#include <Inventor/manips/SoTrackballManip.h>
#include <Inventor/nodes/SoTransformSeparator.h>
#include <Inventor/draggers/SoRotateCylindricalDragger.h>
#include <Inventor/draggers/SoRotateDiscDragger.h>
#include <Inventor/draggers/SoTranslate1Dragger.h>
#include <Inventor/engines/SoCompose.h>
#include <Inventor/SbLinear.h>
#include <Inventor/sensors/SoTimerSensor.h>


#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/ScrollBar.h>

#include "bezier.h"
#include "polynom.h"
#include "move_choice.h"

SbMatrix start;
SbMatrix end;
float factor;

struct path_polys_struct
{
    polynom_t * x, *y, *z, *x_ang, *y_ang, *z_ang;
};

path_polys_struct the_path_polys;


namespace Dotan_and_Shlomi {
    namespace Inventor {
        namespace Daemon {
            
            enum OurDirection
            { 
                LEFT = 0 ,
                RIGHT = 1,
            };

            // This is a small function to prevent us from losing
            // our mind.
            inline SoScale * createScale(SoGroup * group, double x, double y, double z)
            {
                SoScale * ret = new SoScale; 
                ret->scaleFactor.setValue(x,y,z);
                group->addChild(ret);

                return ret;
            }

            inline SoSeparator * createSeparator(SoGroup * base_group)
            {
                SoSeparator * ret = new SoSeparator();
                base_group->addChild(ret);
                
                return ret;
            }

            inline SoTranslation * createTranslation(SoGroup * base_group, double x, double y, double z)
            {
                SoTranslation * ret = new SoTranslation();
                base_group->addChild(ret);
                ret->translation.setValue(x,y,z);

                return ret;
                
            }

            inline double deg2rad(int degrees)
            {
                return ((M_PI/180)*degrees);    
            }

            inline SoRotation * createRotation(SoGroup * base_group, double x, double y, double z, double rad)
            {
                SoRotation * ret = new SoRotation();
                base_group->addChild(ret);
                ret->rotation.setValue(SbVec3f(x,y,z), rad);

                return ret;
            }

            inline SoRotation * createRotation(SoGroup * base_group, double x, double y, double z, int degrees)
            {
                return createRotation(base_group, x, y, z, deg2rad(degrees));
            }
            

            inline SoCylinder * createCylinder(SoGroup * base_group, double radius, double height)
            {
                SoCylinder * ret = new SoCylinder;
                base_group->addChild(ret);
                ret->parts.setValue(SoCylinder::ALL);
                ret->radius.setValue(radius);
                ret->height.setValue(height);
                return ret;
            }

            inline SoCone * createCone(SoGroup * base_group, double radius, double height)
            {
                SoCone * ret = new SoCone;
                base_group->addChild(ret);
                ret->parts.setValue(SoCone::ALL);
                ret->bottomRadius.setValue(radius);
                ret->height.setValue(height);
                return ret;
            }
            
            inline SoSphere * createSphere(SoGroup * group, double radius = 1)
            {
                SoSphere * ret = new SoSphere;
                group->addChild(ret);
                ret->radius.setValue(radius);
                
                return ret;        
            }

            inline SoBaseColor * createBaseColor(SoGroup * group, double r, double g, double b)
            {
                SoBaseColor * ret = new SoBaseColor;
                ret->rgb.setValue(r,g,b);
                group->addChild(ret);

                return ret;
            }

            inline void normalize_axes_around_y(float & x, float & y, float & z, float & angle)
            {
                if (angle == 0.0)
                {
                    x = 0;
                    y = 1;
                    z = 0;
                }                
                else if ((y > -1.0000000001) && (y < -0.9999999))
                {
                    y *= -1;
                    angle *= -1;
                }
                else if (y == 0)
                {
                    if (z == 1)
                    {
                        x = 0;
                        y = 1;
                        z = 0;
                        angle = M_PI/2;
                    }
                    else if (z == -1)
                    {
                        x = 0;
                        y = 1;
                        z = 0;
                        angle = -M_PI/2;
                    }
                }
                while (angle > M_PI)
                {
                    angle -= M_PI*2;
                }
                while (angle < -M_PI)
                {
                    angle += M_PI*2;
                }                
            }
            
            template<class T>
            inline void make_cyl_dragger_in_between(T * dragger, float min_angle, float max_angle)
            {
                SbVec3f axis;
                float angle, x, y, z;
                dragger->rotation.getValue(axis, angle);
                axis.getValue(x,y,z);

#ifdef DEBUG
                printf("Before: x=%f y=%f z=%f angle=%f\n", x, y, z, angle);
#endif
                
                normalize_axes_around_y(x,y,z,angle);

#ifdef DEBUG
                printf("After: x=%f y=%f z=%f angle=%f\n", x, y, z, angle);
#endif

                if (angle > min_angle + 0.0001)
                {
                    dragger->rotation.setValue(SbVec3f(0, 1, 0), min_angle);
                }
                // MAX_ANGLE minus epsilon
                else if (angle < max_angle-0.0001)
                {
                    dragger->rotation.setValue(SbVec3f(0,1,0), max_angle);
                }
                
            };
            

            class GroupedComponent
            {
                public:
                struct rot_dragger_callback
                {
                    GroupedComponent * this_ptr;
                    float min;
                    float max;
                };
                
                rot_dragger_callback createRotDraggerCallback(float max, float min)
                {
                    rot_dragger_callback ret;
                    ret.this_ptr = this;
                    ret.max = max;
                    ret.min = min;
                    return ret;
                }

                SoRotateCylindricalDragger * createRotateCylindricalDragger(rot_dragger_callback * callback, SoGroup * group, float max, float min)
                {
                    *callback = createRotDraggerCallback(max,min);
                    SoRotateCylindricalDragger * ret = new SoRotateCylindricalDragger;
                    ret->addValueChangedCallback(rot_dragger_value_changed_callback, callback);
                    group->addChild(ret);

                    return ret;
                }

                public:
                    std::list<GroupedComponent *> children;
                    SoSeparator * group;
                public:
                    GroupedComponent(SoGroup * base_group);
                    GroupedComponent(GroupedComponent * parent);
                    virtual void reset(void);

                    void propagate_reset(void);

                    static void rot_dragger_value_changed_callback(void * callback, SoDragger * dragger);
                    void rotDraggerValueChanged(SoRotateCylindricalDragger * dragger, float max, float min);
                    void initialize_from_group(SoGroup * base_group) { group = createSeparator(base_group); }
            };

            void GroupedComponent::rot_dragger_value_changed_callback(void * void_callback, SoDragger * dragger)
            {
                rot_dragger_callback * callback = (rot_dragger_callback *)void_callback;
                callback->this_ptr->rotDraggerValueChanged((SoRotateCylindricalDragger *)dragger, callback->max, callback->min);
            }

            void GroupedComponent::rotDraggerValueChanged(SoRotateCylindricalDragger * dragger, float max, float min)
            {
                make_cyl_dragger_in_between<SoRotateCylindricalDragger>(dragger, max , min);
            }
            

            GroupedComponent::GroupedComponent(SoGroup * base_group)
            {
                initialize_from_group(base_group);
            };

            GroupedComponent::GroupedComponent(GroupedComponent * parent)
            {
                initialize_from_group(parent->group);
                parent->children.push_front(this);
            }

            void GroupedComponent::reset(void)
            {
            }

            void GroupedComponent::propagate_reset(void)
            {
                reset();
                std::list<GroupedComponent *>::iterator first = children.begin();
                std::list<GroupedComponent *>::iterator last = children.end();

                while (first != last)
                {
                    (*first)->propagate_reset();
                    first++;
                }
            }
            
            
            class Stomach : public GroupedComponent
            {
                public:
                    SoScale * scale;
                    SoSphere * sphere;

                public:                
                    Stomach(SoGroup * base_group);                
            };


            Stomach::Stomach(SoGroup * base_group) :
                GroupedComponent(base_group)
            {                
                scale = createScale(group, 1.0, 1.3, 1.0);
                sphere = new SoSphere;
                group->addChild(sphere);
            }

            class OurCylinder : public GroupedComponent
            {
                public:
                    SoRotation * rotation;
                    SoCylinder * cylinder;
                public:
                    OurCylinder(SoGroup * base_group, double radius, double height);
            };


            OurCylinder::OurCylinder(SoGroup * base_group, double radius, double height) :
                GroupedComponent(base_group)
            {
                rotation = createRotation(group, 0, 0, 1, 90);
                cylinder = createCylinder(group, radius, height);
            }

            class UpperArm : 
                public GroupedComponent
            {
                public:
                    SoTranslation * translation;
                    OurCylinder * our_cylinder;
                public:
                    UpperArm(SoGroup * base_group);
                    ~UpperArm() { delete our_cylinder; }
            };

            UpperArm::UpperArm(SoGroup * base_group) :
                GroupedComponent(base_group)
            {
                translation = createTranslation(group, 0.5, 0, 0);
                our_cylinder = new OurCylinder(group, 0.2, 1.0 ); 
            }

            class Elbow : public GroupedComponent
            {
                public:
                    SoScale * scale;
                    SoSphere * sphere;
                public:
                    Elbow(SoGroup * base_group);
            };


            Elbow::Elbow(SoGroup * base_group) :
                GroupedComponent(base_group)
            {
                scale = createScale(group, 0.2, 0.2, 0.2);
                sphere = createSphere(group);
            }

            class Finger : 
                public GroupedComponent
            {
                public:
                   
                    enum Finger_Idx {
                        LEFT, MIDDLE, RIGHT
                    };
                    
                    int which;
                    
                    SoTranslation * sideways_trans;
                    SoTranslation * to_middle;
                    SoScale * elliptic_scale;
                    SoSphere * sphere;

                public:
                    Finger(SoGroup * base_group, int which);        
            };

            Finger::Finger(SoGroup * base_group, int which) :
                GroupedComponent(base_group) , which(which)
            {
                switch (which)
                {
                    case LEFT:
                        sideways_trans = createTranslation(group, 0, 0.2, 0);
                        break;
                    case RIGHT:
                        sideways_trans = createTranslation(group, 0, -0.2, 0);
                        break;
                    case MIDDLE:
                        sideways_trans = createTranslation(group, 0.1, 0, 0);
                        break;
                }
                to_middle = createTranslation(group, 0.1, 0, 0);
                elliptic_scale = createScale(group, 1, 0.5, 0.5);
                sphere = createSphere(group, 0.2);
            }

            class Palm :
                public GroupedComponent
            {
                public:
                    SoSeparator * palm_group;
                    SoScale * scale;
                    SoSphere * sphere;
                    SoSeparator * finger_extender_group;
                    SoScale * finger_extender_scale;
                    /* This is meant to keep the finger extender in sync with
                     * the fingers */
                    SoTranslation * finger_extender_translation;
                    SoTranslate1Dragger * finger_extender;
                    SoSeparator * finger_group;
                    SoTranslation * all_fingers_trans;
                    Finger * fingers[3];

                    static void finger_extender_callback(void * this_ptr, SoDragger * dragger)
                    {
                        ((Palm *)this_ptr)->fingerExtenderDraggerValueChanged((SoTranslate1Dragger *)dragger);
                    }
                    
                    void fingerExtenderDraggerValueChanged(SoTranslate1Dragger * dragger);
                    
                public:
                    Palm(GroupedComponent * base);
                    ~Palm() { for(int i=0;i<3;i++) { delete fingers[i]; } };
                    virtual void reset() { finger_extender->translation.setValue(0.05,0,0); }
            };

            void Palm::fingerExtenderDraggerValueChanged(SoTranslate1Dragger * dragger)
            {
                float x, y, z;
                dragger->translation.getValue().getValue(x,y,z);
                if (x < 0.0144 - 0.000001)
                {
                    x = 0.0144;
                }
                else if (x > 0.178264 + 0.000001)
                {
                    x = 0.178264;
                }
                dragger->translation.setValue(x,y,z);
            }

            Palm::Palm(GroupedComponent * base) :
                GroupedComponent(base)
            {
                palm_group = createSeparator(group);
                scale = createScale(palm_group, 0.8, 1, 1);
                sphere = createSphere(palm_group, 0.3);
                finger_extender_group = createSeparator(group);
                finger_extender_scale = createScale(finger_extender_group, 0.5, 0.5, 0.5);
                finger_extender_translation = createTranslation(finger_extender_group, 0, 0, 0);
                finger_extender = new SoTranslate1Dragger;
                finger_extender_group->addChild(finger_extender);
                finger_extender->translation.setValue(0.05,0,0);
                finger_group = createSeparator(group);
                all_fingers_trans = createTranslation(finger_group, 0.05, 0, 0);
                all_fingers_trans->translation.connectFrom(&(finger_extender->translation));
                finger_extender_translation->translation.connectFrom(&(finger_extender->translation));

                finger_extender->addValueChangedCallback(finger_extender_callback, this);
                for(int i=0;i<3;i++)
                {
                    fingers[i] = new Finger(finger_group, i);
                }
            }


            class Arm : 
                public GroupedComponent
            {
                public:
                    rot_dragger_callback my_rot_dragger_callback, my_arm_to_hand_dragger_callback;
                public:
                    int direction;
                    SoSeparator * rot_dragger_group;
                    SoRotation * rot_dragger_rot;
                    SoTranslation * rot_dragger_trans;
                    SoScale * rot_dragger_scale;
                    SoRotateCylindricalDragger * rot_dragger;
                    SoRotation * base_rotation;
                    SoScale * scale;
                    UpperArm * upper_arm;
                    SoTranslation * arm_base_to_elbow_trans;
                    Elbow * elbow;
                    SoSeparator * arm_to_hand_dragger_group;
                    SoScale * dragger_scale1;
                    SoRotateCylindricalDragger * arm_to_hand_dragger;
                    SoRotation * arm_to_hand_rot;
                    SoTranslation * half_hand_trans;
                    OurCylinder * hand;
                    Palm * palm;

                    // TODO: Fill in: the other parts of the arm.
                public:
                    Arm(GroupedComponent * base, int direction);
                    ~Arm() { delete palm; delete elbow; delete hand; delete upper_arm; }
                    virtual void reset() {
                        rot_dragger->rotation.setValue(SbVec3f(0,1,0),deg2rad(0));
                        arm_to_hand_dragger->rotation.setValue(SbVec3f(0,1,0),deg2rad(0));
                    }
            };

            


            Arm::Arm(GroupedComponent * base, int direction) : 
                GroupedComponent(base) , direction(direction)
            {
                rot_dragger_group = createSeparator(group);
                rot_dragger_rot = createRotation(rot_dragger_group, 0, 1, 0, ((direction == RIGHT) ? (-90) : 90));
                rot_dragger_trans = createTranslation(rot_dragger_group, 0, 0, 3);
                rot_dragger_scale = createScale(rot_dragger_group, 0.25, 0.25, 0.25);
                rot_dragger = createRotateCylindricalDragger(&my_rot_dragger_callback, rot_dragger_group, M_PI/4, -M_PI/4);
                
                base_rotation = createRotation(group, 1, 0, 0, 90);

                base_rotation->rotation.connectFrom(&(rot_dragger->rotation));
                if (direction == RIGHT)
                {
                    scale = createScale(group, -1, 1, 1);
                }
                else
                {
                    scale = NULL;
                }


                
                upper_arm = new UpperArm(group);
                arm_base_to_elbow_trans = createTranslation(group, 1.0, 0, 0);
                elbow = new Elbow(group);
#define FACTOR 7.0
                arm_to_hand_dragger_group = createSeparator(group);
                dragger_scale1 = createScale(arm_to_hand_dragger_group, 1/FACTOR, 1/FACTOR, 1/FACTOR);
                arm_to_hand_dragger = 
                    createRotateCylindricalDragger(
                        &my_arm_to_hand_dragger_callback, 
                        arm_to_hand_dragger_group,
                        0, -M_PI*0.4
                        );
#undef FACTOR
                arm_to_hand_rot = createRotation(group, 0, 1, 0, 0);
                arm_to_hand_rot->rotation.connectFrom(&(arm_to_hand_dragger->rotation));
                half_hand_trans = createTranslation(group, 0.4, 0, 0);
                hand = new OurCylinder(group, 0.2, 0.8);
                // We use it again to move forward to the palm.
                group->addChild(half_hand_trans);
                palm = new Palm(this);
            }

            
            class Shoulder :
                public GroupedComponent
            {
                public:        
                    
                SoTranslation * translation;
                Arm * arms[2];
                public:
                Shoulder(GroupedComponent * base);
                ~Shoulder() { delete arms[0] ; delete arms[1]; }
            };


            Shoulder::Shoulder(GroupedComponent * base) :
                GroupedComponent(base)
            {
                translation = createTranslation(group, 0, 1.0, 0);
                for (int i=0; i < 2; i++)
                {
                    arms[i] = new Arm(this, i);
                } 
            }

            class UpperPart : public GroupedComponent
            {
                public:
                    SoTranslation * down_trans;
                    OurCylinder * cylinder;
                public:
                    UpperPart(SoGroup * base_group);
                    ~UpperPart() { delete cylinder; }
            };

            UpperPart::UpperPart(SoGroup * base_group) :
                GroupedComponent(base_group)
            {
                down_trans = createTranslation(group, 0.05, 0, 0);
                cylinder = new OurCylinder(group, 0.2, 0.7);
            }

            class Shoe : public GroupedComponent
            {
                public:
                    class LowerPart : public GroupedComponent
                    {
                        public:
                            SoBaseColor * col;
                            SoTranslation * low_trans;
                            SoTranslation * side_trans;
                            SoScale * scale;
                            OurCylinder * cyl;
                        public:
                            LowerPart(SoGroup * base_group);
                            ~LowerPart() { delete cyl; }
                    };
                public:
                    SoBaseColor * base_color;
                    SoTranslation * down;
                    SoSeparator * upper_part;
                    SoScale * upper_part_scale;
                    OurCylinder * upper_part_cyl;
                    LowerPart * lower_part;
                public:
                    Shoe(SoGroup * base_group);
                    ~Shoe() { delete upper_part_cyl; delete lower_part; }
            };

            Shoe::LowerPart::LowerPart(SoGroup * base_group_dont_use)
                : GroupedComponent(base_group_dont_use)
            {
                col = createBaseColor(group, 0.8, 0.8, 0.8);
                low_trans = createTranslation(group, 0.15+0.125, 0, 0);
                side_trans = createTranslation(group, 0, 0, 0.6);
                scale = createScale(group, 1, 0.75, 2);
                cyl = new OurCylinder(group, 0.5, 0.25);
            }

            Shoe::Shoe(SoGroup * base_group) :
                GroupedComponent(base_group)
            {
                base_color = createBaseColor(group, 0.5, 0, 0);
                down = createTranslation(group, 0.5, 0, 0);
                upper_part = createSeparator(group);
                upper_part_scale = createScale(upper_part, 1, 1, 1.5);
                //SoSphere * sphere = createSphere(group);
                upper_part_cyl = new OurCylinder(upper_part, 0.25, 0.3);
                lower_part = new LowerPart(group);
            }
            
                

            class Leg : public GroupedComponent
            {
                public:
                    rot_dragger_callback my_dragger_callback;
                    
                public:
                    SoTranslation * left_or_right_trans;
                    SoRotation * rot;
                    SoSeparator * dragger_group;
                    SoTranslation * dragger_trans;
                    SoScale * dragger_scale;
                    SoRotateCylindricalDragger * dragger;
                    SoRotation * leg_rot;
                    UpperPart * upper_part;
                    Shoe * shoe;
                        
                public:
                    Leg(GroupedComponent * base, int direction);
                    ~Leg() { delete upper_part; delete shoe; }
                    virtual void reset(void) { dragger->rotation.setValue(SbVec3f(0,1,0),deg2rad(0)); }
            };

            Leg::Leg(GroupedComponent * base, int direction) :
                GroupedComponent(base)
            {
                int direction_factor = ((direction == LEFT) ? 1 : -1);
                left_or_right_trans = 
                    createTranslation(
                        group, 
                        direction_factor * -0.4,
                        0,
                        0
                        );
                
                /* This rotation will switch the following coordinates:
                    z remains the same
                    x <- -y
                    y <- x
                    The purpose of it is to make sure the x axis is parallel
                    to the extension of the leg.  
                */
         
                rot = createRotation(group, 0, 0, 1, -90);
                dragger_group = createSeparator(group);
                dragger_trans = createTranslation(dragger_group, 0, -direction_factor * 2, 0);
                dragger_scale = createScale(dragger_group, 0.25, 0.25, 0.25);
                dragger = createRotateCylindricalDragger(&my_dragger_callback, dragger_group, M_PI/4, -M_PI/4);
                leg_rot = createRotation(group, 0, 1, 0, 0);
                leg_rot->rotation.connectFrom(&(dragger->rotation));
                upper_part = new UpperPart(group);
                shoe = new Shoe(group);
            }

            class FeetBase :
                public GroupedComponent
            {
                public:
                    SoTranslation * down_trans;
                    Leg * legs[2];
                public:
                    FeetBase(GroupedComponent * base);
                    ~FeetBase() { for(int a=0;a<2;a++) { delete legs[a]; }}
            };

            FeetBase::FeetBase(GroupedComponent * base) :
                GroupedComponent(base)
            {
                down_trans = createTranslation(group, 0, -1.1, 0);
                for(int i=0;i<2;i++)
                {
                    legs[i] = new Leg(this, i);
                }
            }

            class Neck : public GroupedComponent
            {
                public:
                    class Nose : public GroupedComponent
                    {
                        public:
                            SoTranslation * trans;
                            SoSphere * sphere;
                        public:
                            Nose(SoGroup * base_group);
                    };

                    class Eye : public GroupedComponent
                    {
                        class WhiteEye : public GroupedComponent
                        {
                            public:
                                SoBaseColor * color;
                                SoScale * scale;
                                SoSphere * sphere;
                            public:
                                WhiteEye(SoGroup * base_group);
                        };

                        class Pupil : public GroupedComponent
                        {
                            public:
                                SoBaseColor * color;
                                SoTranslation * trans;
                                SoScale * scale;
                                SoSphere * sphere;
                            public:
                                Pupil(SoGroup * base_group);
                        };                            
                            
                        public:
                            int direction;
                            SoTranslation * to_center_trans;
                            SoScale * reverse_scale;
                            SoSeparator * main_group;
                            SoRotation * x_rot, * y_rot, * z_rot;
                            WhiteEye * white_eye;
                            Pupil * pupil;
                        public:
                            Eye(SoGroup * base_group, int direction);
                            ~Eye() { delete white_eye; delete pupil; }
                    };

                    class Horn : public GroupedComponent
                    {
                        public:
                            int direction;
                            SoRotation * rot;
                            SoTranslation * to_origin;
                            SoTranslation * to_center;
                            SoCone * cone;
                        public:
                            Horn(SoGroup * base_group, int direction);
                    };
                    
                    
                public:
                    SoTranslation * translation;
                    SoSeparator * dragger_group;
                    SoTranslation * dragger_trans;
                    SoScale * dragger_scale;
                    SoRotateCylindricalDragger * dragger;
                    SoRotation * rot;
                    
                    SoSeparator * neck;
                    SoBaseColor * neck_color;
                    SoCylinder * neck_cyl;
                    SoTranslation * to_head_trans;
                    SoSphere * head_sphere;

                    Nose * nose;
                    Eye * eyes[2];
                    Horn * horns[2];
                    
                    
                public:
                    Neck(GroupedComponent * base);

                    virtual void reset(void) { dragger->rotation.setValue(SbVec3f(0,1,0),deg2rad(0)); }
            };

#define HORN_LENGTH 0.3
            Neck::Horn::Horn(SoGroup * base_group, int direction) :
                GroupedComponent(base_group), direction(direction)
            {
                rot = createRotation(group, 0, 0, 1, (direction ? 60 : -60));
                to_origin = createTranslation(group, 0, 0.8, 0);
                
                to_center = createTranslation(group, 0, HORN_LENGTH, 0);
                cone = createCone(group, 0.15,0.6);
            }

            Neck::Nose::Nose(SoGroup * base_group) :
                GroupedComponent(base_group)
            {
                trans = createTranslation(group, 0, -0.1, 0.8);
                sphere = createSphere(group, 0.2);
            }

            Neck::Neck(GroupedComponent * base) :
                GroupedComponent(base)
            {
                translation = createTranslation(group, 0, 1.3, 0);
                dragger_group = createSeparator(group);
                dragger_trans = createTranslation(dragger_group, 0, 2, 0);
                dragger_scale = createScale(dragger_group, 0.25, 0.25, 0.25);
                dragger = new SoRotateCylindricalDragger;
                dragger_group->addChild(dragger);
                rot = createRotation(group, 0, 1, 0, 0);
                rot->rotation.connectFrom(&(dragger->rotation));
                neck = createSeparator(group);
                neck_color = createBaseColor(neck, 0, 0, 1);
                neck_cyl = createCylinder(neck, 0.4, 0.3);
                to_head_trans = createTranslation(group, 0, 0.7, 0);
                head_sphere = createSphere(group, 0.8);
                nose = new Nose(group);
                int dir;
                    
                for(dir=0;dir<2;dir++)
                {
                    eyes[dir] = new Eye(group, dir);
                }
                for(dir=0;dir<2;dir++)
                {
                    horns[dir] = new Horn(group, dir);
                }

            }

            Neck::Eye::Eye(SoGroup * base_group, int direction) :
                GroupedComponent(base_group)
            {
                to_center_trans = 
                    createTranslation(
                        group,
                        (direction == LEFT) ? -0.3 : 0.3,
                        0.3,
                        0.63
                        );

                if (direction == LEFT)
                {
                    reverse_scale = 
                        createScale(group,-1, 1, 1);
                }
                else
                {
                    reverse_scale = NULL;
                }
                x_rot = createRotation(group, 1, 0, 0, -30);
                y_rot = createRotation(group, 0, 1, 0, 0.3);
                z_rot = createRotation(group, 0, 0, 1, 0.2);
                white_eye = new WhiteEye(group);
                pupil = new Pupil(group);
            }

            Neck::Eye::WhiteEye::WhiteEye(SoGroup * base_group) :
                GroupedComponent(base_group)
            {
                color = createBaseColor(group, 1, 1, 1);
                scale = createScale(group, 1, 1.75, 0.25);
                sphere = createSphere(group, 0.22);
            }

            Neck::Eye::Pupil::Pupil(SoGroup * base_group) :
                GroupedComponent(base_group)
            {
                color = createBaseColor(group, 0,0,0);
                trans = createTranslation(group, -0.06, -0.19, 0.05);
                scale = createScale(group, 1, 1.75, 0.25);
                sphere = createSphere(group, 0.1);
            }

            class Tail : 
                public GroupedComponent
            {
                public:
                    rot_dragger_callback my_rot_dragger_callback;
                    
                public:
                    SoTranslation * to_origin;
                    SoSeparator * rot_dragger_group;
                    SoTranslation * rot_dragger_trans;
                    SoScale * rot_dragger_scale;
                    SoRotation * rot_dragger_rotation;
                    SoRotateCylindricalDragger * rot_dragger;
                    SoComposeRotation * rot_engine;
                    SoDecomposeRotation * rot_engine_decompose;
                    SoRotation * constant_y_rot;
                    SoRotation * y_rot;
                    SoTranslation * advance;
                    SoCylinder * cyl;
                    SoTranslation * advance_to_end_of_cyl;
                    SoTranslation * to_center_of_cone;
                    SoCone * cone;
                public:
                    Tail(GroupedComponent * base);
                    virtual void reset(void) { rot_dragger->rotation.setValue(0,1,0,deg2rad(90)); }
            };

            Tail::Tail(GroupedComponent * base) :
                GroupedComponent(base)
            {
                rot_dragger_group = createSeparator(group);
                to_origin = createTranslation(group, 0, -0.2, -0.3);
                rot_dragger_trans = createTranslation(rot_dragger_group, 0, 0.5, -2);
                rot_dragger_scale = createScale(rot_dragger_group, 0.25, 0.25, 0.25);
                rot_dragger_rotation = createRotation(rot_dragger_group, 0, 0, 1, 270);
                rot_dragger = 
                    createRotateCylindricalDragger(
                        &my_rot_dragger_callback, 
                        rot_dragger_group,
                        deg2rad(110),
                        deg2rad(70)
                            );
                        
                rot_engine = new SoComposeRotation;
                constant_y_rot = createRotation(group, 1, 0, 0, 150);
                y_rot = createRotation(group, 1,0,0,-120);
                rot_engine_decompose = new SoDecomposeRotation;
                rot_engine_decompose->rotation.connectFrom(&(rot_dragger->rotation));
                rot_engine->axis.setValue(1, 0, 0);
                rot_engine->angle.connectFrom(&(rot_engine_decompose->angle));
                y_rot->rotation.connectFrom(&(rot_engine->rotation));
                reset(); // This sets the rotation of the dragger.
                
                advance = createTranslation(group, 0, 0.9, 0);
                cyl = createCylinder(group, 0.1, 1.5);
                advance_to_end_of_cyl = createTranslation(group, 0, 0.75, 0);
                to_center_of_cone = createTranslation(group, 0, 0.2, 0);
                cone = createCone(group, 0.15, 0.42);
            }


            class Daemon :
                public GroupedComponent
            {
                public:
                    SoTransform * base_transform;
                    SoBaseColor * color;
                    SoGroup * body_group;
                    SoTrackballManip * trackball;
                    Stomach * stomach;
                    Shoulder * shoulder;
                    FeetBase * feet_base;
                    Neck * neck;
                    Tail * tail;
                    Daemon(SoSeparator * base_group);
                    ~Daemon() { delete stomach; delete shoulder; delete feet_base; delete neck ; delete tail; }
                    virtual void reset(void);
            };

            void Daemon::reset(void)
            {
                base_transform->setToDefaults();
            }

            Daemon::Daemon(SoSeparator * base_group) :
                GroupedComponent(base_group)
            {
                base_transform = new SoTransform;
                group->addChild(base_transform);
                color = new SoBaseColor;
                color->rgb.setValue(1.0, 0, 0); // Red
                group->addChild(color);
                body_group = new SoGroup;
                group->addChild(body_group);
#if 0
                trackball = new SoTrackballManip;
                body_group->addChild(trackball);
#endif
                stomach = new Stomach(body_group);
                shoulder = new Shoulder(this);
                feet_base = new FeetBase(this);
                neck = new Neck(this);
                tail = new Tail(this);
            }
        }   
    }
}

char * szHelpText = 
"          BSD Daemon\n"
"By Shlomi Fish (0-3386577-5) and Dotan Barak (0-3238863-9)\n"
"\n"
"Help:\n"
"\n"
"To move the various parts of the daemon press the various controls,"
" keep the mouse button pressed, and drag in the requested direction\n"
"\n"
"Movable Parts\n"
"1. The head can be rotate in 360 degrees. (like any respectable demon)\n"
"2. The legs can be rotated back and forth.\n"
"3. The tail can go up and down.\n"
"4. The arms can be rotated back and forth.\n"
"5. The elbow can be rotated from a straight hand to a forward one.\n"
"6. The fingers can be extended or shortened.\n"
"\n"
"\n"
"Operation keys:\n\n"
"Press 'r' to reset the daemon's position and parts to their initial configuration\n"
"press 'g' to move the daemon through the path you specified\n"
"press 'p' to open the path configuration dialog (points, angles and algorithm)\n"
"Press 'h' to open this help window again\n"
"Press 'q' to quit\n"
;


Widget help_dialog;

SoPath *handleBoxPath    = NULL;
SoHandleBoxManip    *myHandleBox;

SoTrackballManip    *myTrackball;
SoPath *trackballPath    = NULL;

int trackball_active = 0;
int use_trackball = 0;


static void
processKeyEvents( void *data, SoEventCallback *cb );

static void create_help_dialog(Widget parent)
{
    Arg args[50];
    int n=0;
    XtSetArg(args[n], XmNfractionBase, 3); n++;
    help_dialog = XmCreateFormDialog(parent,"help_dialog", args, n);

    n = 0;
    XtSetArg(args[n], XmNscrollVertical, True); n++;
    XtSetArg(args[n], XmNscrollHorizontal, False); n++;
    XtSetArg(args[n], XmNeditMode, XmMULTI_LINE_EDIT); n++;
    XtSetArg(args[n], XmNeditable, False); n++;
    XtSetArg(args[n], XmNwordWrap, True); n++;
    XtSetArg(args[n], XmNvalue, szHelpText); n++;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM); n++;
    XtSetArg(args[n], XmNrows, 20); n++;

    Widget text_display = 
        XmCreateScrolledText(
            help_dialog,
            "help_text",
            args,
            n
            );
           
    XtManageChild(text_display);
}

void selectionCallback(void *, SoPath *);
void deselectionCallback(void *, SoPath *);

SoSphere * theBody;
SoSeparator * theRoot;

Dotan_and_Shlomi::Inventor::Daemon::Daemon * daemon_ptr;

SoTransform * scene_trans;


void MatrixFromEulerAngles(
  const float X_Angle,
  const float Y_Angle,
  const float Z_Angle,
  SbMatrix& Matrix
){
  Matrix.makeIdentity();

  float sinx = sin(X_Angle);
  float cosx = cos(X_Angle);
  float siny = sin(Y_Angle);
  float cosy = cos(Y_Angle);
  float sinz = sin(Z_Angle);
  float cosz = cos(Z_Angle);

  Matrix[0][0] = cosy*cosz;
  Matrix[0][1] = cosy*sinz;
  Matrix[0][2] = -siny;

  Matrix[1][0] = sinx*siny*cosz - cosx*sinz;
  Matrix[1][1] = sinx*siny*sinz + cosx*cosz;
  Matrix[1][2] = cosy*sinx;

  Matrix[2][0] = cosx*siny*cosz + sinx*sinz;
  Matrix[2][1] = cosx*siny*sinz - sinx*cosz;
  Matrix[2][2] = cosy*cosx;
} /*MatrixFromEulerAngles*/


void EulerAnglesFromMatrix(
  const SbMatrix& Matrix,
  float& X_Angle,
  float& Y_Angle,
  float& Z_Angle
){
  float siny = - Matrix[0][2];
  float cosy = sqrt(1.0-siny*siny);

  float sinx,cosx,sinz,cosz;

  Y_Angle = atan2(siny,cosy);

  if (cosy != 0.0)
  {
    sinx = Matrix[1][2]/cosy;
    cosx = Matrix[2][2]/cosy;
    sinz = Matrix[0][1]/cosy;
    cosz = Matrix[0][0]/cosy;
    Z_Angle = atan2(sinz,cosz);
  }
  else
  {
     sinx = -Matrix[2][1];
     cosx = Matrix[1][1];
     Z_Angle = 0.0;
  }

  X_Angle = atan2(sinx,cosx);
} /*EulerAnglesFromMatrix*/

void change_scene_trans_callback(void * data, SoSensor * sensor)
{
    if (factor < 1)
    {
        factor += 0.002;
        if (type_of_path == PATH_MATRIX)
        {
            SbMatrix start_mat;
            SbMatrix end_mat;
            
            start.getValue(start_mat);
            end.getValue(end_mat);
            int x,y;
            for(x=0;x<4;x++)
            {
                for(y=0;y<4;y++)
                {
                    start_mat[x][y] /= start_mat[3][3];
                    end_mat[x][y] /= end_mat[3][3];
                }
            }
            SbMat result;
            for(x=0;x<4;x++)
            {
                for(y=0;y<4;y++)
                {
                    result[x][y] = start_mat[x][y] * (1-factor) + end_mat[x][y] * factor;
                }
            }
            
            scene_trans->setMatrix(SbMatrix(result));
        }
        else if (type_of_path == PATH_BEZIER)
        {
#define get_elem(elem) float elem = polynom_eval(the_path_polys.elem, factor);
            get_elem(x);
            get_elem(y);
            get_elem(z);
            get_elem(x_ang);
            get_elem(y_ang);
            get_elem(z_ang);
#undef get_elem

            SbMatrix rot;
            MatrixFromEulerAngles(x_ang, y_ang, z_ang, rot);

            SbMatrix trans = SbMatrix::identity();
            trans.setTranslate(SbVec3f(x,y,z));

            SbMatrix total_xform = rot * trans;
            
            scene_trans->setMatrix(total_xform);
        }
    }
}


static void travel_path(void)
{
    type_of_path = new_type_of_path;
    if (type_of_path == PATH_MATRIX)
    {
        if (path_len >= 2)
        {
            point_t * e = &(path[0]);
            SbMatrix rot;
            MatrixFromEulerAngles(e->x_ang, e->y_ang, e->z_ang, rot);
            SbMatrix trans = SbMatrix::identity();
            trans.setTranslate(SbVec3f(e->x,e->y,e->z));
            start = rot * trans;

            e = &(path[path_len-1]);
            MatrixFromEulerAngles(e->x_ang, e->y_ang, e->z_ang, rot);
            trans.setTranslate(SbVec3f(e->x,e->y,e->z));
            end = rot * trans;
        }
        else
        {
            start.setTransform(SbVec3f(0, 0, 0), SbRotation(SbVec3f(1, 0, 0), 0), SbVec3f(1,1,1));
            end.setTransform(SbVec3f(10, -5, 8), SbRotation(SbVec3f(1, 1, 0), M_PI/180*30), SbVec3f(1,1,1));
        }
    }
    else if (type_of_path == PATH_BEZIER)
    {
        /* Calculate the path polynoms */
        float * temp;
        int i;
        
        temp = (float *)malloc(sizeof(temp[0])*path_len);
#define make_path(elem) \
        for(i=0;i<path_len;i++)     \
        {       \
            temp[i] = path[i].elem;      \
        }      \
        if (the_path_polys.elem != NULL)    \
        {         \
            polynom_free(the_path_polys.elem);    \
        }\
        the_path_polys.elem = polynom_get_bezier(path_len-1, temp);

        make_path(x);
        make_path(y);
        make_path(z);
        make_path(x_ang);
        make_path(y_ang);
        make_path(z_ang);
    }
    factor = 0;
}

int main(int argc, char * * argv)
{
    memset(&the_path_polys, '\0', sizeof(the_path_polys));
    Widget myWindow = SoXt::init(argv[0]);
    if (myWindow == NULL)
    {
        return 1;
    }

    int examiner_viewer = 1;

    if ((argc > 1) && (!strcmp(argv[1], "--nev")))
    {
        examiner_viewer = 0;
    }
    
    SoSelection * scene = new SoSelection;
    scene->ref();

    SoEventCallback * eventCB = new SoEventCallback;
    scene->addChild(eventCB);

    SoSeparator * root = Dotan_and_Shlomi::Inventor::Daemon::createSeparator(scene);

    SoPerspectiveCamera * myCamera;
    
    if (!examiner_viewer)
    {
        myCamera = new SoPerspectiveCamera;
        root->addChild(myCamera);
        root->addChild(new SoDirectionalLight);
    }
#if 0
    myCamera->position.setValue(atoi(argv[1]),atoi(argv[2]),atoi(argv[3]));

    myCamera->nearDistance.setValue(1);
    myCamera->farDistance.setValue(2);
    myCamera->focalDistance.setValue(1.5);
#endif

    //scene_trans = new SoTransform;
    
    //root->addChild(scene_trans);

    SoTimerSensor * my_timer_sensor = new SoTimerSensor(change_scene_trans_callback, NULL);

    my_timer_sensor->setInterval(SbTime(0.01));

    //root->addChild(my_timer_sensor);
    my_timer_sensor->schedule();

    Dotan_and_Shlomi::Inventor::Daemon::Daemon * daemon = 
        new Dotan_and_Shlomi::Inventor::Daemon::Daemon(root);

    scene_trans = daemon->base_transform;

    daemon_ptr = daemon;

    theBody = daemon->stomach->sphere;
    theRoot = daemon->group;

    SoXtRenderArea * myRenderArea;
    SoXtExaminerViewer * myViewer;

    if (!examiner_viewer)
    {
        myRenderArea = new SoXtRenderArea(myWindow);
        myCamera->viewAll(scene, myRenderArea->getViewportRegion());
        myRenderArea->setSceneGraph(scene);
        myRenderArea->setTitle("BSD Daemon");
        myRenderArea->show();

        
    }
    else
    {    
        myViewer = new SoXtExaminerViewer(myWindow);
        myViewer->setSceneGraph(scene);
        myViewer->setTitle("BSD Daemon");
        myViewer->show();
    }

    eventCB->addEventCallback(SoKeyboardEvent::getClassTypeId(), processKeyEvents, myWindow);

    SoOutput * myOutput = new SoOutput();
    myOutput->openFile("daemon_from_cpp.iv");
    SoWriteAction * write = new SoWriteAction(myOutput);
    write->apply(scene);
    myOutput->closeFile();

    create_path_dialog(myWindow);

    create_help_dialog(myWindow);

    create_move_choice_dialog(myWindow);

    factor = 10;

    SoXt::show(myWindow);

    SoXt::mainLoop();    
}

// Is this node of a type that is influenced by transforms?
SbBool
isTransformable(SoNode *myNode)
{
   if (myNode->isOfType(SoGroup::getClassTypeId())
      || myNode->isOfType(SoShape::getClassTypeId())
      || myNode->isOfType(SoCamera::getClassTypeId())
      || myNode->isOfType(SoLight::getClassTypeId()))
      return TRUE;
   else 
      return FALSE;
}


//  Create a path to the transform node that affects the tail
//  of the input path.  Three possible cases:
//   [1] The path-tail is a node kit. Just ask the node kit for
//       a path to the part called "transform"
//   [2] The path-tail is NOT a group.  Search siblings of path
//       tail from right to left until you find a transform. If
//       none is found, or if another transformable object is 
//       found (shape,group,light,or camera), then insert a 
//       transform just to the left of the tail. This way, the 
//       manipulator only effects the selected object.
//   [3] The path-tail IS a group.  Search its children left to
//       right until a transform is found. If a transformable
//       node is found first, insert a transform just left of 
//       that node.  This way the manip will affect all nodes
//       in the group.
SoPath *
createTransformPath(SoPath *inputPath)
{
   int pathLength = inputPath->getLength();
   if (pathLength < 2) // Won't be able to get parent of tail
      return NULL;

   SoNode *tail = inputPath->getTail();

   // CASE 1: The tail is a node kit.
   // Nodekits have built in policy for creating parts.
   // The kit copies inputPath, then extends it past the 
   // kit all the way down to the transform. It creates the
   // transform if necessary.
   if (tail->isOfType(SoBaseKit::getClassTypeId())) {
      SoBaseKit *kit = (SoBaseKit *) tail;
      return kit->createPathToPart("transform",TRUE,inputPath);
   }

   SoTransform *editXf = NULL;
   SoGroup     *parent;
   SbBool      existedBefore = FALSE;

   // CASE 2: The tail is not a group.
   SbBool isTailGroup;
   isTailGroup = tail->isOfType(SoGroup::getClassTypeId());
   if (!isTailGroup) {
      // 'parent' is node above tail. Search under parent right
      // to left for a transform. If we find a 'movable' node
      // insert a transform just left of tail.  
      parent = (SoGroup *) inputPath->getNode(pathLength - 2);
      int tailIndx = parent->findChild(tail);

      for (int i = tailIndx; (i >= 0) && (editXf == NULL);i--){
         SoNode *myNode = parent->getChild(i);
         if (myNode->isOfType(SoTransform::getClassTypeId()))
            editXf = (SoTransform *) myNode;
         else if (i != tailIndx && (isTransformable(myNode)))
            break;
      }
      if (editXf == NULL) {
         existedBefore = FALSE;
         editXf = new SoTransform;
         parent->insertChild(editXf, tailIndx);
      }
      else
         existedBefore = TRUE;
   }
   // CASE 3: The tail is a group.
   else {
      // Search the children from left to right for transform 
      // nodes. Stop the search if we come to a movable node.
      // and insert a transform before it.
      parent = (SoGroup *) tail;
      int i;
      for (i = 0;
         (i < parent->getNumChildren()) && (editXf == NULL); 
         i++) {
         SoNode *myNode = parent->getChild(i);
         if (myNode->isOfType(SoTransform::getClassTypeId()))
            editXf = (SoTransform *) myNode;
         else if (isTransformable(myNode))
            break;
      }
      if (editXf == NULL) {
         existedBefore = FALSE;
         editXf = new SoTransform;
         parent->insertChild(editXf, i);
      }
      else 
         existedBefore = TRUE;
   }

   // Create 'pathToXform.' Copy inputPath, then make last
   // node be editXf.
   SoPath *pathToXform = NULL;
   pathToXform = inputPath->copy();
   pathToXform->ref();
   if (!isTailGroup) // pop off the last entry.
      pathToXform->pop();
   // add editXf to the end
   int xfIndex   = parent->findChild(editXf);
   pathToXform->append(xfIndex);
   pathToXform->unrefNoDelete();

   return(pathToXform);
}

// This routine is called when an object
// gets selected. We determine which object
// was selected, then call replaceNode()
// to replace the object's transform with
// a manipulator.
void
selectionCallback(
   void *, // user data is not used
   SoPath *selectionPath)
{

    // Attach the handle box to the sphere,
    // the trackball to the cube
    // or the transformBox to the wrapperKit

    //if (selectionPath->getTail() == theBody)
    if (1)
    {
        SoPath * theRootPath = new SoPath(theRoot);
        // Attach the manipulator.
        // Use the convenience routine to get a path to
        // the transform that effects the selected object.
        SoPath *xformPath = createTransformPath(theRootPath);
        if (xformPath == NULL) return;
        xformPath->ref();
        
        if (use_trackball)
        {
            trackballPath = xformPath;
            myTrackball->replaceNode(xformPath);
        }
        else
        {
            handleBoxPath = xformPath;
            myHandleBox->replaceNode(xformPath);            
        }
        trackball_active = use_trackball;
        use_trackball = ! use_trackball;
   }
}

// This routine is called whenever an object gets
// deselected. It detaches the manipulator from
// the transform node, and removes it from the 
// scene graph that will not be visible.
void
deselectionCallback(
   void *, // user data is not used
   SoPath *deselectionPath)
{
   if (deselectionPath->getTail()->
        isOfType(SoCone::getClassTypeId())) {
       if (trackball_active)
       {
           myTrackball->replaceManip(trackballPath, NULL);
           trackballPath->unref();
       }
       else
       {
            myHandleBox->replaceManip(handleBoxPath,NULL);
            handleBoxPath->unref();
               
       }
   }
}




static void
processKeyEvents( void *data, SoEventCallback *cb )
{
    if (SO_KEY_PRESS_EVENT(cb->getEvent(), H)) {
        XtManageChild(help_dialog);
    }
    else if (SO_KEY_PRESS_EVENT(cb->getEvent(), R)) {
        daemon_ptr->propagate_reset();
    }
    else if (SO_KEY_PRESS_EVENT(cb->getEvent(), Q)) {
        exit(0);
    }
    else if (SO_KEY_PRESS_EVENT(cb->getEvent(), P)) {
        XtManageChild(path_dialog);
        XtManageChild(move_choice_dialog);
    }
    else if (SO_KEY_PRESS_EVENT(cb->getEvent(), G)) {
        travel_path();
    }
}

