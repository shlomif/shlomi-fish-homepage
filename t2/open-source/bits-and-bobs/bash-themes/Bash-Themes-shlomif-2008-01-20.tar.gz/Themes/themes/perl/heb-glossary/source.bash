load_common mymake

this="$HOME/Svn/Docs/Perl/Hebrew-Glossary/"

cd $this

