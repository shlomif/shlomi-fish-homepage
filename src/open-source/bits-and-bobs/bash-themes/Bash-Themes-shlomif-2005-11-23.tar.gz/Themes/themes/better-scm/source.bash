load_common mymake

this="/home/shlomi/Docs/programming/SCM/better-scm/site"
trunk="$this/trunk"
comparison="$trunk/src/comparison"

cd $trunk

