load_common completion

base="/home/shlomi/Download/unpack/net/www/mozilla"
export MOZCONFIG="$base/mozconfig/mozconfig-firefox"
this="$base/from_cvs/mozilla"
cd $this

