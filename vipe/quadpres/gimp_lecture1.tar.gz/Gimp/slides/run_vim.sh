alias gvim="gvim -u ../vimrc -font '-misc-fixed-medium-r-normal-*-*-140-*-*-c-*-iso8859-1'"


