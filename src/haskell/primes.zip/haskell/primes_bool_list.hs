
primes :: Int -> [Int]
primes how_much =  (iterate 2 initial_map) where
	initial_map :: [Bool]
	initial_map = (map (\x -> True) [ 0 .. how_much])
	iterate :: Int -> [Bool] -> [Int]
	iterate p (a:as) | p > mybound = process_map p (a:as)
	                 | a = p:(iterate (p+1) (mymark (p+1) step (2*p) as))
	                 | (not a) = (iterate (p+1) as) where
	                 	step :: Int
	                 	step = if p == 2 then p else 2*p
        mymark :: Int -> Int -> Int -> [Bool] -> [Bool]
        mymark cur_pos step next_pos [] = []
        mymark cur_pos step next_pos (a:as) = 
        	if (cur_pos == next_pos) then
        		False:(mymark (cur_pos+1) step (cur_pos+step) as)
        	else
        		a:(mymark (cur_pos+1) step next_pos as)
	mybound :: Int
	mybound = ceiling(sqrt(fromIntegral(how_much)))
	process_map :: Int -> [Bool] -> [Int]
	process_map cur_pos [] = []
	process_map cur_pos (a:as) | a = cur_pos:(process_map (cur_pos+1) as)
	                           | (not a) = (process_map (cur_pos+1) as)
					
