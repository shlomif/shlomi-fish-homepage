#!/bin/sh

PATCH_DIR="$1"
CONFIGURE_OPTIONS="$2"

patch -p 1 < "$PATCH_DIR"/grad-fu.patch
cp -f "$PATCH_DIR"/gradient.c app/gradient.c
chmod 755 ./plug-ins/perl/examples/perl_rainbow_strips.pl
automake
./configure $CONFIGURE_OPTIONS
(cd tools/pdbgen && make)


