#!/usr/bin/perl

use strict;

use Data::Dumper;

#use Gamla::Web::PathMan::Pointer::WithMount;
use Gamla::Web::PathMan::Perl;

my $pathman = Gamla::Web::PathMan::Perl->new();

my $p = $pathman->get_base_pointer();

my $site = "www.iglu.org.il";

$p->mkdir_("Hello");
$p->mkdir_("Shlomif");
$p->atomic_cd("Hello");
$p->mkdir_("You");
my $p2 = $p->duplicate_by_elements_copy();
$p->atomic_cd("..");
$p->mkdir_("Chen");
$p->atomic_cd("Chen");
$p->set_attribs(
    {
        'path' => [ "chen" ],
        'site' => $site,
    }
);
$p->mkdir_("Shapira");
$p->cd_(["..", ".."]);
$p->mkdir_("Ira");
$p->cd_(["Ira", "..", "Chen" , "Shapira" , ".", ".."]);
$p->mkdir_("Hackers-IL");

$p2->mkdir_("World");
$p2->mkdir_("Bill (Gates Naturally)");
$p2->set_attribs(
    {
        'path' => ["hello"],
        'site' => $site,
        'cgi_params' => [ "you" => "too", "u" => "2" ],
    }
    );

print join(" ", @{$p->pwd_()}), "\n";
#$p->cd_(["..", ".." , "Hello"]);
$p->cd_(["..", "Hello"]);
print join(" ", @{$p->pwd_()}), "\n";
my $myattribs = $p->get_attribs( [ "path", "cgi_params" ] );

my $d = Data::Dumper->new([$pathman, $p, $myattribs],["\$pathman", "\$p", "\$myattrib"]);

my $dump_text =  $d->Dump();

open O, ">dump.pl";
print O $dump_text;
close(O);
