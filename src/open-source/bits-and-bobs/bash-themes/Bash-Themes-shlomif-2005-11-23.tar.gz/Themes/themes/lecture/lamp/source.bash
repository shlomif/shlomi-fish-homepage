this="$HOME/Svn/Docs/lecture/LAMP/summary"

cd $this

