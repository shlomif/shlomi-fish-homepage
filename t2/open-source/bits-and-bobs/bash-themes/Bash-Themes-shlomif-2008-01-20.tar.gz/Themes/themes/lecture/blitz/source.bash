base="$HOME/Docs/lecture/Newbies/Blitz"
this="$base/slides"
images="$base/Images"

render()
{
    (cd "$this" && quadp render -a)
}

upload()
{
    (cd "$this" && quadp upload)
}

cd $this
