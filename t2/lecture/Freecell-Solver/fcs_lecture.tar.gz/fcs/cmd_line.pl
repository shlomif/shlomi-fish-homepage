#!/usr/bin/perl -w

use strict;

#use CGI;
use Contents;
use Pres;

#my $q = CGI->new();

#print $q->header();

my $contents = Contents::get_contents();

my $document_name = shift || "";

my $p = Pres->new($contents, $document_name);

$p->render();


