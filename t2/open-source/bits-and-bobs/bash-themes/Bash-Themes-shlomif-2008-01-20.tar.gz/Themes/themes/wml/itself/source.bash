load_common mymake
load_common completion

base="$HOME/progs/wml/wml-itself/core/conversion-to-cmake/src"
trunk="$base"
# this="$trunk/wml_backend/p2_mp4h"
this="$trunk/wml_backend/p3_eperl"

cd $this

prompt()
{
    perl ~/bin/prompt-cmd.pl "$(pwd)" \
        "\$trunk=$trunk" \
        "~=$HOME"
}

__ignore_cmake_gen_files()
{
    (cd "$trunk" ;
    for I in CMakeFiles cmake_install.cmake CMakeCache.txt ; do
        perl ~/bin/add-file-to-svn-ignore.pl "$I"
    done
    )
}

e()
{
    (cd "$this" ;
        gvim -p CMakeLists.txt ../p2_mp4h/CMakeLists.txt \
        Makefile.in configure.in 
    )
}

PS1="\\u:\$(prompt)\\$ "

