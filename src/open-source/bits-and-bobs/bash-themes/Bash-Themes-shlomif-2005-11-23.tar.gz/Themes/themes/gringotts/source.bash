load_common mymake
# load_common gen_patch

base="$HOME/Download/unpack/file/gringotts"
this="$trunk/"
rw_repos_url="svn+ssh://svn.berlios.de/svnroot/repos/web-cpan/nav-menu"
read_repos_url="svn://svn.berlios.de/web-cpan/nav-menu"
test_dir="$trunk/tests/integration/sites-gen"

# Make sure that gvim's filename completion ignores filenames that it should
# not edit.

__gvim_completion()
{ 
    local cur
    cur="${COMP_WORDS[COMP_CWORD]}"
    COMPREPLY=( $(compgen -f -X '*~' -- "$cur" |
        grep -v '/\.' | grep -v '^\.') )
}

complete -o filenames -F __gvim_completion gvim

__test_distribution()
{
    (
        module_name="Shlomif-NavMenu"
        cd "$this"
        make disttest
        rm -fr "$(cat Makefile | grep "^DISTVNAME = " | sed 's/^DISTVNAME = //')"
    )
}

__run_integration_tests()
{
    (
        touch "$test_dir"/head.pl ;
        __display_integration_tests_results ;
    )
}

__display_integration_tests_results()
{
    (
        cd "$test_dir" ;
        make ;
    )
}

cd $this

