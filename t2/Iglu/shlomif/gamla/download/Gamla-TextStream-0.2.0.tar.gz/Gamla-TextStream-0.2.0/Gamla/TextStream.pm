package Gamla::TextStream;

use strict;

use Gamla::Object;

use vars qw(@ISA);

@ISA=qw(Gamla::Object);

sub append
{
}

sub flush
{
}
