#!/usr/bin/perl -w

use strict;

use Gamla::TextStream::Out::Buffer;
use Gamla::TextStream::Out::File;
use Gamla::TextStream::Out::BufRef;
use Gamla::TextStream::Out::Indirect::Buffered;
use Gamla::TextStream::Out::File::Buffered;

my $s_buffer = Gamla::TextStream::Out::Buffer->new();
my $s_file = Gamla::TextStream::Out::File->new(\*STDOUT);
my $buffer = "Content-Type:text/html\n\n";
my $s_bufref = Gamla::TextStream::Out::BufRef->new(\$buffer);
my $s_gaal = Gamla::TextStream::Out::Indirect::Buffered->new(
    $s_file, 
    32);

my $s_gaal2 = Gamla::TextStream::Out::File::Buffered->new(
    \*STDOUT,
    256);

sub output_something3
{
    my $s = shift;

    $s->append("<h1>Text Header</h1>\n\n");
}

sub output_something1
{
    my $s = shift;

    $s->append("<html>\n");
    $s->append("<body bgcolor=\"#FFFFFF\">\n");

    output_something3($s);
}

sub output_something2
{
    my $s = shift;
    
    $s->append("Shlomi Fish Here\n");
    $s->append("</body>\n");
    $s->append("</html>\n");

    return 0;
}

my $s = $s_gaal2;
output_something1($s);
$s->flush_();
#$s->redirect($s_buffer);
output_something2($s);
$s->flush_();

#print $s_buffer->get_buffer();
print ("\n\n\$s->get_count() = ", $s->get_count(), "\n" );


#my $text = $s->get_buffer();

#undef($s);

#print $text;
