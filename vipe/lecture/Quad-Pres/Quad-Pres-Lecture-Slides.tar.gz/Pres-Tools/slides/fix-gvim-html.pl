#!/usr/bin/perl

use strict;

while (<>)
{
    s/<font color="(#[a-f0-9]{6})">/<span style="color : $1">/g;
    s!</font>!</span>!g;
    print $_;
}
