#!/usr/bin/perl

use strict;

use Data::Dumper;
use DBI;

use Arad::OneTable::RecordStream::SQL;

my $conn = DBI->connect('dbi:mysql:test_jobs');

sub generate_spec
{
    my $spec = 
    {
        'tables' => 
        [
            {
                'table_name' => 'jobs',
                'fields' =>
                [
                    {
                        'name' => 'id',
                        'type' => 'int32',
                    },
                    {
                        'name' => 'workplace',
                        'type' => 'varchar',
                    },
                    {
                        'name' => 'description',
                        'type' => 'varchar',
                    },
                    {
                        'name' => 'requirements',
                        'type' => 'varchar',
                    },
                ],
                'sql_order_by' => 'workplace, id',
		'sql_where' => "(workplace LIKE 'N%') OR (workplace LIKE 'T%')"
            },
        ],
        
    };

    return $spec;
}

sub init_spec
{
    my $spec = shift;

    my (%index);
    
    my $a;
    
    for($a=0;$a<scalar(@{$spec->{'tables'}});$a++)
    {
        $index{$spec->{'tables'}->[$a]->{'table_name'}} = $a;
    }
    
    $spec->{'tables_index'} = \%index;
    
    return 0;
}

my $spec = generate_spec();
init_spec($spec);

my $stream = Arad::OneTable::RecordStream::SQL->new($conn, $spec, "jobs");

my $r;

while ($r = $stream->get_next_record())
{
    my $d = Data::Dumper->new([$r],"\$r");
    
    print $d->Dump();
    
    print "\n\n\n";

}

$conn->disconnect();