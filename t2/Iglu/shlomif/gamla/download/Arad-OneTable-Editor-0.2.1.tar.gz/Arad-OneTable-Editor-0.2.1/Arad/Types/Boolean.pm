# Arad::Types::Boolean - a boolean (True or False) SQL data type.
#
# Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 1999
# This code is under the public domain. (It's uncopyrighted)


package Arad::Types::Boolean;

use Arad::Types::Base;

@ISA = qw(Arad::Types::Base);

use strict;

sub initialize
{
    my $self = shift;

    $self->{'type'} = 'boolean';
}

sub check_value
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if (($value eq undef) || ($value eq ''))
    {
        return (0, "")
    }
    elsif ($value !~ /^(true|false|t|f|y|n|yes|no|0|1)$/i)
    {
        return (1, "\$F must be boolean.");
    }
    {
        return (0, "");
    }
}

sub to_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    if (($value eq undef) || ($value eq ''))
    {
        return (0, "null");
    }
    elsif ($value =~ /^(true|t|y|yes|1)$/i)
    {
        return (1, 't');
    }
    else
    {
        return (1, 'f');
    }

    return (0, $value);
}

sub from_sql
{
    my $self = shift;

    my $type_params = shift;
    my $value = shift;

    return $value;
}

sub compare
{
    my $self = shift;

    my $type_params = shift;

    my $value1 = shift;
    my $value2 = shift;

    my $true1 = (($value1 =~ /^(true|t|y|yes|1)$/i) ? 1 : 0);
    my $true2 = (($value2 =~ /^(true|t|y|yes|1)$/i) ? 1 : 0);

    return ($true1 <=> $true2);
}
