#!/usr/bin/perl

use strict;

use Data::Dumper;

#use Gamla::Web::PathMan::Pointer::WithMount;
use Gamla::Web::PathMan::Perl;

my $pathman = Gamla::Web::PathMan::Perl->new();

my $p = $pathman->get_base_pointer();

$p->mkdir_("Hello");
$p->mkdir_("Shlomif");

my $d = Data::Dumper->new([$p],["\$p"]);

print $d->Dump();
