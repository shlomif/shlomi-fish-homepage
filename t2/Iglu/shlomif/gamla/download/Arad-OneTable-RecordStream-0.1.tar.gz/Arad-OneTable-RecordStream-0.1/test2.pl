use DBI;

use strict;

use Data::Dumper;

require 'flush.pl';

my $conn = DBI->connect('dbi:mysql:test_jobs');

my $query = $conn->prepare("SELECT * FROM jobs");

my ($h, $a);

$a = 0;

$query->execute();

while ($h = $query->fetchrow_hashref())
{
	print ($a++, "\n");
	my $d = Data::Dumper->new([ $h ]);
	
	print $d->Dump();
	
	print "\n\n\n";
	&flush(*STDOUT);
}

$conn->disconnect();