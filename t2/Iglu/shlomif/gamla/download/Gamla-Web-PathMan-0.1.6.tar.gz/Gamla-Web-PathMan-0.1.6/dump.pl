$pathman = bless( {
                    'root' => {
                                'attrbs' => {},
                                '..' => undef,
                                'subdirs' => {
                                               'Ira' => {
                                                          'attrbs' => {},
                                                          '..' => $pathman->{'root'},
                                                          'subdirs' => {},
                                                          'is_mounted' => 0
                                                        },
                                               'Shlomif' => {
                                                              'attrbs' => {},
                                                              '..' => $pathman->{'root'},
                                                              'subdirs' => {},
                                                              'is_mounted' => 0
                                                            },
                                               'Hello' => {
                                                            'attrbs' => {
                                                                          'path' => [
                                                                                      'hello'
                                                                                    ],
                                                                          'site' => 'www.iglu.org.il',
                                                                          'cgi_params' => [
                                                                                            'you',
                                                                                            'too',
                                                                                            'u',
                                                                                            '2'
                                                                                          ]
                                                                        },
                                                            '..' => $pathman->{'root'},
                                                            'subdirs' => {
                                                                           'World' => {
                                                                                        'attrbs' => {},
                                                                                        '..' => $pathman->{'root'}{'subdirs'}{'Hello'},
                                                                                        'subdirs' => {},
                                                                                        'is_mounted' => 0
                                                                                      },
                                                                           'Bill (Gates Naturally)' => {
                                                                                                         'attrbs' => {},
                                                                                                         '..' => $pathman->{'root'}{'subdirs'}{'Hello'},
                                                                                                         'subdirs' => {},
                                                                                                         'is_mounted' => 0
                                                                                                       },
                                                                           'You' => {
                                                                                      'attrbs' => {},
                                                                                      '..' => $pathman->{'root'}{'subdirs'}{'Hello'},
                                                                                      'subdirs' => {},
                                                                                      'is_mounted' => 0
                                                                                    }
                                                                         },
                                                            'is_mounted' => 0
                                                          },
                                               'Chen' => {
                                                           'attrbs' => {
                                                                         'path' => [
                                                                                     'chen'
                                                                                   ],
                                                                         'site' => 'www.iglu.org.il'
                                                                       },
                                                           '..' => $pathman->{'root'},
                                                           'subdirs' => {
                                                                          'Shapira' => {
                                                                                         'attrbs' => {},
                                                                                         '..' => $pathman->{'root'}{'subdirs'}{'Chen'},
                                                                                         'subdirs' => {},
                                                                                         'is_mounted' => 0
                                                                                       },
                                                                          'Hackers-IL' => {
                                                                                            'attrbs' => {},
                                                                                            '..' => $pathman->{'root'}{'subdirs'}{'Chen'},
                                                                                            'subdirs' => {},
                                                                                            'is_mounted' => 0
                                                                                          }
                                                                        },
                                                           'is_mounted' => 0
                                                         }
                                             },
                                'is_mounted' => 0
                              }
                  }, 'Gamla::Web::PathMan::Perl' );
$p = bless( {
              'recursive_mount' => 0,
              'cur_dir' => $pathman->{'root'}{'subdirs'}{'Hello'},
              'is_in_mounted' => 0,
              'pm_path' => [
                             'Hello'
                           ],
              'path_man' => $pathman,
              'recursive_write' => 1
            }, 'Gamla::Web::PathMan::Perl::Pointer' );
